package view;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import controller.ControllerDisponibilita;
import ingegnerizzazione.DisponibilitaBean;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class GC_CustomerAvailability {
	
	@FXML
	private Button back;
	@FXML
	private Label numeroLb;
	private String farmacia, farmaco;
	private ControllerDisponibilita controller = new ControllerDisponibilita();
	
	
	private void searchAvailability() {
		DisponibilitaBean bean = controller.cercaDisponibilitaInFarmacia(this.farmacia, this.farmaco);
		numeroLb.setText(bean.getNumero() + " unit�");
	}

	
	@FXML
	public void backPressed() {
		Stage stage = (Stage) back.getScene().getWindow();
		stage.close();
	}
	
	
	@FXML
	public void linkPressed(ActionEvent event) {
		
		
		try {
			java.awt.Desktop.getDesktop().browse(new URI("https://www.google.it/maps/search/farmacia/@41.8926454,12.5233758,12z/data=!3m1!4b1"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	
	
	public void request(String farmacia, String farmaco) {
		this.farmacia = farmacia;
		this.farmaco = farmaco;
		this.searchAvailability();
	}
}
