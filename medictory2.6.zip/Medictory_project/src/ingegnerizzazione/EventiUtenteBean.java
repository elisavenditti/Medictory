package ingegnerizzazione;

import javafx.collections.ObservableList;

public class EventiUtenteBean {
	private ObservableList<EventiUtenteAbstractModelTable> eventi;

	public EventiUtenteBean(ObservableList<EventiUtenteAbstractModelTable> list) {
	this.eventi=list;
	}

	public ObservableList<EventiUtenteAbstractModelTable> getEventi() {
		return eventi;
	}

	public void setEventi(ObservableList<EventiUtenteAbstractModelTable> eventi) {
		this.eventi = eventi;
	}
	
	
}
