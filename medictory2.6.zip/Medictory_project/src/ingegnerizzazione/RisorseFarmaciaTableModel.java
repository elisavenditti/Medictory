package ingegnerizzazione;

public class RisorseFarmaciaTableModel {
	private String farmaco;
	private String quantitativo;

	
	public RisorseFarmaciaTableModel(String f, String q) {
		this.farmaco = f;
		this.quantitativo = q;
		
	}
	
	public String getFarmaco() {
		return farmaco;
	}
	public void setFarmaco(String farmaco) {
		this.farmaco = farmaco;
	}

	public String getQuantitativo() {
		return quantitativo;
	}
	public void setQuantitativo(String quantita) {
		this.quantitativo = quantita;
	}

}
