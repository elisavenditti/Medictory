package ingegnerizzazione;

import javafx.collections.ObservableList;

public class ListaFarmacieBean {


	private ObservableList<ListaFarmacieModelTable> farmacie;
	
	public ListaFarmacieBean(ObservableList<ListaFarmacieModelTable> list) {
		this.setFarmaci(list);
	}

	public ObservableList<ListaFarmacieModelTable> getFarmacie() {
		return farmacie;
	}

	public void setFarmaci(ObservableList<ListaFarmacieModelTable> farmacie) {
		this.farmacie = farmacie;
	}
}
