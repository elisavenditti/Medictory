package model;

import java.util.ArrayList;

public class SessioneFarmacia extends Sessione {
	private ArrayList<FarmacoFarmacia> farmaci;
	
	public SessioneFarmacia(String username, ArrayList<FarmacoFarmacia> farmaci, ArrayList<Evento> eventi) {
		this.username = username;
		this.farmaci = farmaci;
		this.eventi = eventi;
	}
	
	
	public ArrayList<FarmacoFarmacia> getFarmaci() {
		return farmaci;
	}

	public void setFarmaci(ArrayList<FarmacoFarmacia> farmaci) {
		this.farmaci = farmaci;
	}
}
