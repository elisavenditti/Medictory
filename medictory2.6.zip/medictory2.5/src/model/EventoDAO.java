package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class EventoDAO {
	private static Connector connector = Connector.getConnectorInstance();
	


public static ArrayList<Evento> allEventsFarmacia(String username){
	 ArrayList <Evento> eventi = null;
	 Connection conn= connector.getConnection();

	 Statement stmt = null;
	
 
    try {
    	
    	String sql = "SELECT E.`nome`, E.`descrizione`, E.`inizio`, E.`fine`, E.`premio`, E.`livello richiesto`, E.`vincitore` FROM `Evento` E  WHERE  E.`farmacia`='" + username + "';";
    	
    	
        stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

        ResultSet rs = stmt.executeQuery(sql);

    	if (rs.first()) {
    		rs.first();
    		eventi = new ArrayList<Evento>();
    	do {
    		 
    	   	Evento e = new Evento(rs.getString("nome"),rs.getString("descrizione"),rs.getString("premio"),(rs.getDate("inizio")).toString(), (rs.getDate("fine")).toString(), rs.getInt("livello richiesto"));
    	   	eventi.add(e);
    	} while(rs.next());
    	rs.close();
    	}
    	
    
    } catch (SQLException se) {
        // Errore durante l'apertura della connessione
        se.printStackTrace();
    } catch (Exception e) {
        // Errore nel loading del driver
        e.printStackTrace();
    } finally {
        try {
            if (stmt != null)
                stmt.close();
   
        } catch (SQLException se2) {
        }
        try {
            if (conn != null)
                conn.close();
        } catch (SQLException se) {
            se.printStackTrace();
        }
    }
    return eventi;
}


public static 	ArrayList<Evento> allMyEvents(String username){
	 ArrayList <Evento> eventi = null;
	 Connection conn= connector.getConnection();

	 Statement stmt = null;
	
  
     try {
     	
     	String sql="SELECT A.`evento`, E.`descrizione`, E.`inizio`,E.`fine`, E.`premio`, E.`livello richiesto`, E.`vincitore` FROM `Adesioni evento` A JOIN `Evento` E ON E.`nome`=A.`evento` and E.`Farmacia`= A.`Organizzatore` WHERE  A.`cliente`='" + username + "';";
     	
     	
         stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

         ResultSet rs = stmt.executeQuery(sql);

     	if (rs.first()) {
     		rs.first();
     		eventi = new ArrayList<Evento>();
     	do {
     		 
     	   	Evento e = new Evento(rs.getString("evento"),rs.getString("descrizione"),rs.getString("premio"),(rs.getDate("inizio")).toString(), (rs.getDate("fine")).toString(), rs.getInt("livello richiesto"));
     	   	eventi.add(e);
     	} while(rs.next());
     	rs.close();
     	}
     	
     
     } catch (SQLException se) {
         // Errore durante l'apertura della connessione
         se.printStackTrace();
     } catch (Exception e) {
         // Errore nel loading del driver
         e.printStackTrace();
     } finally {
         try {
             if (stmt != null)
                 stmt.close();
    
         } catch (SQLException se2) {
         }
         try {
             if (conn != null)
                 conn.close();
         } catch (SQLException se) {
             se.printStackTrace();
         }
     }
     return eventi;
}
	

	public static  ArrayList<Evento> allActiveEvents() {
		
		Statement stmt = null;
		Connection conn= connector.getConnection();
		
       
        
        ArrayList<Evento> eventi = null;
        try {
        
        	String sql = "select * from `evento` where `inizio`>= now();";
        	
        	/*Class.forName(DRIVER_CLASS_NAME);
            conn = DriverManager.getConnection(DB_URL, USER, PASS);*/
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery(sql);
            
           
            
            if (rs.first()) {
                rs.first();
                eventi = new ArrayList<Evento>();
            	do {
            		 
            	   	Evento e = new Evento(rs.getString("nome"),rs.getString("descrizione"),rs.getString("premio"),(rs.getDate("inizio")).toString(), (rs.getDate("fine")).toString(), rs.getInt("livello richiesto"));
            	   	eventi.add(e);
            	  
            	} while(rs.next());
            	
            	
            	rs.close();
            	}
          
        	
        } catch (SQLException se) {
            // Errore durante l'apertura della connessione
            se.printStackTrace();
        } catch (Exception e) {
            // Errore nel loading del driver
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
            } catch (SQLException se2) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        return eventi;
	}	
}
