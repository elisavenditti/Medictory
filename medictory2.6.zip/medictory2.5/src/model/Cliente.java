package model;

import java.util.ArrayList;

import ingegnerizzazione.Observer;
import ingegnerizzazione.Observable;

public class Cliente extends Utente implements Observable{
	private String farma_associata;
	private int punti;
	private int livello;
	private ArrayList<FarmacoCliente> farmaci;
	private ArrayList<Evento> eventi;
	
	private ArrayList<Observer> observers = new ArrayList<Observer>();
	
	
	public Cliente(String user, String pwd, String em) {
		super(user, pwd, em);
		this.punti = 0;
		this.livello = 0;
	}
	public Cliente(String user, String pwd, String em, String farma, int pt, int lv) {
		
		super(user, pwd, em);
		this.farma_associata = farma;
		this.punti = pt;
		this.livello = lv;
	}
	
	public void setPunti(int p){
		this.punti = p;
	}
	public void setLivello(int l){
		this.livello = l;
	}
	public void setFarmaciaAssociata(String f){
		this.farma_associata = f;
	}
	/*		// MAGARI QUESTE OP DOVREBBERO ESSERE FATTE DAL CONTROLLORE ...
	 public void incrementaPunti(int p){
		this.punti = this.punti + p;
	 }
	 public void incrementaLivello(){
		this.livello ++;
	 }
	*/
	
	public int getPunti(){
		return this.punti;
	}
	public String getFarma_associata() {
		return farma_associata;
	}
	public void setFarma_associata(String farma_associata) {
		this.farma_associata = farma_associata;
	}
	public ArrayList<FarmacoCliente> getFarmaci() {
		return farmaci;
	}
	public void setFarmaci(ArrayList<FarmacoCliente> farmaci) {
		this.farmaci = farmaci;
	}
	public ArrayList<Evento> getEventi() {
		return eventi;
	}
	public void setEventi(ArrayList<Evento> eventi) {
		this.eventi = eventi;
	}
	public int getLivello(){
		return this.livello;
	}
	
	
	
	@Override
	public void attach(Observer observer){   //agg un osservatore alla lista
		if (!observers.contains(observer))
			observers.add(observer);		
	}
	
	@Override
	public void detach(Observer observer) {
		observers.remove(observer);
		
	}
	@Override
	public void notifica(){
	    for (Observer observer : observers) {
	       observer.update();
	    }

	}
	
	
	
}
