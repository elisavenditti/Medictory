package view;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.FarmacoCliente;
import model.Sessione;
import model.SessioneCliente;

import java.io.IOException;

import controller.ControllerCustomerResource;
import ingegnerizzazione.EventiUtenteAbstractModelTable;
import ingegnerizzazione.EventiUtenteBean;
import ingegnerizzazione.EventiUtenteModelTable;
import ingegnerizzazione.MyEventiUtenteBean;
import ingegnerizzazione.MyEventiUtenteModelTable;
import ingegnerizzazione.RisorseUtenteBean;
import ingegnerizzazione.RisorseUtenteTableModel;
import ingegnerizzazione.StoricoUtenteBean;
import ingegnerizzazione.StoricoUtenteTableModel;
import javafx.scene.Scene;

public class GC_CustomerEvent implements Graphic_Controller {
	@FXML
	private Button risorse, risorse2;
	@FXML
	private Button riciclaggio, riciclaggio2;
	@FXML
	private Button account, account2;
	@FXML
	private Button home, home2;
	@FXML
	private Button myEvent, eventiAttivi;
	@FXML
	private Button join;
	
	
	@FXML
	private TableView<EventiUtenteAbstractModelTable> myEventoTb;
	@FXML
	private TableColumn<EventiUtenteAbstractModelTable, String> risorse_cl1, risorse_cl2, risorse_cl3, risorse_cl4, risorse_cl5, extra;
	
	
	
	private SessioneCliente sessione;
	private ControllerCustomerResource controller = new ControllerCustomerResource();
	
	private void setPrimaryStage(Stage primaryStage, String file, Button btn) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource(file));
			Parent root = loader.load();
			
			Graphic_Controller controller_next = loader.getController();
			controller_next.setData(sessione);
			
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
			}
		
	}
	
	public void setData(Sessione cliente) {
		this.sessione = (SessioneCliente)cliente;
		this.showResource();

	}
	
public void showResource() {
		
		ObservableList<EventiUtenteAbstractModelTable> list = FXCollections.observableArrayList();
		risorse_cl1.setCellValueFactory(new PropertyValueFactory<EventiUtenteAbstractModelTable, String>("Evento"));
		risorse_cl2.setCellValueFactory(new PropertyValueFactory<EventiUtenteAbstractModelTable, String>("Descrizione"));
		risorse_cl3.setCellValueFactory(new PropertyValueFactory<EventiUtenteAbstractModelTable, String>("Premio"));
		risorse_cl4.setCellValueFactory(new PropertyValueFactory<EventiUtenteAbstractModelTable, String>("DataInizio"));
		risorse_cl5.setCellValueFactory(new PropertyValueFactory<EventiUtenteAbstractModelTable, String>("DataFine"));
		
		
		
		
		if(extra != null) {
			extra.setCellValueFactory(new PropertyValueFactory<EventiUtenteAbstractModelTable, String>("Requisiti"));
			EventiUtenteBean bean = controller.findAllActiveEvents();
			
			
			list =  bean.getEventi();
			
		}
		
		
		if(sessione != null && extra ==null) {
			MyEventiUtenteBean bean = controller.findEvents(sessione);	
			
			list = bean.getEventi();
		}
		
		
		myEventoTb.setItems(list);
		

	}
	


	
	@FXML
	public void risorsePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "Risorse.fxml",(Button)event.getSource());
	}
	
	@FXML
	public void risorse2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "Risorse.fxml",(Button)event.getSource());
	}
	
	@FXML
	public void accountPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerAccount.fxml",(Button)event.getSource());
	}
	
	@FXML
	public void account2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerAccount.fxml",(Button)event.getSource());
	}
	
	@FXML
	public void riciclaggioPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerRiciclaggio.fxml",(Button)event.getSource());
	}
	
	@FXML
	public void riciclaggio2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerRiciclaggio.fxml",(Button)event.getSource());
	}
	
	@FXML
	public void homePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepageClient.fxml",(Button)event.getSource());
	}
	
	@FXML
	public void home2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepageClient.fxml",(Button)event.getSource());
	}
	
	@FXML
	public void eventiAttiviPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerEventi.fxml",(Button)event.getSource());
	}
	
	@FXML
	public void myEventPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerMyEvent.fxml",(Button)event.getSource());
	}
}
