package view;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.FarmacoCliente;
import model.Sessione;
import model.SessioneCliente;
import java.io.IOException;
import controller.ControllerCustomerResource;
import ingegnerizzazione.RisorseUtenteBean;
import ingegnerizzazione.RisorseUtenteTableModel;
import javafx.scene.Scene;
import ingegnerizzazione.Observer;

public class GC_CustomerRisorse implements Graphic_Controller, Observer {
	
	@FXML
	private Button riciclaggio;
	@FXML
	private Button eventi;
	@FXML
	private Button account;
	@FXML
	private Button submit;
	@FXML
	private Button home;
	@FXML
	private TextField farmaco;
	@FXML
	private TextField descrizione;
	@FXML
	private TextField quantitativo;
	@FXML
	private TextField scadenza;

	@FXML
	private TableView<RisorseUtenteTableModel> risorsetb;
	@FXML
	private TableColumn<RisorseUtenteTableModel, String> risorse_cl1, risorse_cl2, risorse_cl3, risorse_cl4;
	
	
	private SessioneCliente sessione;
	private ControllerCustomerResource controller = new ControllerCustomerResource();
	

	private void setPrimaryStage(Stage primaryStage, String file, Button btn) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource(file));
			Parent root = loader.load();
					
			Graphic_Controller controller_next = loader.getController();
			controller_next.setData(sessione);
			
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	private void mostraErrore(String err) {
		try {
			
			Stage primaryStage = new Stage();
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Errore.fxml"));
			Parent root = loader.load();
			GC_Errore controller_next = loader.getController();
			controller_next.setError(err);
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 314, 209));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	
	
	public void setData(Sessione cliente) {
		this.sessione = (SessioneCliente)cliente;
		for (FarmacoCliente f : sessione.getFarmaci()) {
			if(f.getStato().compareTo("utilizzabile") == 0) f.attach(this);
		}
		this.showResource();
	}
	
	
	@FXML
	public void submitPressed(ActionEvent event) {
		
		String f = farmaco.getText();
		String q = quantitativo.getText();
		String d = descrizione.getText();
		String s = scadenza.getText();
		
		if(d.compareTo("") == 0 || s.compareTo("") == 0 || f.compareTo("") == 0 || q.compareTo("") == 0) {
			mostraErrore("Non hai inserito tutti i parametri");
		}
		
		else if(d.compareTo("") == 0 && s.compareTo("") == 0 && f.compareTo("") != 0 && q.compareTo("") != 0) {
			controller.modifyAmount(sessione, f, Integer.parseInt(q));
		}
		
		else if (f.compareTo("") != 0 || q.compareTo("") != 0 || d.compareTo("") != 0 || s.compareTo("") != 0) {
			if(controller.addMedicine(sessione, this, f, d, s, Integer.parseInt(q)) == false) {
			
				mostraErrore("Non puoi inserire un medicinale scaduto");
				
			}
			farmaco.setText("");
			quantitativo.setText("");
			descrizione.setText("");
			scadenza.setText("");
		}
		
	}
	
	public void showResource() {
		
		ObservableList<RisorseUtenteTableModel> list = FXCollections.observableArrayList();
		risorse_cl1.setCellValueFactory(new PropertyValueFactory<RisorseUtenteTableModel, String>("Farmaco"));
		risorse_cl2.setCellValueFactory(new PropertyValueFactory<RisorseUtenteTableModel, String>("Descrizione"));
		risorse_cl3.setCellValueFactory(new PropertyValueFactory<RisorseUtenteTableModel, String>("Quantitativo"));
		risorse_cl4.setCellValueFactory(new PropertyValueFactory<RisorseUtenteTableModel, String>("Scadenza"));
		
		
		if(sessione != null) {
			RisorseUtenteBean bean = controller.findResources(sessione);
		
		//chiama la bean per visualizzare i dati:
		list = bean.getFarmaci();
		risorsetb.setItems(list);
		}
	}
	
	@FXML
	public void accountPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerAccount.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void homePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepageClient.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void riciclaggioPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerRiciclaggio.fxml",(Button)event.getSource());
		
	}
	
	@FXML
	public void eventiPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerMyEvent.fxml", (Button)event.getSource());
	}


	@Override
	public void update() {
		showResource();
	}

}
