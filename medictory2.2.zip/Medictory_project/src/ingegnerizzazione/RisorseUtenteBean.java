package ingegnerizzazione;
import javafx.collections.ObservableList;



public class RisorseUtenteBean {
	private ObservableList<RisorseUtenteTableModel> farmaci;
	
	public RisorseUtenteBean(ObservableList<RisorseUtenteTableModel> list) {
		this.setFarmaci(list);
	}

	public ObservableList<RisorseUtenteTableModel> getFarmaci() {
		return farmaci;
	}

	public void setFarmaci(ObservableList<RisorseUtenteTableModel> farmaci) {
		this.farmaci = farmaci;
	}
	
	
}
