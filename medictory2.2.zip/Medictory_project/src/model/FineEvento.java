package model;

//Closed event

public class FineEvento extends AbstractState{
	
	

	public FineEvento(Evento evento) {
		super(evento);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void addPartecipant(String username){
	}
    
	@Override
	public void setLivello_richiesto(int lv) {
	}
    
	@Override
	public String getVincitore() {
		return "OK";
	}
    
	@Override
	public void setVincitore(String v) {
		
	}
    
	@Override
	public void setFine(String f) {
	}
    
	@Override
	public void setInizio(String i) {
	}
    
	@Override
	public void setPremio(String premio) {
	}
    
	@Override
	public void setDescrizione(String ds) {
	}
    
	@Override
	public void setNome(String nome) {
	}
    
	@Override
	public AbstractState nextState() {
		return null;
	}
	
}
