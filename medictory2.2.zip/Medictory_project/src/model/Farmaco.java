package model;

import java.util.ArrayList;

public class Farmaco {
	private String nome;
	private String descrizione;
	private String scadenza;
	private int quantita;
	
	
	public Farmaco(String nome, String descrizione, String scadenza, int quantita) {
		this.nome = nome;
		this.descrizione = descrizione;
		this.scadenza = scadenza;
		this.quantita = quantita;
	}
	
	

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDescrizione() {
		return descrizione;
	}
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	public String getScadenza() {
		return scadenza;
	}
	public void setScadenza(String scadenza) {
		this.scadenza = scadenza;
	}
	public int getQuantita() {
		return quantita;
	}
	public void setQuantita(int quantita) {
		this.quantita = quantita;
	}
	
}
