	package model;
import java.sql.*;
import java.util.ArrayList;


public class ClienteDAO {
	private static String USER = "root";
	private static String PASS = "";
	private static String DB_URL = "jdbc:mysql://localhost:3306/medictory?serverTimezone=Europe/Rome";
	private static String DRIVER_CLASS_NAME = "com.mysql.cj.jdbc.Driver";
	private static AbstractFactory factory = new FactoryElementoUtente();
	
	public static Cliente creaUtenteCliente(String username, String pwd, String email, String farma) {
		Statement stmt = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		Statement stmt4 = null;
        Connection conn = null;
        Cliente c = null;
        
        try {
        	
        	String sql = "SELECT `username` " + "FROM `Utenti` where `username` = '" + username + "';";
            String sql2 = "INSERT INTO `Utenti` (`username`, `password`, `email`) values ('"+ username + "', '" + pwd + "', '" +email + "');" ;
            String sql3 = "SELECT `username` " + "FROM `Farmacia` where `username` = '" + farma + "';";
            String sql4 = "INSERT INTO `Cliente` (`username`, `farmacia associata`) values ('"+ username + "', '" + farma + "');" ;
            
        	
        	Class.forName(DRIVER_CLASS_NAME);
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            stmt2 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt3 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            stmt4 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            
            
            ResultSet rs = stmt.executeQuery(sql);
            ResultSet rs3 = stmt3.executeQuery(sql3);
            
            if (!rs3.first()) return null;			//se rs3 non trova farmacie l'input era errato
            
            if (!rs.first()) {						// rs vuoto --> posso procedere
            	
            	
            	stmt2.executeUpdate(sql2);
            	stmt4.executeUpdate(sql4);
            	c = new Cliente(username, pwd, email);
            	c.setFarmaciaAssociata(farma);
            	return c;

            }
            rs.close();
            stmt.close();
            
            conn.close();
        } catch (SQLException se) {
            // Errore durante l'apertura della connessione
            se.printStackTrace();
        } catch (Exception e) {
            // Errore nel loading del driver
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
            } catch (SQLException se2) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        return null;
	}
	
	
	
	
	public static  Cliente esisteCliente(String username, String pwd) {
		
		Statement stmt = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
        Connection conn = null;
        Cliente cl = null;
        
        ArrayList<FarmacoCliente> farmaci = new ArrayList<FarmacoCliente>();
        ArrayList <Evento> eventi = new ArrayList<Evento>();
        
        try {
        	
        	String sql = "SELECT C.`username`, C.`farmacia associata`, C.`punti`, C.`livello`, U.`password`, U.`email` " + "FROM `Cliente` C join `Utenti` U  on C.`username` = U.`username` WHERE C.`username` = '" + username + "' and U.`password` = '" + pwd + "';";
        	String sql1="SELECT F.`farmaco`, F.`descrizione`,F.`scadenza`,F.`quantitativo`, F.`stato` FROM `Farmaco Cliente`F WHERE  F.`possessore`='" + username + "';";
        	String sql2="SELECT A.`evento`, E.`descrizione`, E.`inizio`,E.`fine`, E.`premio`, E.`livello richiesto`, E.`vincitore` FROM `Adesioni evento` A JOIN `Evento` E ON E.`nome`=A.`evento` and E.`Farmacia`= A.`Organizzatore` WHERE  A.`cliente`='" + username + "';";
        	
        	
        	Class.forName(DRIVER_CLASS_NAME);
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            stmt2 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            stmt3 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            
   
            ResultSet rs = stmt.executeQuery(sql);
            ResultSet rs2 = stmt2.executeQuery(sql1);
            ResultSet rs3 = stmt3.executeQuery(sql2);
           
            
            if	(rs.first()) {
            	rs.first();
            	cl = (Cliente)factory.creaUtente(rs.getString("username"), rs.getString("password"), rs.getString("email"));
            	cl.setFarma_associata(rs.getString("farmacia associata"));
            	cl.setPunti(rs.getInt("punti"));
            	cl.setLivello(rs.getInt("livello"));
            }
          
            rs.close();
          
            if (rs2.first()) {
            rs2.first();
        	do {
        	    FarmacoCliente f = (FarmacoCliente)factory.creaFarmaco(rs2.getString("farmaco"), rs2.getString("descrizione"), rs2.getString("scadenza"), rs2.getInt("quantitativo"));
        	   	f.setStato(rs2.getString("stato"));
        	   	farmaci.add(f);
        	   	} while(rs2.next());
        	rs2.close();
            }
            	
      
        	if (rs3.first()) {
            rs3.first();
        	do {
        		 
        	   	Evento e = new Evento(rs3.getString("evento"),rs3.getString("descrizione"),rs3.getString("premio"),(rs3.getDate("inizio")).toString(), (rs3.getDate("fine")).toString(), rs3.getInt("livello richiesto"));
        	   	eventi.add(e);
        	} while(rs3.next());
        	rs3.close();
        	}
        	
        	cl.setFarmaci(farmaci);
        	cl.setEventi(eventi);
        	
        } catch (SQLException se) {
            // Errore durante l'apertura della connessione
            se.printStackTrace();
        } catch (Exception e) {
            // Errore nel loading del driver
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
                if (stmt2 != null)
                    stmt2.close();
                if (stmt3 != null)
                    stmt3.close();
            } catch (SQLException se2) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        return cl;
	}
	
	
public static  ArrayList<Evento> allActiveEvents() {
		
		Statement stmt = null;
		Connection conn = null;
       
        
        ArrayList<Evento> eventi = new ArrayList<Evento>();
        try {
        
        	String sql = "select * from `evento` where `inizio`>= now();";
        	
        	Class.forName(DRIVER_CLASS_NAME);
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery(sql);
            
           
            
            if (rs.first()) {
                rs.first();
            	do {
            		 
            	   	Evento e = new Evento(rs.getString("nome"),rs.getString("descrizione"),rs.getString("premio"),(rs.getDate("inizio")).toString(), (rs.getDate("fine")).toString(), rs.getInt("livello richiesto"));
            	   	eventi.add(e);
            	  
            	} while(rs.next());
            	
            	
            	rs.close();
            	}
          
        	
        } catch (SQLException se) {
            // Errore durante l'apertura della connessione
            se.printStackTrace();
        } catch (Exception e) {
            // Errore nel loading del driver
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
            } catch (SQLException se2) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        return eventi;
	}	
	
public static  ArrayList<String> datiAccount(String username) {
		
		Statement stmt = null;
		Connection conn = null;
        Cliente cl = null;
        
        ArrayList<String> dati = new ArrayList<String>();
        try {
        	
        	String sql = "select C.`username`, C.`farmacia associata`, C.`punti`, C.`livello`, U.`email` from `Cliente` C join `Utenti` U on C.`username` = U.`username` where C.`username` = '" + username + "';";
        	
        	Class.forName(DRIVER_CLASS_NAME);
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery(sql);
            
           
            
            if	(rs.first()) {
            	rs.first();
            	dati.add(rs.getString("username"));
            	dati.add(rs.getString("farmacia associata"));
            	dati.add(Integer.toString(rs.getInt("punti")));
            	dati.add(Integer.toString(rs.getInt("livello")));
            	dati.add(rs.getString("email"));
            }
          
            rs.close();
        	
        } catch (SQLException se) {
            // Errore durante l'apertura della connessione
            se.printStackTrace();
        } catch (Exception e) {
            // Errore nel loading del driver
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
            } catch (SQLException se2) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        return dati;
	}
	
	
}
