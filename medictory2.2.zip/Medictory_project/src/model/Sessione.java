package model;

import java.util.ArrayList;

public abstract class Sessione {
	protected String username;
	protected ArrayList<Evento> eventi;
	
		
	public String getUsername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public ArrayList<Evento> getEventi() {
		return eventi;
	}
	public void setEventi(ArrayList<Evento> eventi) {
		this.eventi = eventi;
	}
 
}
