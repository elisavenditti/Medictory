package model;

import java.util.ArrayList;

public class SessioneCliente extends Sessione{
	
	private ArrayList<FarmacoCliente> farmaci;
	private int punteggio;
		
	public SessioneCliente(String username, ArrayList<FarmacoCliente> farmaci, ArrayList<Evento> eventi) {
		this.username = username;
		this.farmaci = farmaci;
		this.eventi = eventi;
	}
	
	
	public int getPunteggio() {
		return punteggio;
	}


	public void setPunteggio(int punteggio) {
		this.punteggio = punteggio;
	}


	public ArrayList<FarmacoCliente> getFarmaci() {
		return farmaci;
	}

	public void setFarmaci(ArrayList<FarmacoCliente> farmaci) {
		this.farmaci = farmaci;
	}
	

}
