package model;


public abstract class AbstractState/*State*/ {
	protected Evento evento;
	
	public AbstractState(Evento evento) {
		this.evento= evento;
		
	}
	
	

    public abstract void addPartecipant(String username);
    public abstract void setLivello_richiesto(int lv);
    public abstract String getVincitore();
    public abstract void setVincitore(String v);
    public abstract void setFine(String f);
    public abstract void setInizio(String i);
    public abstract void setPremio(String premio);
    public abstract void setDescrizione(String ds);
    public abstract void setNome(String nome);
    public abstract AbstractState nextState();


	
    
}
