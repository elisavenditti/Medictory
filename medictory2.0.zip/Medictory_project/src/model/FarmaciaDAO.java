package model;
import java.sql.*;
import java.util.ArrayList;

import javafx.collections.ObservableList;
import view.ModelTable;

public class FarmaciaDAO {
	private static String USER = "root";
	private static String PASS = "lZ...030599";
	private static String DB_URL = "jdbc:mysql://localhost:3306/medictory";
	private static String DRIVER_CLASS_NAME = "com.mysql.cj.jdbc.Driver";
	private static AbstractFactory factory = new FactoryElementoFarmacia();
	
	
	public static Farmacia creaUtenteFarmacia(String username, String pwd, String nome, String email, String indirizzo) {
		Statement stmt = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		Statement stmt4 = null;
        Connection conn = null;
        Farmacia f = null;
        
        try {
        	
        	String sql = "SELECT `username` " + "FROM `Farmacia` where `username` = '" + username + "';";
            String sql2 = "SELECT `indirizzo` " + "FROM `Farmacia` where `indirizzo` = '" + indirizzo + "';";
            String sql3 = "INSERT INTO `Utenti` (`username`, `password`, `email`) values ('"+ username + "', '" + pwd + "', '" +email + "');" ;
            String sql4 = "INSERT INTO `Farmacia` (`username`, `nome`, `indirizzo`) values ('"+ username + "', '" + nome + "', '" +indirizzo + "');" ;
            
        	//cerca nel db se esistono username e indirizzo inseriti
        	Class.forName(DRIVER_CLASS_NAME);
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            stmt2 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            stmt3 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt4 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            
            
            ResultSet rs = stmt.executeQuery(sql);
            ResultSet rs2 = stmt2.executeQuery(sql2);
           
            if (!rs.first() && !rs2.first()) {		// rs e rs2 vuoti --> posso procedere
            	
            	
            	stmt3.executeUpdate(sql3);
            	stmt4.executeUpdate(sql4);
            	f = new Farmacia(username, pwd, email);
            	f.setNome(nome);
            	f.setIndirizzo(indirizzo);
            	return f;

            }
            rs.close();
            stmt.close();
            
            conn.close();
        } catch (SQLException se) {
            // Errore durante l'apertura della connessione
            se.printStackTrace();
        } catch (Exception e) {
            // Errore nel loading del driver
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
            } catch (SQLException se2) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        return null;
	}
	
	
	
	
	public static Farmacia esisteFarmacia(String username, String pwd) {
		
		Statement stmt = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
        Connection conn = null;
        Farmacia f = null;
        
        ArrayList<FarmacoFarmacia> farmaci = new ArrayList<FarmacoFarmacia>();;
        ArrayList <Evento> eventi = new ArrayList<Evento>();
        
        try {
        	
        	String sql = "SELECT F.`username`, F.`nome`, F.`indirizzo`, U.`password`, U.`email` " + "FROM `Farmacia` F join `Utenti` U on F.`username`= U.`username` where F.`username` = '" + username + "' and U.`password` = '" + pwd + "';";
        	String sql2 = "SELECT F.`farmaco`, F.`descrizione`,F.`scadenza`,F.`quantitativo` FROM `Farmaco Farmacia`F WHERE  F.`possessore`='" + username + "';";
        	String sql3 = "SELECT E.`nome`, E.`descrizione`, E.`inizio`, E.`fine`, E.`premio`, E.`livello richiesto`, E.`vincitore` FROM `Evento` E  WHERE  E.`farmacia`='" + username + "';";
        	
        	Class.forName(DRIVER_CLASS_NAME);
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            stmt2 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            stmt3 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            
            
            ResultSet rs = stmt.executeQuery(sql);
            ResultSet rs2 = stmt2.executeQuery(sql2);
            ResultSet rs3 = stmt3.executeQuery(sql3);
           
            if	(rs.first()) {
            	rs.first();
            	f = (Farmacia)factory.creaUtente(rs.getString("username"), rs.getString("password"), rs.getString("email"));
            	f.setNome(rs.getString("nome"));
            	f.setIndirizzo(rs.getString("indirizzo"));
            	
            }
        
            rs.close();
          
            if (rs2.first()) {
            rs2.first();
        	do {
        	    FarmacoFarmacia farmaco= (FarmacoFarmacia)factory.creaFarmaco(rs2.getString("farmaco"), rs2.getString("descrizione"), rs2.getString("scadenza"), rs2.getInt("quantitativo"));
        	   	farmaci.add(farmaco);
        	   	} while(rs2.next());
        	rs2.close();
            }
            	
      
        	if (rs3.first()) {
            rs3.first();
        	do {
        		 
        	   	Evento e = new Evento(rs3.getString("nome"),rs3.getString("descrizione"),rs3.getString("premio"),(rs3.getDate("inizio")).toString(), (rs3.getDate("fine")).toString(), rs3.getInt("livello richiesto"));
        	   	eventi.add(e);
        	} while(rs3.next());
        	rs3.close();
        	}
        	
        	f.setFarmaci(farmaci);
        	f.setEventi(eventi);
        	            
        } catch (SQLException se) {
            // Errore durante l'apertura della connessione
            se.printStackTrace();
        } catch (Exception e) {
            // Errore nel loading del driver
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
            } catch (SQLException se2) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        return f;
	}
	
	
	
	
	
	
	
	public static ObservableList<ModelTable> popolaRegistazione(ObservableList<ModelTable> list) {
		Statement stmt = null;
        Connection conn = null;
        
       try { 
      
    	   	String sql = "SELECT `username`, `nome`, `indirizzo` " + "FROM `Farmacia`;";
    	   	Class.forName(DRIVER_CLASS_NAME);
    	   	conn = DriverManager.getConnection(DB_URL, USER, PASS);
    	   	stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
    	   	ResultSet rs = stmt.executeQuery(sql);
       
        
    	   	if (!rs.first()) return null;
        	rs.first();
    	   	do {
    	   		list.add(new ModelTable(rs.getString("username"), rs.getString("nome"), rs.getString("indirizzo")));
    	   	} while(rs.next());
    	   	
    	   	rs.close();
    	   	stmt.close();
    	   	conn.close();
    	   	return list;
       	} catch (SQLException se) {
       		// Errore durante l'apertura della connessione
       		se.printStackTrace();
       	} catch (Exception e) {
       		// Errore nel loading del driver
       		e.printStackTrace();
       	} finally {
       		try {
       			if (stmt != null)
       				stmt.close();
       		} catch (SQLException se2) {
       		}
       		try {
       			if (conn != null)
       				conn.close();
       		} catch (SQLException se) {
       			se.printStackTrace();
       		}
       	}
       return null;
	}
        
        
        
}
