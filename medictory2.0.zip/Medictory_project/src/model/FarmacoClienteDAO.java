package model;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javafx.collections.ObservableList;
import view.ModelTable;

public class FarmacoClienteDAO {
	private static String USER = "root";
	private static String PASS = "lZ...030599";
	private static String DB_URL = "jdbc:mysql://localhost:3306/medictory";
	private static String DRIVER_CLASS_NAME = "com.mysql.cj.jdbc.Driver";
	
	
	public List<FarmacoCliente> retrieveResourceFromDb(String username) {
		
		List<FarmacoCliente> farmaci =  new ArrayList<FarmacoCliente>();
		
		//in Farmaco Cliente trova i farmaci 'utilizzabili che sono dell'username'
		Statement stmt = null;
		Connection conn = null;
     
        
        try {
        	
        	String sql = "SELECT `farmaco`, `descrizione`, `scadenza`, `quantitativo`, `stato` " + "FROM `Farmaco Cliente` where `possessore` = '" + username + "';";
           
        	//cerca nel db i farmaci dell'utente
        	Class.forName(DRIVER_CLASS_NAME);
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);       
            
            ResultSet rs = stmt.executeQuery(sql);
            
           
            if (rs.first()) {		// rs non vuoto, posso procedere
            	rs.first();
            	do {
            		FarmacoCliente f =new FarmacoCliente(rs.getString("farmaco"), rs.getString("descrizione"), rs.getString("scadenza"), rs.getInt("quantitativo"));
             		f.setStato(rs.getString("stato"));
            		farmaci.add(f);
            		
            	} while (rs.next());
            	return farmaci;
            }

            else{
            	rs.close();
                stmt.close();
                conn.close();
                return null;
            }
        } catch (SQLException se) {
            // Errore durante l'apertura della connessione
            se.printStackTrace();
        } catch (Exception e) {
            // Errore nel loading del driver
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
            } catch (SQLException se2) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
		return null;
	}
}
