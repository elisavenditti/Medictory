package view;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import model.Sessione;
import model.SessioneCliente;

import java.io.IOException;
import javafx.scene.Scene;

public class GC_CustomerAccount  implements Graphic_Controller {
	@FXML
	private Button farma, dati;
	@FXML
	private Button home, home2;
	@FXML
	private Button logout, logout2;
	
	private SessioneCliente sessione;
	
	
	private void setPrimaryStage(Stage primaryStage, String file, Button btn) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource(file));
			Parent root = loader.load();
			
			/*if(btn.getId().compareTo("farma")== 0) {
				GC_CustomerAccount controller_next = loader.getController();
				controller_next.setData(sessione);
			}
			else if(btn.getId().compareTo("dati")== 0) {
				GC_CustomerAccount controller_next = loader.getController();
				controller_next.setData(sessione);
			}
			else if(btn.getId().compareTo("home")== 0) {
				GC_CustomerHomepage controller_next = loader.getController();
				controller_next.setData(sessione);
			}
			else if(btn.getId().compareTo("home2")== 0) {
				GC_CustomerHomepage controller_next = loader.getController();
				controller_next.setData(sessione);
			}*/
		
			
			
			if (btn.getId().compareTo("logout") !=0 && btn.getId().compareTo("logout2") !=0 ) {
				Graphic_Controller controller_next=loader.getController();
				controller_next.setData(sessione);
			}
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
			}
		
	}
	
	
	public void setData(Sessione cliente) {
		this.sessione = (SessioneCliente)cliente;
	}
	
	@FXML
	public void datiPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerAccount.fxml",(Button)event.getSource());
	}
	
	@FXML
	public void farmaPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerAccountPage2.fxml",(Button)event.getSource());
	}

	@FXML
	public void homePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepageClient.fxml",(Button)event.getSource());
	}
	@FXML
	public void home2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepageClient.fxml",(Button)event.getSource());
	}
	
	@FXML
	public void logoutPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "progetto.fxml",(Button)event.getSource());
	}
	
	@FXML
	public void logout2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "progetto.fxml",(Button)event.getSource());
	}
}
