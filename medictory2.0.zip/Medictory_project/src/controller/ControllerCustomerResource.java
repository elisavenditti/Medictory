package controller;

import java.util.ArrayList;


import ingegnerizzazione.RisorseUtenteBean;
import ingegnerizzazione.RisorseUtenteTableModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.FarmacoCliente;
import model.SessioneCliente;

public class ControllerCustomerResource {
	
	
	public RisorseUtenteBean findResources(SessioneCliente s) {
		int i;
	
		ObservableList<RisorseUtenteTableModel> list = FXCollections.observableArrayList();
		
		ArrayList<FarmacoCliente> farmaci = s.getFarmaci();
		
		for(i=0; i<farmaci.size(); i++) {
			if(farmaci.get(i).getStato().compareTo("utilizzabile") == 0)
			list.add(new RisorseUtenteTableModel(farmaci.get(i).getNome(), farmaci.get(i).getDescrizione(), farmaci.get(i).getQuantita(), farmaci.get(i).getScadenza())); 
		}
		
		RisorseUtenteBean bean = new RisorseUtenteBean(list);
		return bean;
		
	}
	
	public void modifyAmount(SessioneCliente s, String farma, int quantitativo) {
		ArrayList<FarmacoCliente> farmaci = s.getFarmaci();
		for (FarmacoCliente f : farmaci) {
			if(f.getNome().compareToIgnoreCase(farma)==0) {
				f.setQuantita(f.getQuantita() + quantitativo);
				f.notifica();
				
		}
		
		
		
		}
	}
}
