package controller;
import model.Farmacia;
import model.FarmaciaDAO;
import model.SessioneCliente;
import model.SessioneFarmacia;
import model.Cliente;
import model.ClienteDAO;

public class ControllerLogin {
	private SessioneCliente s;
	private SessioneFarmacia sf;
	
	
	public SessioneFarmacia loginFarmacia(String us, String pwd) {
		if (us == null || pwd == null || us.equals("") || pwd.equals("")) return null;
		
		Farmacia f;
		f = FarmaciaDAO.esisteFarmacia(us, pwd);
		
		
		if(f == null) return null;
		sf = new SessioneFarmacia(f.getUsername(),f.getFarmaci(),f.getEventi());
		
		return sf;
	}
	
	public SessioneCliente loginCliente(String us, String pwd) {
		if (us == null || pwd == null || us.equals("") || pwd.equals("")) return null;
		
		Cliente c;
		c = ClienteDAO.esisteCliente(us, pwd);
			
		
		if(c == null) return null;
		
		s = new SessioneCliente(c.getUsername(),c.getFarmaci(),c.getEventi());
		s.setPunteggio(c.getPunti());
		
		return s;
	}
}
