package ingegnerizzazione;

import javafx.collections.ObservableList;

public class RiciclaggioUtenteBean {
private ObservableList<RiciclaggioUtenteTableModel> farmaci;
	
	public RiciclaggioUtenteBean(ObservableList<RiciclaggioUtenteTableModel> list) {
		this.setFarmaci(list);
	}

	public ObservableList<RiciclaggioUtenteTableModel> getFarmaci() {
		return farmaci;
	}

	public void setFarmaci(ObservableList<RiciclaggioUtenteTableModel> farmaci) {
		this.farmaci = farmaci;
	}
}
