package model;
import java.sql.*;

public class ClienteDAO {
	private static String USER = "root";
	private static String PASS = "Telepatia.95";
	private static String DB_URL = "jdbc:mysql://localhost:3306/medictory";
	private static String DRIVER_CLASS_NAME = "com.mysql.cj.jdbc.Driver";
	
	public static Cliente creaUtenteCliente(String username, String pwd, String email, String farma) {
		Statement stmt = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		Statement stmt4 = null;
        Connection conn = null;
        Cliente c = null;
        
        try {
        	
        	String sql = "SELECT `username` " + "FROM `Utenti` where `username` = '" + username + "';";
            String sql2 = "INSERT INTO `Utenti` (`username`, `password`, `email`) values ('"+ username + "', '" + pwd + "', '" +email + "');" ;
            String sql3 = "SELECT `username` " + "FROM `Farmacia` where `username` = '" + farma + "';";
            String sql4 = "INSERT INTO `Cliente` (`username`, `farmacia associata`) values ('"+ username + "', '" + farma + "');" ;
            
        	
        	Class.forName(DRIVER_CLASS_NAME);
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            stmt2 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt3 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            stmt4 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            
            
            ResultSet rs = stmt.executeQuery(sql);
            ResultSet rs3 = stmt3.executeQuery(sql3);
            
            if (!rs3.first()) return null;			//se rs3 non trova farmacie l'input era errato
            
            if (!rs.first()) {						// rs vuoto --> posso procedere
            	
            	
            	stmt2.executeUpdate(sql2);
            	stmt4.executeUpdate(sql4);
            	c = new Cliente(username, pwd, email, farma);
            	return c;

            }
            rs.close();
            stmt.close();
            
            conn.close();
        } catch (SQLException se) {
            // Errore durante l'apertura della connessione
            se.printStackTrace();
        } catch (Exception e) {
            // Errore nel loading del driver
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
            } catch (SQLException se2) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        return null;
	}
	
	
	
	
public static Cliente esisteCliente(String username, String pwd) {
		
		Statement stmt = null;
        Connection conn = null;
        Cliente cl = null;
        
        try {
        	
        	String sql = "SELECT C.`username`, C.`farmacia associata`, C.`punti`, C.`livello`, U.`password`, U.`email` " + "FROM `Cliente` C join `Utenti` U  on C.`username` = U.`username` where C.`username` = '" + username + "' and U.`password` = '" + pwd + "';";
           
        	
        	Class.forName(DRIVER_CLASS_NAME);
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            
   
            ResultSet rs = stmt.executeQuery(sql);
           
            if (rs.first()) {		// rs non vuoto --> esiste l'utente cercato  
            	// � giusto creare qui la farmacia? mi serve veramente ?
            	cl = new Cliente(rs.getString("username"), rs.getString("password"), rs.getString("email"), rs.getString("farmacia associata"), rs.getInt("punti"), rs.getInt("livello"));
            	rs.close();
            	stmt.close();
            	conn.close();
            	return cl;
            	
            } else {
            	
            	rs.close();
            	stmt.close();
            	conn.close();
            	return null;
            }
            
        } catch (SQLException se) {
            // Errore durante l'apertura della connessione
            se.printStackTrace();
        } catch (Exception e) {
            // Errore nel loading del driver
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
            } catch (SQLException se2) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        return null;
	}
	
	
	
	
}
