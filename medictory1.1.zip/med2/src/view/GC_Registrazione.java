package view;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import model.Farmacia;
import model.FarmaciaDAO;
import javafx.scene.Scene;
import controller.ControllerRegistrazione;

public class GC_Registrazione {
	
	
	
	
	
	@FXML
	private Button x;
	@FXML
	private Button farma;
	@FXML
	private TextField username;
	@FXML
	private PasswordField password;
	@FXML
	private TextField email;
	@FXML
	private TextField scelta;
	@FXML
	private Button done;
	@FXML
	private TableView<ModelTable> table;
	@FXML
	private TableColumn<ModelTable, String> username_col;
	@FXML
	private TableColumn<ModelTable, String> name_col;
	@FXML
	private TableColumn<ModelTable, String> indirizzo_col;
	
	private void setPrimaryStage(Stage primaryStage, String file) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource(file));
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	@FXML
	public void xPressed(ActionEvent event) {
		
        Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "progetto.fxml");
	}
	
	
	@FXML
	public void farmaPressed(ActionEvent event) {
		
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "Registrazione_farma.fxml");
	}
	

	@FXML
	public void tableStart() {
		
		ObservableList<ModelTable> list = FXCollections.observableArrayList();
		username_col.setCellValueFactory(new PropertyValueFactory<>("Username"));
		name_col.setCellValueFactory(new PropertyValueFactory<>("Nome"));
		indirizzo_col.setCellValueFactory(new PropertyValueFactory<>("Indirizzo"));
		
		list = FarmaciaDAO.popolaRegistazione(list);
		table.setItems(list);
	}
	
	
	@FXML
	public void donePressed(ActionEvent event) {
		String u;
		String p;
		String e;
		String s;
		
		u = username.getText();
		p = password.getText();
		e = email.getText();
		s = scelta.getText();
		
		if(ControllerRegistrazione.registraCliente(u, p, e, s)) {
			
			Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
			setPrimaryStage(primaryStage, "progetto.fxml");
			GC_Ok o = new GC_Ok();
			o.mostrati();
		}
		else {
			u = "";
			p = "";
			e = "";
			s = "";
			
			Stage stage = (Stage) done.getScene().getWindow();
			stage.close();
			Stage primaryStage = new Stage();
			setPrimaryStage(primaryStage, "Registrazione.fxml");
	
			GC_Errore g = new GC_Errore();
			g.mostrati();
			
		}
		
	}
	
}
