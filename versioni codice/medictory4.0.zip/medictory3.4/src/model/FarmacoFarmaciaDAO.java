package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class FarmacoFarmaciaDAO {
	
	private static AbstractFactory factory = new FactoryElementoFarmacia();
	private static Connector connector = Connector.getConnectorInstance();
	
	
	public static void pharmacyMedicinePersistence(SessioneFarmacia s) {
		 ArrayList <FarmacoFarmacia> farmaci = null;
		 Connection conn= connector.getConnection();
		 Statement stmt = null;
		
		 try {
			 if (s.getFarmaci() == null) return;
			 farmaci = s.getFarmaci();
			 for (FarmacoFarmacia f : farmaci) {
				 if (f.isAddedRuntime() == true) {   
				    String sql1 = "INSERT INTO  `farmaco farmacia` VALUES ('" + f.getNome() +"','" + s.getUsername() + "','" + f.getScadenza() + "','" + f.getDescrizione() + "','" + f.getQuantita() + "');";
				    
				    stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

				    stmt.executeUpdate(sql1);
				    
				 }
				 else if (f.isChanged()== true) {
					 String sql1 = "UPDATE `farmaco farmacia` F SET F.`descrizione`= '" + f.getDescrizione() +"', F.`quantitativo` = '" + f.getQuantita() + "' WHERE F.`possessore` = '" + s.getUsername() + "' AND F.`farmaco`='" + f.getNome() + "' AND F.`scadenza`='" + f.getScadenza() + "';";
					 stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

					 stmt.executeUpdate(sql1);
					 
				 }
			 }
		    	
		    } catch (SQLException se) {
		        // Errore durante l'apertura della connessione
		        se.printStackTrace();
		    } catch (Exception e) {
		        // Errore nel loading del driver
		        e.printStackTrace();
		    } finally {
		        try {
		            if (stmt != null)
		                stmt.close();
		   
		        } catch (SQLException se2) {
		        }
		        try {
		            if (conn != null)
		                conn.close();
		        } catch (SQLException se) {
		            se.printStackTrace();
		        }
		    }
	}
	
	
	public static ArrayList<FarmacoFarmacia>  myFarmaciFarmacia (String username) {
		
		Statement stmt = null;
		
		Connection conn= connector.getConnection();
  
	    ArrayList<FarmacoFarmacia> farmaci = null;
	   
    
	    try {
	    	//String sql = "SELECT * FROM (SELECT `farmaco`, `descrizione`, `scadenza`, `quantitativo` FROM `Farmaco Farmacia` WHERE `possessore`='" + username + "') as T1 JOIN (SELECT `farmaco`, sum(`quantitativo`) as totale FROM `Farmaco Farmacia`  WHERE  `possessore`='" + username + "'and `scadenza`> now()  group by `farmaco`) as T2 ON T1.`farmaco` = T2.`farmaco`;";
	    	String sql = "SELECT F.`farmaco`, F.`descrizione`,F.`scadenza`,F.`quantitativo` FROM `Farmaco Farmacia`F WHERE  F.`possessore`='" + username + "';";
	    	//String sql2 = "SELECT F.`farmaco`, sum(F.`quantitativo`) as totale FROM `Farmaco Farmacia`F WHERE  F.`possessore`='" + username + "'and F.`scadenza`> now()  group by  F.`farmaco`;";
	    	
	    	
	        stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
  
	        ResultSet rs = stmt.executeQuery(sql);
  
	        if (rs.first()) {
	        		rs.first();
        		farmaci = new ArrayList<FarmacoFarmacia>();
	        		do {
	        			FarmacoFarmacia farmaco= (FarmacoFarmacia)factory.creaFarmaco(rs.getString("farmaco"), rs.getString("descrizione"), rs.getString("scadenza"), rs.getInt("quantitativo"));
	        			//farmaco.setTotale(rs.getInt("totale"));
	        			farmaci.add(farmaco);
	        		} while(rs.next());
	        		rs.close();
	        	}
 
	    } catch (SQLException se) {
	        se.printStackTrace();
	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (stmt != null)
	                stmt.close();
	        } catch (SQLException se2) {
	        }
	        try {
	            if (conn != null)
	                conn.close();
	        } catch (SQLException se) {
	            se.printStackTrace();
	        }
	    }
	    return farmaci;
	}
}
