package view;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import model.Sessione;
import model.SessioneFarmacia;

import java.io.IOException;
import javafx.scene.Scene;

public class GC_PharmacyHomepage implements Graphic_Controller{
	@FXML
	private Button account, eventi, gestione, ritiro, risorse;
	
	private SessioneFarmacia sessione;
	
	
	private void setPrimaryStage(Stage primaryStage, String file, Button btn) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource(file));
			Parent root = loader.load();
			
			
			Graphic_Controller controller_next= loader.getController();
			controller_next.setData(sessione);
			
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
			}
		
	}	
	
	public void setData(Sessione farma) {
		this.sessione = (SessioneFarmacia) farma;
		
	}
	
	
	
	@FXML
	public void accountPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyAccount.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void eventiPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyEvent.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void gestionePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "GestioneFarmacie.fxml", (Button)event.getSource());
	}
	
	@FXML	//modifica
	public void ritiroPressed(ActionEvent event) {
		//Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		//setPrimaryStage(primaryStage, "progetto.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void risorsePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "RisorseFarmacia.fxml", (Button)event.getSource());
	}
}
