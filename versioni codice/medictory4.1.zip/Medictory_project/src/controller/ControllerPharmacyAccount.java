package controller;

import java.util.ArrayList;

import ingegnerizzazione.ListaClientiBean;
import ingegnerizzazione.ListaClientiModelTable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Cliente;
import model.SessioneFarmacia;
import view.GC_PharmacyAccount;

public class ControllerPharmacyAccount {
	private ArrayList<Cliente> clienti = null; 
	
	
	
	public ListaClientiBean findListOfCustomers(SessioneFarmacia sessione, GC_PharmacyAccount controllerGrafico) {
		
		ObservableList<ListaClientiModelTable> list = FXCollections.observableArrayList();
		
		if(clienti == null) {
			clienti = sessione.getClienti();
		}
		
		for(Cliente c: clienti) {
			list.add(new ListaClientiModelTable(c));
			c.attach(controllerGrafico);
		}

		return new ListaClientiBean(list);
		
	}
}
