package controller;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import ingegnerizzazione.PharmacyAllEventBean;
import ingegnerizzazione.PharmacyAllEventTableModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.AbstractState;
import model.Evento;
import model.SessioneFarmacia;
import model.StatoIniziale;
import model.SvolgimentoEvento;
import view.GC_PharmacyEvent;

public class ControllerPharmacyEvent {
	//private  PharmacyAllEventBean bean = new PharmacyAllEventBean(null);
	
	public Evento addEvent( GC_PharmacyEvent controllerGrafico, String nome, String dettagli, String premio, String inizio, String fine, int livello) {
		
		Evento ev = null;		
		Date oggi = new Date();
		
			
		try {
				
			SimpleDateFormat sdf = new  SimpleDateFormat("yyyy-MM-dd");
			Date scad = sdf.parse(inizio);
			if (scad.before(oggi)) return ev;
			
			} catch (ParseException e) {
		      e.printStackTrace();
			}
		
		ev = new Evento(nome, dettagli, premio, inizio, fine, livello);
		ev.setAddedRuntime(true);	
		ev.attach(controllerGrafico);
		/*if (bean.getEventi() == null) 
			bean.setEventi(FXCollections.observableArrayList());
		bean.getEventi().add(new PharmacyAllEventTableModel(e.getNome(), e.getDescrizione(),Integer.toString(e.getLivello_richiesto()), e.getPremio(), e.getInizio().toString() , e.getFine().toString()));
		System.out.println(bean.getEventi().size());*/
		ev.notifica();
		return ev;
	}
	
	
	public PharmacyAllEventBean findEvent(SessioneFarmacia sessione) {
		/*ObservableList<PharmacyAllEventTableModel> list = null;
		if (bean.getEventi() == null) {
			list = FXCollections.observableArrayList();
			bean.setEventi(list);
		}
		list = bean.getEventi();
		ArrayList<Evento> eventi = EventoDAO.allActiveEvents(sessione.getUsername()) ;
		if (eventi !=  null) {
			for(int i=0; i<eventi.size(); i++) {
				list.add(new PharmacyAllEventTableModel(eventi.get(i).getNome(), eventi.get(i).getDescrizione(),Integer.toString(eventi.get(i).getLivello_richiesto()),eventi.get(i).getPremio(), eventi.get(i).getInizio().toString() , eventi.get(i).getFine().toString())); 
			}
		}
			bean.setEventi(list);
		System.out.println(bean.getEventi().size());
		return bean*/		
		ObservableList<PharmacyAllEventTableModel> list = FXCollections.observableArrayList();

		ArrayList<Evento> eventi = sessione.getEventi() ;
		if (eventi ==  null) return null;
		for(int i=0; i<eventi.size(); i++) {
			AbstractState state = eventi.get(i).getState();
			if(state.getClass() == StatoIniziale.class || state.getClass() == SvolgimentoEvento.class){	
				list.add(new PharmacyAllEventTableModel(eventi.get(i).getNome(), eventi.get(i).getDescrizione(), Integer.toString(eventi.get(i).getLivello_richiesto()), eventi.get(i).getPremio(), eventi.get(i).getInizio() , eventi.get(i).getFine())); 
			}
		}
	
	return new PharmacyAllEventBean(list);	
	
	}
	
	
	
}
