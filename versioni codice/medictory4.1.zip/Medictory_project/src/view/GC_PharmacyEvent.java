package view;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.AbstractState;
import model.Evento;
import model.Sessione;
import model.SessioneFarmacia;
import model.StatoIniziale;

import java.io.IOException;
import java.util.ArrayList;

import controller.ControllerPharmacyEvent;
import ingegnerizzazione.Observable;
import ingegnerizzazione.Observer;
import ingegnerizzazione.PharmacyAllEventBean;
import ingegnerizzazione.PharmacyAllEventTableModel;
import javafx.scene.Scene;

public class GC_PharmacyEvent implements Graphic_Controller, Observer {
	
	
	@FXML
	private Button gestione, gestione2, ritiro, ritiro2, risorse, risorse2, account, account2, home, home2, allEvent, creaEvento, createEvent, elimina;
	@FXML
	private TextField nomeTf, dettagliTf, livelloTf, inizioTf, fineTf, premioTf, eliminaTf;
	@FXML
	private TableView<PharmacyAllEventTableModel> eventiTb;
	@FXML
	private TableColumn<PharmacyAllEventTableModel, String> eventoCol, descrizioneCol, requisitiCol, inizioCol, fineCol, premioCol;
	
	
	
	private SessioneFarmacia sessione;
	private ControllerPharmacyEvent controller = new ControllerPharmacyEvent();
	private boolean first = true;
	
	private void setPrimaryStage(Stage primaryStage, String file) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource(file));
			Parent root = loader.load();
			
			
			Graphic_Controller controller_next= loader.getController();
			controller_next.setData(sessione);
			
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
			}
		
	}	
	
	private void mostraErrore(String err) {
		try {
			
			Stage primaryStage = new Stage();
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Errore.fxml"));
			Parent root = loader.load();
			GC_Errore controller_next = loader.getController();
			controller_next.setError(err);
			primaryStage.initStyle(StageStyle.UNDECORATED);
			primaryStage.setScene(new Scene(root, 314, 209));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void setData(Sessione farma) {
		this.sessione = (SessioneFarmacia) farma;
		if (eventiTb != null) {
			if (first == true && farma.getEventi() != null) {
				for (Evento e : farma.getEventi()) {
					AbstractState state = e.getState();
					if(state.getClass() == StatoIniziale.class){
						e.attach(this);
				}	
			}
			first = false;
			}
			this.showResource();	
		}
	}

	@Override
	public void update( Observable e) {
		ArrayList<Evento> eventi = null;
		if(sessione.getEventi() != null) 
			eventi = sessione.getEventi();
		else eventi = new ArrayList<Evento>();
		
		if(!(eventi.contains((Evento)e))) {
			eventi.add((Evento)e);
			sessione.setEventi(eventi);
		}
		
	}
	

	
	
	public void showResource() {
		
		ObservableList<PharmacyAllEventTableModel> list = FXCollections.observableArrayList();
		eventoCol.setCellValueFactory(new PropertyValueFactory<PharmacyAllEventTableModel, String>("Evento"));
		descrizioneCol.setCellValueFactory(new PropertyValueFactory<PharmacyAllEventTableModel, String>("Descrizione"));
		requisitiCol.setCellValueFactory(new PropertyValueFactory<PharmacyAllEventTableModel, String>("Requisiti"));
		premioCol.setCellValueFactory(new PropertyValueFactory<PharmacyAllEventTableModel, String>("Premio"));
		inizioCol.setCellValueFactory(new PropertyValueFactory<PharmacyAllEventTableModel, String>("Inizio"));
		fineCol.setCellValueFactory(new PropertyValueFactory<PharmacyAllEventTableModel, String>("Fine"));
	
		if(sessione != null) {
			PharmacyAllEventBean bean = controller.findEvent(sessione);
			if (bean != null) {
			list = bean.getEventi();
			eventiTb.setItems(list);
			}
		}
	}
	
	
	
	@FXML
	public void gestionePressed(ActionEvent event) {
		
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "GestioneFarmacie.fxml");
	}
	
	@FXML
	public void gestione2Pressed(ActionEvent event) {
		
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "GestioneFarmacie.fxml");
	}
	
	@FXML
	public void risorsePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "RisorseFarmacia.fxml");
	}
	
	@FXML
	public void risorse2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "RisorseFarmacia.fxml");
	}
	
	@FXML
	public void allEventPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyAllEvent.fxml");
	}
	
	@FXML
	public void homePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepagePharmacy.fxml");
	}
	
	@FXML
	public void home2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepagePharmacy.fxml");
	}
	
	@FXML
	public void accountPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyAccount.fxml");
	}
	
	@FXML
	public void account2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyAccount.fxml");
	}
	
	
	@FXML
	public void creaPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyEvent.fxml");
	}
	
	@FXML
	public void createEventPressed() {
		String n = nomeTf.getText();
		String p = premioTf.getText();
		String d = dettagliTf.getText();
		String l = livelloTf.getText();
		String i = inizioTf.getText();
		String f = fineTf.getText();
		
		if(n.compareTo("") == 0 || p.compareTo("") == 0 || d.compareTo("") == 0 || l.compareTo("") == 0 || i.compareTo("") == 0 || f.compareTo("") == 0) {
			mostraErrore("Non hai inserito tutti i parametri");
		} else {
			if(controller.addEvent (this, n, d, p, i, f, Integer.parseInt(l)) == null) {
				mostraErrore("Non puoi inserire un evento iniziato");
			}
		}
		nomeTf.setText("");
		premioTf.setText("");
		dettagliTf.setText("");
		livelloTf.setText("");
		inizioTf.setText("");
		fineTf.setText("");
		
	}

	
}
