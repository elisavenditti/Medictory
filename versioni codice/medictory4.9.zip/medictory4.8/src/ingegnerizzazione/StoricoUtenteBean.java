package ingegnerizzazione;

import javafx.collections.ObservableList;

public class StoricoUtenteBean {
private ObservableList<StoricoUtenteTableModel> farmaci;
	
	public StoricoUtenteBean(ObservableList<StoricoUtenteTableModel> list) {
		this.setFarmaci(list);
	}

	public ObservableList<StoricoUtenteTableModel> getFarmaci() {
		return farmaci;
	}

	public void setFarmaci(ObservableList<StoricoUtenteTableModel> farmaci) {
		this.farmaci = farmaci;
	}
}
