package ingegnerizzazione;

import javafx.collections.ObservableList;

public class RiciclaggioUtenteBean {
	private ObservableList<RiciclaggioUtenteModelTable> farmaci;
	
	public RiciclaggioUtenteBean(ObservableList<RiciclaggioUtenteModelTable> list) {
		this.setFarmaci(list);
	}

	public ObservableList<RiciclaggioUtenteModelTable> getFarmaci() {
		return farmaci;
	}

	public void setFarmaci(ObservableList<RiciclaggioUtenteModelTable> farmaci) {
		this.farmaci = farmaci;
	}
}
