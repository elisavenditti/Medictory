package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connector {
	private static String USER = "root";
	private static String PASS = "";
	private static String DB_URL = "jdbc:mysql://localhost:3306/medictory?serverTimezone=Europe/Rome";
	private static String DRIVER_CLASS_NAME = "com.mysql.cj.jdbc.Driver";
	private static Connector connectorInstance=null;
	private Connection connection;
	
	public static Connector getConnectorInstance() {
		if (connectorInstance==null) {
			connectorInstance = new Connector();
			
		}
		return connectorInstance;
	}

	public Connection getConnection() {
		try {
			
        	Class.forName(DRIVER_CLASS_NAME);
        	connection = DriverManager.getConnection(DB_URL, USER, PASS);
           
            
            
        } catch (SQLException se) {
            // Errore durante l'apertura della connessione
            se.printStackTrace();
        } catch (Exception e) {
            // Errore nel loading del driver
            e.printStackTrace();
        } 
		return connection;
	}
		
}
