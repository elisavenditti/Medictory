package view;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.FarmacoFarmacia;
import model.Sessione;
import model.SessioneFarmacia;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;

import controller.ControllerPharmacyResource;
import ingegnerizzazione.Observable;
import ingegnerizzazione.Observer;
import ingegnerizzazione.RisorseFarmaciaBean;
import ingegnerizzazione.RisorseFarmaciaTableModel;
import javafx.scene.Scene;

public class GcPharmacyRisorse implements Graphic_Controller, Observer{
	
	@FXML
	private Button eventi;
	@FXML
	private Button ritiro;
	@FXML
	private Button gestione;
	@FXML
	private Button account;
	@FXML
	private Button home;
	@FXML
	private Button submit;
	@FXML
	private DatePicker scadenzaDp;
	@FXML
	private TableView<RisorseFarmaciaTableModel> risorseTb;
	@FXML
	private TableColumn<RisorseFarmaciaTableModel, String> farmacoCol;
	@FXML
	private TableColumn<RisorseFarmaciaTableModel, String> quantitativoCol;
	@FXML
	private TableColumn<RisorseFarmaciaTableModel, String> descrizioneCol;
	@FXML
	private TextField farmacoLb;
	@FXML
	private TextField quantitativoLb;
	@FXML
	private TextField scadenzaLb;
	@FXML
	private TextField descrizioneLb;
	
	
	private SessioneFarmacia sessione;
	private ControllerPharmacyResource controller = new ControllerPharmacyResource();
	
	
	
	private void setPrimaryStage(Stage primaryStage, String file) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource(file));
			Parent root = loader.load();
					
			Graphic_Controller controllerNext = loader.getController();
			controllerNext.setData(sessione);
			
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void mostraErrore(String err) {
		try {
			
			Stage primaryStage = new Stage();
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Errore.fxml"));
			Parent root = loader.load();
			GcErrore controllerNext = loader.getController();
			controllerNext.setError(err);
			primaryStage.initStyle(StageStyle.UNDECORATED);
			primaryStage.setScene(new Scene(root, 314, 209));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void showResource() {
		
		ObservableList<RisorseFarmaciaTableModel> list = FXCollections.observableArrayList();
		farmacoCol.setCellValueFactory(new PropertyValueFactory<RisorseFarmaciaTableModel, String>("Farmaco"));
		quantitativoCol.setCellValueFactory(new PropertyValueFactory<RisorseFarmaciaTableModel, String>("Quantitativo"));
		descrizioneCol.setCellValueFactory(new PropertyValueFactory<RisorseFarmaciaTableModel, String>("Descrizione"));
		
		
	
		if(sessione != null) {
			RisorseFarmaciaBean bean = controller.findResources(sessione);
			list = bean.getFarmaci();
			risorseTb.setItems(list);
		
		}
	}
	
	
	@FXML
	public void eventiPressed(ActionEvent event) {
		
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyEvent.fxml");
	}
	
	@FXML
	public void gestionePressed(ActionEvent event) {
		
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "GestioneFarmacie.fxml");
	}
	
	@FXML
	public void ritiroPressed(ActionEvent event) {
		
		
	}
	
	@FXML
	public void homePressed(ActionEvent event) {
		
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepagePharmacy.fxml");
	}
	@FXML
	public void accountPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyAccount.fxml");
	}
	
	@FXML
	public void submitPressed(ActionEvent event) {
		
		String f = farmacoLb.getText();
		String q = quantitativoLb.getText();
		String d = descrizioneLb.getText();
		LocalDate scade = scadenzaDp.getValue();
		
		if(f.compareTo("") != 0 && q.compareTo("") != 0 &&  d.compareTo("") == 0 &&  scade == null) {
			controller.cambiaQuantita(sessione, f, Integer.parseInt(q), this);
		}
		else if(f.compareTo("") == 0 || q.compareTo("") == 0 ||  d.compareTo("") == 0 ||  scade == null)  {
			mostraErrore("Non hai inserito tutti i parametri");
		}
		
		else {
			if (controller.addMedicine(sessione, this, f, Integer.parseInt(q) , d, scade.toString()) == null) 
				mostraErrore("Non puoi inserire un medicinale scaduto");
		}
		
		farmacoLb.setText("");
		quantitativoLb.setText("");
		descrizioneLb.setText("");
		scadenzaDp.setValue(null);
	}

	@Override
	public void setData(Sessione farmacia) {
		this.sessione = (SessioneFarmacia) farmacia;
		if(sessione.getFarmaci() != null) {
			for (FarmacoFarmacia f : sessione.getFarmaci()) {
				f.attach(this);
			}
		}
		this.showResource();
		
	}

	@Override
	public void update(Observable f) {
		ArrayList<FarmacoFarmacia> farmaci = null;
		if(sessione.getFarmaci() != null) 
			farmaci = sessione.getFarmaci();
		else farmaci = new ArrayList<FarmacoFarmacia>();
		
		if(!(farmaci.contains((FarmacoFarmacia)f))) {
			farmaci.add((FarmacoFarmacia)f);
			sessione.setFarmaci(farmaci);
		}
		showResource();
		
	}
	
}
