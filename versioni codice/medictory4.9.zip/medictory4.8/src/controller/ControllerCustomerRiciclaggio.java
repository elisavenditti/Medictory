package controller;

import java.util.ArrayList;

import ingegnerizzazione.RiciclaggioUtenteBean;
import ingegnerizzazione.RiciclaggioUtenteModelTable;
import ingegnerizzazione.StoricoUtenteBean;
import ingegnerizzazione.StoricoUtenteTableModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.FarmacoCliente;
import model.FarmacoClienteDAO;
import model.SessioneCliente;
import view.GcCustomerRiciclaggio;

public class ControllerCustomerRiciclaggio {
	public RiciclaggioUtenteBean findResources(SessioneCliente s) {
		int i;
	
		ObservableList<RiciclaggioUtenteModelTable> list = FXCollections.observableArrayList();
		
		ArrayList<FarmacoCliente> farmaci = s.getFarmaci();
		
		for(i=0; i<farmaci.size(); i++) {
			if(farmaci.get(i).getStato().compareTo("scaduto") == 0) {
				list.add(new RiciclaggioUtenteModelTable(farmaci.get(i).getNome(), farmaci.get(i).getDescrizione(), farmaci.get(i).getQuantita()));} 
		}
		
		return new RiciclaggioUtenteBean(list);
		
	}
	
	

	
	public StoricoUtenteBean findResourcesBis(SessioneCliente s) {
		int i;
	
		ObservableList<StoricoUtenteTableModel> list = FXCollections.observableArrayList();
		
		ArrayList<FarmacoCliente> farmaci = s.getFarmaci();
		
		for(i=0; i<farmaci.size(); i++) {
			if(farmaci.get(i).getStato().compareTo("verificato") == 0)
				list.add(new StoricoUtenteTableModel(farmaci.get(i).getNome(), farmaci.get(i).getDescrizione(), "\u2713")); 
			else if (farmaci.get(i).getStato().compareTo("smaltito") == 0 )
				list.add(new StoricoUtenteTableModel(farmaci.get(i).getNome(), farmaci.get(i).getDescrizione(), "\uD83D\uDD52"/*⌛❀✿ ┌∩┐(◣_◢)┌∩┐"*/)); 
		}
		
		
		return new StoricoUtenteBean(list);
		
	}
	
	
	public void ricicla(SessioneCliente s, String nomeFarmaco, GcCustomerRiciclaggio controllerGrafico) {
		for (FarmacoCliente f: s.getFarmaci()) {
			
			if(f.getNome().compareToIgnoreCase(nomeFarmaco) == 0) {
				
				if(f.getStato().compareTo("scaduto") == 0) {
					f.setStato("smaltito");
					FarmacoClienteDAO.scriviFarmacoClienteNelDb(f, s.getUsername());
					f.notifica();
					return;
				} else {
					controllerGrafico.mostraErrore("Il farmaco inserito non può essere smaltito");
					return;
					
				}
			}
		}
		controllerGrafico.mostraErrore("Farmaco non trovato");	
	}
	
	
	public void incrementaPunteggio(SessioneCliente s) {
	
		int livello;
		int punti;
		int deltaQta;
		int qta = 0; 
		
		//calcola gli eventuali incrementi nelle quantita' dopo il refresh
		
		if(s.getFarmaci() != null) {
			for(FarmacoCliente f: s.getFarmaci()) {

				if(f.getStato().compareTo("verificato") == 0) {
					qta += f.getQuantita();	
				}
			}
		}
		
		//se ci sono stati degli incrementi allora la farmacia ha 
		//verificato qualche farmaco quindi il punteggio del cliente si alza
		
		deltaQta = qta - s.getQtaVerificate();
		
		if(deltaQta>0) {				
			
			livello = s.getLivello();
			punti = s.getPunteggio();
						
			punti += 10*deltaQta;
			if(punti >= livello*100) {
							
				punti = punti-livello*100;				//azzero i punti
				livello += 1;							//aumento il livello
				s.setLivello(livello);
				
			}
						
			s.setPunteggio(punti);
			s.setQtaVerificate(qta);
		}
	}
}
