package controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import ingegnerizzazione.RisorseFarmaciaBean;
import ingegnerizzazione.RisorseFarmaciaTableModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.AbstractFactory;
import model.FactoryElementoFarmacia;
import model.FarmacoFarmacia;
import model.SessioneFarmacia;
import view.GC_PharmacyRisorse;

public class ControllerPharmacyResource {
	
	private AbstractFactory factory = new FactoryElementoFarmacia();
	
	
	
	
	public RisorseFarmaciaBean findResources(SessioneFarmacia s) {
		
		ArrayList<FarmacoFarmacia> farmaci = new ArrayList<>();
	    ObservableList<RisorseFarmaciaTableModel> list = null;			//devo mettere i farmaci qui ma devono essere raggruppati
		ArrayList<String> nomiPresenti = new ArrayList<>();
	    
	    if(s.getFarmaci() != null) {
			
			list = FXCollections.observableArrayList();
		    farmaci = s.getFarmaci();
		
			for(FarmacoFarmacia f: farmaci) {
				
				String farmacoCorrente = f.getNome();
				
				if(nomiPresenti.contains(farmacoCorrente)) {
					
					for(RisorseFarmaciaTableModel tm: list) {
						if(tm.getFarmaco().compareToIgnoreCase(farmacoCorrente) == 0) {
							int qta = f.getQuantita() + Integer.parseInt(tm.getQuantitativo());
							tm.setQuantitativo(Integer.toString(qta));
						}
					}
					
					
				} else {
					list.add(new RisorseFarmaciaTableModel(f.getNome(), Integer.toString(f.getQuantita()), f.getDescrizione())); 
					nomiPresenti.add(f.getNome());
				}
				
				
			}
		
		}
	    
	    
		return new RisorseFarmaciaBean(list);
	}
	
	
	
	
	
	public FarmacoFarmacia addMedicine(SessioneFarmacia s, GC_PharmacyRisorse controllerGrafico, String nome, int quantitativo,  String descrizione, String scadenza) {
		
		
		/*ArrayList<FarmacoFarmacia> farmaci = new ArrayList<FarmacoFarmacia>();
		if( s.getFarmaci() != null) {
			farmaci =  s.getFarmaci();
		}
		
		FarmacoFarmacia f = (FarmacoFarmacia) factory.creaFarmaco(nome, descr , scad, quantitativo);
		farmaci.add(f);
		s.setFarmaci(farmaci);				//update the list of medicines in the session
		
		f.attach(controllerGrafico);
		f.notifica();
		return true;*/
		FarmacoFarmacia f = null;
		
		Date oggi = new Date();
		
		
		try {
				
			SimpleDateFormat sdf = new  SimpleDateFormat("yyyy-MM-dd");
			Date scad = sdf.parse(scadenza);
			if (scad.before(oggi)) return f;
			
			} catch (ParseException e) {
		      e.printStackTrace();
			}
		
		f = (FarmacoFarmacia) factory.creaFarmaco(nome, descrizione, scadenza, quantitativo);
		f.setAddedRuntime(true);
		f.attach(controllerGrafico);
		f.notifica();
		
		return f;
	}
}
