package ingegnerizzazione;

public class EventiUtenteModelTable extends EventiUtenteAbstractModelTable{
	
	private String requisiti;
	
	
	public EventiUtenteModelTable(String e, String d, String r, String p, String di, String df) {
		this.evento=e;
		this.descrizione=d;
		this.requisiti=r;
		this.premio=p;
		this.dataInizio=di;
		this.dataFine=df;
	}



	public String getRequisiti() {
		return requisiti;
	}



	public void setRequisiti(String requisiti) {
		this.requisiti = requisiti;
	}


}
