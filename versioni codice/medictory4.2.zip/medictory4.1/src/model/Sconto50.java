package model;

public class Sconto50 extends Decorator {

	public Sconto50(Premiazione premiazione){
		this.prem=premiazione;
	}

	@Override
	public String premia() {
		return this.prem.premia()+ " con Sconto del 50%";
	}
	

}
