package controller;

import java.time.LocalDate;
import java.util.List;

import ingegnerizzazione.PharmacyAppuntamentiBean;
import ingegnerizzazione.PharmacyAppuntamentiTableModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Cliente;
import model.RitiroCliente;
import model.RitiroClienteDAO;
import model.SessioneFarmacia;


public class ControllerPharmacyAppuntamenti  {
	
	public PharmacyAppuntamentiBean findListOfRitiri(SessioneFarmacia sessione) {
		
		
		ObservableList<PharmacyAppuntamentiTableModel> list = FXCollections.observableArrayList();
		List<Cliente> clienti = sessione.getClienti();
	
		LocalDate currentDate = LocalDate.now();
		for(Cliente c: clienti) {
			List<RitiroCliente> ritiri= RitiroClienteDAO.myRitiriCliente(c.getUsername());
			
			if(ritiri != null) {
				for(RitiroCliente rc: ritiri) {
				
					if((rc.getData()).isAfter(currentDate)) {
						PharmacyAppuntamentiTableModel modelTable = new PharmacyAppuntamentiTableModel(c.getUsername(),rc.getEmail(),rc.getCitta(),rc.getIndirizzo(),rc.getData());
						list.add(modelTable);
					}
				}
			}
		}
		return new PharmacyAppuntamentiBean(list);
    }
}


	

 