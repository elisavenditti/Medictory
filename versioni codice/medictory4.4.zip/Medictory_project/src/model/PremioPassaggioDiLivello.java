package model;


public class PremioPassaggioDiLivello extends Premiazione {
	
	
	public PremioPassaggioDiLivello(String utente,String email) {
		super();
		this.utente=utente;
		this.email=email;
	}

	@Override
	public String premia() {
		
		return "Complimenti " + this.getUtente() + ", hai superato il livello.\n";
	}
	
}
