package model;

//Ongoing event

public class SvolgimentoEvento extends AbstractState{
	
	SvolgimentoEvento(Evento evento) {
		super(evento);
	}

	@Override
	public boolean addPartecipant(String username) {
		return true;
	}
    
	@Override
	public boolean setLivello_richiesto(int lv) {
		return false;
	}
    
	@Override
	public String getVincitore() {
		return "No winner: the event is still on going";
	}
    
	@Override
	public boolean setVincitore(String v) {
		return false;
	}
    
	@Override
	public boolean setFine(String f) {
		return false;
	}
    
	@Override
	public boolean setInizio(String i) {
		return false;
	}
    
	@Override
	public boolean setPremio(String premio) {
		return false;
	}
    
	@Override
	public boolean setDescrizione(String ds) {
		return false;
	}
    
	@Override
	public boolean setNome(String nome) {
		return false;
	}
    
	@Override
	public AbstractState nextState() {
		FineEvento f = new FineEvento(evento);
		return f;
	}

}
