package controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import ingegnerizzazione.RisorseUtenteBean;
import ingegnerizzazione.RisorseUtenteTableModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.AbstractFactory;
import model.FactoryElementoUtente;
import model.FarmacoCliente;
import model.SessioneCliente;
import view.GC_CustomerRisorse;

public class ControllerCustomerResource {
	private AbstractFactory factory = new FactoryElementoUtente();
	
	public RisorseUtenteBean findResources(SessioneCliente s) {
		int i;
	
		ObservableList<RisorseUtenteTableModel> list = FXCollections.observableArrayList();
		
		ArrayList<FarmacoCliente> farmaci = s.getFarmaci();
		
		for(i=0; i<farmaci.size(); i++) {
			if(farmaci.get(i).getStato().compareTo("utilizzabile") == 0)
				list.add(new RisorseUtenteTableModel(farmaci.get(i).getNome(), farmaci.get(i).getDescrizione(), farmaci.get(i).getQuantita(), farmaci.get(i).getScadenza())); 
		}
		
		return new RisorseUtenteBean(list);
	}
	
		
	public void modifyAmount(SessioneCliente s, String farma, int quantitativo) {
		ArrayList<FarmacoCliente> farmaci = s.getFarmaci();
		for (FarmacoCliente f : farmaci) {
			if(f.getNome().compareToIgnoreCase(farma)==0) {
				f.setQuantita(f.getQuantita() + quantitativo);
				f.setChanged(true);
				f.notifica();	
			}
		}
	}
	
	public FarmacoCliente addMedicine(GC_CustomerRisorse controllerGrafico, String nome, String descrizione, String scadenza, int quantitativo) {

		FarmacoCliente f = null;
		
		Date oggi = new Date();
		
		
		try {
				
			SimpleDateFormat sdf = new  SimpleDateFormat("yyyy-MM-dd");
			Date scad = sdf.parse(scadenza);
			if (scad.before(oggi)) return f;
			
			} catch (ParseException e) {
		      e.printStackTrace();
			}
		
		f = (FarmacoCliente) factory.creaFarmaco(nome, descrizione, scadenza, quantitativo);
		f.setStato("utilizzabile");
		f.setAddedRuntime(true);
		f.attach(controllerGrafico);
		f.notifica();
		
		return f;
	}
}
