package controller;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;

import ingegnerizzazione.PharmacyAllEventBean;
import ingegnerizzazione.PharmacyAllEventTableModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.AbstractState;
import model.Cliente;
import model.Coupon;
import model.Evento;
import model.EventoDAO;
import model.FineEvento;
import model.Premiazione;
import model.PremioVincitaEvento;
import model.SessioneFarmacia;
import model.StatoIniziale;
import model.SvolgimentoEvento;
import view.GC_PharmacyEvent;

public class ControllerPharmacyEvent implements Runnable {
	private String vincitore;
	private String emailCliente;
	
	
	public void premiazione (SessioneFarmacia s) {
		ArrayList<Cliente> infoPartecipanti =null;
		ArrayList<Evento> eventi = null;
		if(s.getEventi()== null) return;
			eventi = s.getEventi();
			for (Evento e: eventi) {
				AbstractState state = e.getState();
			    if(state.getClass() == FineEvento.class && e.getVincitore() == null){	
			    	infoPartecipanti = EventoDAO.findPartecipants(e.getNome(),s.getUsername());
			    	if (infoPartecipanti != null) {
			    		Random r = new Random();
			    		int dimensione = infoPartecipanti.size();
			    		int selected = r.nextInt(dimensione);
				    	this.vincitore = infoPartecipanti.get(selected).getUsername();
						this.emailCliente = infoPartecipanti.get(selected).getEmail();
						e.setPremio("Coupon");
						e.setVincitore(vincitore);
						e.setChanged(true);
						e.notifica();
						new Thread(this).start();
			    	}
			    	
			    }	
			}
			
	}
	
	@Override
	public void run() {
		Premiazione p;
		Coupon coupon;
		p = new PremioVincitaEvento(vincitore, emailCliente);
		coupon = new Coupon(p);
		System.out.println(coupon.premia());
		
	}
	
	
	public void deleteEvent (GC_PharmacyEvent observer, SessioneFarmacia s, String nomeEvento) {
		if (s.getEventi() == null) return;
		ArrayList<Evento> eventi = s.getEventi();
		for (Evento e : eventi) {
			if (e.getNome().compareToIgnoreCase(nomeEvento)==0) { //Data la farmacia il nome evento � unico
				e.setDeleted(true);
				e.attach(observer);
				e.notifica();
			}
		}	
	}
	
	
	
	public Evento addEvent( GC_PharmacyEvent controllerGrafico, SessioneFarmacia sessione, String nome, String dettagli, String premio, String inizio, String fine, int livello) {
		
		Evento ev = null;		
		Date oggi = new Date();
		
			
		try {
				
			SimpleDateFormat sdf = new  SimpleDateFormat("yyyy-MM-dd");
			Date scad = sdf.parse(inizio);
			if (scad.before(oggi)) return ev;
			
			} catch (ParseException e) {
		      e.printStackTrace();
			}
		
		ev = new Evento(nome, dettagli, premio, inizio, fine, livello);
		
		ev.setAddedRuntime(true);	
		ev.attach(controllerGrafico);
		sessione.getEventi().add(ev);
		ev.notifica();
		return ev;
	}
	
	
	public PharmacyAllEventBean findEvent(SessioneFarmacia sessione) {	
		ObservableList<PharmacyAllEventTableModel> list = FXCollections.observableArrayList();

		ArrayList<Evento> eventi = sessione.getEventi() ;
		if (eventi ==  null) return null;
		for(int i=0; i<eventi.size(); i++) {
			AbstractState state = eventi.get(i).getState();
			if(eventi.get(i).isDeleted()) {}
			
			else if(state.getClass() == StatoIniziale.class || state.getClass() == SvolgimentoEvento.class){	
				list.add(new PharmacyAllEventTableModel(eventi.get(i).getNome(), eventi.get(i).getDescrizione(), Integer.toString(eventi.get(i).getLivello_richiesto()), eventi.get(i).getPremio(), eventi.get(i).getInizio() , eventi.get(i).getFine())); 
			}
		}
	
	return new PharmacyAllEventBean(list);	
	
	}
	
	
	
}
