package model;

import java.util.ArrayList;

public class Farmacia extends Utente{
	private String nome;
	private String indirizzo;
	private ArrayList<FarmacoFarmacia> farmaci;
	private ArrayList<EventoFarmacia> eventi;
	private ArrayList<Cliente> clienti;
	
	public Farmacia(String user, String pwd, String em) {
		
		super(user, pwd, em);
		
	}
	
	public ArrayList<FarmacoFarmacia> getFarmaci() {
		return farmaci;
	}

	public void setFarmaci(ArrayList<FarmacoFarmacia> farmaci) {
		this.farmaci = farmaci;
	}

	public ArrayList<EventoFarmacia> getEventi() {
		return eventi;
	}

	public void setEventi(ArrayList<EventoFarmacia> eventi) {
		this.eventi = eventi;
	}

	public void setNome(String name){
		this.nome = name;
	}
	public void setIndirizzo(String i){
		this.indirizzo = i;
	}
	
	public String getNome(){
		return this.nome;
	}
	public String getIndirizzo(){
		return this.indirizzo;
	}

	public ArrayList<Cliente> getClienti() {
		return clienti;
	}

	public void setClienti(ArrayList<Cliente> clienti) {
		this.clienti = clienti;
	}

}
