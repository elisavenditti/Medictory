package view;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import model.SessioneCliente;
import controller.ControllerLogin;

import java.io.IOException;
import javafx.scene.Scene;

public class GC_CustomerLogin{
	
	@FXML
	private Button backButton;
	@FXML
	private Button loginButton;
	@FXML
	private TextField username;
	@FXML
	private PasswordField password;
	
	private void setPrimaryStage(Stage primaryStage, String file) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource(file));
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}	
	
	private void mostraErrore(String err) {
		try {
			
			Stage primaryStage = new Stage();
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Errore.fxml"));
			Parent root = loader.load();
			GC_Errore controller_next = loader.getController();
			controller_next.setError(err);
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 314, 209));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public void loginPressed(ActionEvent event){
		
		String s1, s2;
		s1 = username.getText();
		s2 = password.getText();
		
		
		
		
		
		ControllerLogin controller_attuale = new ControllerLogin();		
		SessioneCliente s = controller_attuale.loginCliente(s1, s2);
		
			if(s == null) {
				s1 = "";
				s2 = "";	
				mostraErrore("Dati inseriti scorretti, riprovare");
				
			} else {
				
				try {
					Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
					primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
						
						public void handle (WindowEvent event) {
							try {
								Stage primaryStage = new Stage();	
								FXMLLoader loader = new FXMLLoader(getClass().getResource("Exit.fxml"));
								Parent root = loader.load();
								GC_Exit controllerNext = loader.getController();
								primaryStage.setTitle("Medictory");
								primaryStage.setScene(new Scene(root, 314, 209));
								primaryStage.show();
								controllerNext.setData(s,0);
							} catch(IOException e) {
								e.printStackTrace();
							}			
						}
					});
					FXMLLoader loader = new FXMLLoader(getClass().getResource("HomepageClient.fxml"));
					Parent root = loader.load();
					GC_CustomerHomepage controller_next = loader.getController();
					controller_next.setData(s);
					primaryStage.setTitle("Medictory");
					primaryStage.setScene(new Scene(root, 600,400));
					primaryStage.show();
				} catch(IOException e) {
					e.printStackTrace();
					}
			}
	}
	
	public void backPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "progetto.fxml");
	}

}
