package controller;

import java.util.List;

import ingegnerizzazione.ListaClientiBean;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Cliente;
import model.SessioneFarmacia;
import view.GcPharmacyAccount;

public class ControllerPharmacyAccount {
	private List<Cliente> clienti = null; 
	
	
	
	public ObservableList<ListaClientiBean> findListOfCustomers(SessioneFarmacia sessione, GcPharmacyAccount controllerGrafico) {
		
		ObservableList<ListaClientiBean> list = FXCollections.observableArrayList();
		
		if(clienti == null) {
			clienti = sessione.getClienti();
		}
		
		for(Cliente c: clienti) {
			list.add(new ListaClientiBean(c));
			c.attach(controllerGrafico);
		}

		return list;
		
	}
}
