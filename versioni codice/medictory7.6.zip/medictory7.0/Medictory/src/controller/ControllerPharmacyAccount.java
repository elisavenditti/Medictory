package controller;

import java.util.ArrayList;
import java.util.List;

import ingegnerizzazione.ListaClientiBean;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Cliente;
import model.SessioneFarmacia;
import view.GcPharmacyAccount;

public class ControllerPharmacyAccount {
	private List<Cliente> clienti = null; 
	
	
	
	public List<ListaClientiBean> findListOfCustomers(SessioneFarmacia sessione/*, GcPharmacyAccount controllerGrafico*/) {
		
		ArrayList<ListaClientiBean> list = new ArrayList<>();
		
		if(clienti == null) {
			clienti = sessione.getClienti();
		}
		
		for(Cliente c: clienti) {
			list.add(new ListaClientiBean(c));
			//c.attach(controllerGrafico);
		}

		return list;
		
	}
}
