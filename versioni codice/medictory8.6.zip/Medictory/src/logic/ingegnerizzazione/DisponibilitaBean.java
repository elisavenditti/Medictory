package logic.ingegnerizzazione;

public class DisponibilitaBean {
	private String numero;
	
	public DisponibilitaBean(String n) {
		this.numero = n;
	}
	
	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}
	
}
