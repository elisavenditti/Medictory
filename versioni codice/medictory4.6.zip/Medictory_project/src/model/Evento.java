package model;

import ingegnerizzazione.Observer;

public interface Evento {
	 public void nextState();
	 public boolean addPartecipant(String username);
	 public boolean setLivelloRichiesto(int livelloRichiesto);
	 public String getVincitore();

	 public boolean setVincitore(String vincitore);		
	 public boolean setFine(String fine);
	 public boolean setInizio(String inizio);
	 public boolean setPremio(String premio);
	 public boolean setDescrizione(String descrizione);
	 public boolean setNome(String nome);		
	 public AbstractState getState();
	 public String getNome();
	 public String getPremio();
	 public String getDescrizione();
	 public String getFine();
	 public int getLivelloRichiesto();
	 public String getInizio();
	 public void attach(Observer observer);
	 public void detach(Observer observer);
	 public void notifica();
}
