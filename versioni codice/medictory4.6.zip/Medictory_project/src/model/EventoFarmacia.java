package model;

import java.util.ArrayList;


import ingegnerizzazione.Observable;
import ingegnerizzazione.Observer;


public class EventoFarmacia implements Observable, Evento {
	private AbstractState state;
	private ArrayList<Observer> observers = new ArrayList<>();
	private String nome, descrizione, premio, inizio, fine;
	private String vincitore = null;
    private int livello_richiesto;
    private boolean addedRuntime = false; //E' solo per la farmacia
    private boolean changed = false;
    private boolean deleted = false; // E' solo per la farmacia
   // private List<String> partecipanti = new ArrayList<>();

    public EventoFarmacia(String nome, String descrizione, String premio, String inizio, String fine, int lv) {
        this.state = new StatoIniziale(this);
        this.setNome(nome);
        this.descrizione = descrizione;
        this.premio = premio;
        this.livello_richiesto = lv;
        this.inizio = inizio;
        this.fine = fine;
        
    }
    
    /********************* FUNZIONI CHE CAMBIANO IMPLEMENTAZIONE IN BASE ALLO STATO ***********************************/
    
    @Override
    public void nextState() {
        this.state = this.state.nextState();
    }
    
  
	/*public boolean addPartecipant(String username) {
    	if(state.addPartecipant(username) == true) {
    		this.partecipanti.add(username);
    		return true;
    	}
    	else return false;
    }*/
    
    //@Override
    public boolean setLivelloRichiesto(int livello_richiesto) {
		if( state.setLivello_richiesto(livello_richiesto) == true) {
			this.livello_richiesto = livello_richiesto;
			return true;
		}
		else return false;
	}
    
    //@Override
    public String getVincitore() {
    	if (state.getVincitore().compareTo("OK")==0) return this.vincitore;
    	else return "No winner";
	}
    
   // @Override
	public boolean setVincitore(String vincitore) {
		if( state.setVincitore(vincitore) == true) {
			this.vincitore = vincitore;
			return true;
		}
		else return false;
	}
    
   // @Override
	public boolean setFine(String fine) {
		if( state.setFine(fine) == true) {
			this.fine = fine;
			return true;
		}
		else return false;
	}
    
    //@Override
	public boolean setInizio(String inizio) {
		
		if(state.setInizio(inizio) == true) {
			this.inizio = inizio;
			return true;
		}
		else return false;
	}
	
   // @Override
	public boolean setPremio(String premio) {
		if(state.setPremio(premio) == true) {
			this.premio = premio;
			return true;
		}
		else return false;
	}
    
   // @Override
	public boolean setDescrizione(String descrizione) {
		if( state.setDescrizione(descrizione) == true) {
			this.descrizione = descrizione;
			return true;
		}
		else return false;
	}
    
    //@Override
	public boolean setNome(String nome) {
		if( state.setNome(nome) == true) {
			this.nome = nome;
			return true;
		}
		else return false;
	}
	
    
	public boolean setDeleted(boolean deleted) {
		
		if(state.setDeleted(deleted)) {
			this.deleted = deleted;
			return true;
		}
		return false;

	}
	
	
	/********************* NON CAMBIANO IN BASE ALLO STATO *****************************************/
	@Override
	public AbstractState getState() {
        return state;
    }
	
	@Override
	public String getNome() {
		return nome;
	}
	
	@Override
	public String getPremio() {
		return premio;
	}
	
	@Override
	public String getDescrizione() {
		return descrizione;
	}
	
	@Override
	public String getFine() {
		return fine;
	}
	
	@Override
	public int getLivelloRichiesto() {
		return livello_richiesto;
	}
	@Override
	public String getInizio() {
		return inizio;
	}

	@Override
	public void attach(Observer observer){   
		if (!observers.contains(observer))
			observers.add(observer);		
	}
	
	@Override
	public void detach(Observer observer) {
		observers.remove(observer);
		
	}
	@Override
	public void notifica(){
	    for (Observer observer : observers) {
	       observer.update(this);
	    }

	}
	
	public boolean isAddedRuntime() {
			return addedRuntime;
	}

	public void setAddedRuntime(boolean addedRuntime) {
		this.addedRuntime = addedRuntime;
	}

	public boolean isChanged() {
		return changed;
	}

	public void setChanged(boolean changed) {
		this.changed = changed;
	}

	public boolean isDeleted() {
		return deleted;
	}

}

