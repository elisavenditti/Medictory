package model;


public abstract class AbstractState/*State*/ {
	protected Evento evento;
	
	public AbstractState(Evento evento2) {
		this.evento= evento2;
		
	}
	
	

	 public abstract boolean addPartecipant(String username);
	 public abstract boolean setLivello_richiesto(int lv);
	 public abstract String getVincitore();
	 public abstract boolean setVincitore(String v);
	 public abstract boolean setFine(String f);
	 public abstract boolean setInizio(String i);
	 public abstract boolean setPremio(String premio);
  	 public abstract boolean setDescrizione(String ds);
	 public abstract boolean setNome(String nome);
	 public abstract boolean setJoined(Boolean bool);
	 public abstract boolean setDeleted(Boolean bool);
	 public abstract AbstractState nextState();


	
    
}
