package model;

public class AnalisiGratis extends Decorator {

	public AnalisiGratis(Premiazione premiazione) {
		this.prem=premiazione;
	}

	@Override
	public String premia() {
		return this.prem.premia() + " con Analisi gratis";
	}

}
