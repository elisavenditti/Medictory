package ingegnerizzazione;

import javafx.collections.ObservableList;

public class PharmacyAllEventBean {
	
	private ObservableList<PharmacyAllEventTableModel> eventi;
		
	public PharmacyAllEventBean(ObservableList<PharmacyAllEventTableModel> list) {
		this.setEventi(list);
	}

	public ObservableList<PharmacyAllEventTableModel> getEventi() {
		return this.eventi;
	}

	public void setEventi(ObservableList<PharmacyAllEventTableModel> eventi) {
		this.eventi = eventi;
	}
}

