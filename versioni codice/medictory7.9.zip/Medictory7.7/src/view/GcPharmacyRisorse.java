package view;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.FarmacoFarmacia;
import model.Sessione;
import model.SessioneFarmacia;
import java.io.IOException;
import java.time.LocalDate;
import controller.ControllerPharmacyResource;
import ingegnerizzazione.Feedback;
import ingegnerizzazione.InputException;
import ingegnerizzazione.Observer;
import ingegnerizzazione.RisorseFarmaciaBean;
import javafx.scene.Scene;

public class GcPharmacyRisorse implements GraphicController, Observer{
	
	@FXML
	private Button eventi;
	@FXML
	private Button ritiro;
	@FXML
	private Button gestione;
	@FXML
	private Button account;
	@FXML
	private Button home;
	@FXML
	private Button submit;
	@FXML
	private DatePicker scadenzaDp;
	@FXML
	private TableView<RisorseFarmaciaBean> risorseTb;
	@FXML
	private TableColumn<RisorseFarmaciaBean, String> farmacoCol;
	@FXML
	private TableColumn<RisorseFarmaciaBean, String> quantitativoCol;
	@FXML
	private TableColumn<RisorseFarmaciaBean, String> descrizioneCol;
	@FXML
	private TextField farmacoLb;
	@FXML
	private TextField quantitativoLb;
	@FXML
	private TextField scadenzaLb;
	@FXML
	private TextField descrizioneLb;
	
	
	private SessioneFarmacia sessione;
	
	private ControllerPharmacyResource controller = new ControllerPharmacyResource();
	
	
	
	private void setPrimaryStage(Stage primaryStage, String file) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource(file));
			Parent root = loader.load();
					
			GraphicController controllerNext = loader.getController();
			controllerNext.setData(sessione);
			
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public void showResource() {
		
		ObservableList<RisorseFarmaciaBean> list = FXCollections.observableArrayList();
		farmacoCol.setCellValueFactory(new PropertyValueFactory<>("Farmaco"));
		quantitativoCol.setCellValueFactory(new PropertyValueFactory<>("Quantitativo"));
		descrizioneCol.setCellValueFactory(new PropertyValueFactory<>("Descrizione"));
		
		
	
		if(sessione != null) {
			list.addAll(controller.findResources(sessione));
			risorseTb.setItems(list);
		
		}
	}
	
	
	@FXML
	public void eventiPressed(ActionEvent event) {
		
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyEvent.fxml");
	}
	
	@FXML
	public void gestionePressed(ActionEvent event) {
		
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "GestioneFarmacie.fxml");
	}
	
	@FXML
	public void ritiroPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "FarmaciaAppuntamento.fxml");
		
	}
	
	@FXML
	public void homePressed(ActionEvent event) {
		
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepagePharmacy.fxml");
	}
	@FXML
	public void accountPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyAccount.fxml");
	}
	
	@FXML
	public void submitPressed(ActionEvent event) {
		
		String f = farmacoLb.getText();
		String q = quantitativoLb.getText();
		String d = descrizioneLb.getText();
		LocalDate scade = scadenzaDp.getValue();
		try {
			if(f.compareTo("") != 0 && q.compareTo("") != 0 &&  d.compareTo("") == 0 &&  scade == null) {
				controller.cambiaQuantita(sessione, f, Integer.parseInt(q));
			}
			else if(f.compareTo("") == 0 || q.compareTo("") == 0 ||  d.compareTo("") == 0 ||  scade == null)  {
				throw new InputException("Non hai inserito tutti i parametri");
			}
			else {
				FarmacoFarmacia newF =controller.addMedicine(sessione, f, Integer.parseInt(q) , d, scade.toString());
				newF.attach(this);
				newF.notifica();
			}
		}catch(InputException ex) {
			Feedback.mostraErrore(ex.getMessage());
		}
		
		farmacoLb.setText("");
		quantitativoLb.setText("");
		descrizioneLb.setText("");
		scadenzaDp.setValue(null);
	}

	@Override
	public void setData(Sessione farmacia) {
		this.sessione = (SessioneFarmacia) farmacia;
		if(sessione.getFarmaci() != null) {
			for (FarmacoFarmacia f : sessione.getFarmaci()) {
				f.attach(this);
			}
		}
		this.showResource();
		
	}

	@Override
	public void update() {
		showResource();
		
	}
	
}
