package test;

import static org.junit.Assert.assertThrows;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import logic.controller.ControllerPharmacyEvent;
import logic.ingegnerizzazione.DateException;
import logic.model.SessioneFarmacia;

public class TestControllerPharmacyEvent {
		// Test Case Ludovico 2
		private static final String NOME_EVENTO = "Natale";
		@Test 
		public void testControllerPharmacyEventAddMyEvent()  {
			ControllerPharmacyEvent c = new ControllerPharmacyEvent();
			 SessioneFarmacia sessione = new SessioneFarmacia("Ludovico",null,null,null);
			 List<String> informazioni = new ArrayList<>();
			 informazioni.add(NOME_EVENTO);
			 informazioni.add("ok");
			 informazioni.add("Coupon");
			 informazioni.add("2020-01-01");
			 informazioni.add("2021-01-01");
			 assertThrows(DateException.class,()-> c.addEvent(sessione, informazioni, 10));
			 
			 
		}
}
