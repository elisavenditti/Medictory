package controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import ingegnerizzazione.RisorseFarmaciaBean;
import ingegnerizzazione.RisorseFarmaciaTableModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.AbstractFactory;
import model.FactoryElementoFarmacia;
import model.FarmacoFarmacia;
import model.SessioneFarmacia;
import view.GC_PharmacyRisorse;

public class ControllerPharmacyResource {
	
	private AbstractFactory factory = new FactoryElementoFarmacia();
	
	public RisorseFarmaciaBean findResources(SessioneFarmacia s) {
		int i;
		
	
		ObservableList<RisorseFarmaciaTableModel> list = null;
		if(s.getFarmaci() != null) {
			//int somma;
			list = FXCollections.observableArrayList();
			ArrayList<FarmacoFarmacia> farmaci = s.getFarmaci();
		
			for(i=0; i<farmaci.size(); i++) {
				/*somma = 0;
				for (int j=0; j < farmaci.size();j++) {
					if (farmaci.get(i).getNome().compareTo(farmaci.get(j).getNome())==0)
						somma +=  farmaci.get(i).getQuantita();
					
				}*/
				list.add(new RisorseFarmaciaTableModel(farmaci.get(i).getNome(), Integer.toString(farmaci.get(i).getQuantita()), farmaci.get(i).getDescrizione())); 
			}
		
		}
		return new RisorseFarmaciaBean(list);
	}
	
	
	public FarmacoFarmacia addMedicine(SessioneFarmacia s, GC_PharmacyRisorse controllerGrafico, String nome, int quantitativo,  String descrizione, String scadenza) {
		
		
		/*ArrayList<FarmacoFarmacia> farmaci = new ArrayList<FarmacoFarmacia>();
		if( s.getFarmaci() != null) {
			farmaci =  s.getFarmaci();
		}
		
		FarmacoFarmacia f = (FarmacoFarmacia) factory.creaFarmaco(nome, descr , scad, quantitativo);
		farmaci.add(f);
		s.setFarmaci(farmaci);				//update the list of medicines in the session
		
		f.attach(controllerGrafico);
		f.notifica();
		return true;*/
		FarmacoFarmacia f = null;
		
		Date oggi = new Date();
		
		
		try {
				
			SimpleDateFormat sdf = new  SimpleDateFormat("yyyy-MM-dd");
			Date scad = sdf.parse(scadenza);
			if (scad.before(oggi)) return f;
			
			} catch (ParseException e) {
		      e.printStackTrace();
			}
		
		f = (FarmacoFarmacia) factory.creaFarmaco(nome, descrizione, scadenza, quantitativo);
		f.setAddedRuntime(true);
		f.attach(controllerGrafico);
		f.notifica();
		
		return f;
	}
}
