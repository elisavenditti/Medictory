package controller;

import java.util.ArrayList;

import ingegnerizzazione.EventiUtenteAbstractModelTable;
import ingegnerizzazione.EventiUtenteBean;
import ingegnerizzazione.EventiUtenteModelTable;
import ingegnerizzazione.MyEventiUtenteBean;
import ingegnerizzazione.MyEventiUtenteModelTable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.AbstractState;
import model.Evento;
import model.EventoDAO;
import model.SessioneCliente;
import model.StatoIniziale;
import model.SvolgimentoEvento;

public class ControllerCustomerEvents {
	
	public MyEventiUtenteBean findEvents(SessioneCliente s) {
		ObservableList<EventiUtenteAbstractModelTable> list = FXCollections.observableArrayList();
		if (s.getEventi() == null) return null;
		ArrayList<Evento> eventi = s.getEventi() ;
	
		for(int i=0; i<eventi.size(); i++) {
			list.add(new MyEventiUtenteModelTable(eventi.get(i).getNome(), eventi.get(i).getDescrizione(), eventi.get(i).getPremio(), eventi.get(i).getInizio().toString() , eventi.get(i).getFine().toString())); 
		}
	
		return new MyEventiUtenteBean(list);
	}

	public EventiUtenteBean findAllActiveEvents(SessioneCliente sessione) {
		ObservableList<EventiUtenteAbstractModelTable> list = FXCollections.observableArrayList();

		ArrayList<Evento> eventi = EventoDAO.allActiveEvents(sessione.getFarmaciaAssociata()) ;
	
		for(int i=0; i<eventi.size(); i++) {
			AbstractState state = eventi.get(i).getState();
			if(state.getClass() == StatoIniziale.class || state.getClass() == SvolgimentoEvento.class){	
				list.add(new EventiUtenteModelTable(eventi.get(i).getNome(), eventi.get(i).getDescrizione(),Integer.toString(eventi.get(i).getLivello_richiesto()),eventi.get(i).getPremio(), eventi.get(i).getInizio().toString() , eventi.get(i).getFine().toString())); 
			}
		}
	
		return new EventiUtenteBean(list);
	}
}
