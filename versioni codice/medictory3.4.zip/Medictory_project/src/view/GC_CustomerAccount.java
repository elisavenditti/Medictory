package view;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Sessione;
import model.SessioneCliente;
import java.io.IOException;
import controller.ControllerCustomerAccount;
import controller.ControllerLogout;
import ingegnerizzazione.CustomerAccountBean;
import ingegnerizzazione.ListaFarmacieBean;
import ingegnerizzazione.ListaFarmacieModelTable;
import ingegnerizzazione.Observable;
import ingegnerizzazione.Observer;
import javafx.scene.Scene;

public class GC_CustomerAccount  implements Graphic_Controller, Observer {
	@FXML
	private Button farma, dati;
	@FXML
	private Button home, home2;
	@FXML
	private Button logout, logout2;
	@FXML
	private Label usernameLabel, emailLabel, farmaciaLabel, puntiLb, livelloLb, ptLabel, lvLabel;
	@FXML
	private TableView<ListaFarmacieModelTable> farmacieTb;
	@FXML
	private TableColumn<ListaFarmacieModelTable, String> usernameCol, nomeCol, emailCol, indirizzoCol;
	
	private SessioneCliente sessione;
	private ControllerCustomerAccount controller = new ControllerCustomerAccount();
	
	
	
	private void setPrimaryStage(Stage primaryStage, String file, Button btn) {
		try {
			
			FXMLLoader loader = new FXMLLoader(getClass().getResource(file));
			Parent root = loader.load();
			
			if(btn.getId().compareTo("logout") == 0 || btn.getId().compareTo("logout2") ==0) {
				ControllerLogout ControllerLogout = new ControllerLogout();
				ControllerLogout.makeDataClientPersistent(sessione);
			}
			else {
			Graphic_Controller controller_next = loader.getController();
			controller_next.setData(sessione);
			}
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
			
			
		} catch(IOException e) {
			e.printStackTrace();
			}
		
	}
	
	
	
	public void setData(Sessione cliente) {
		this.sessione = (SessioneCliente) cliente;
		if(farmacieTb != null)
			this.showResourceBis();
		else this.showResource();
		
	}
	
	@Override
	public void update(Observable subj) {
		if (puntiLb!=null) this.showResource();
		else this.showResourceBis();
		
	}
	
	public void showResource() {
		
		
		if(sessione != null) {
			CustomerAccountBean bean = new CustomerAccountBean(sessione);
		
			usernameLabel.setText(bean.getUsername());
			emailLabel.setText(bean.getEmail());
			farmaciaLabel.setText(bean.getFarmaciaAssociata());
			livelloLb.setText(bean.getLivello());
		
		
			String punti = bean.getPunti();
			String[] parts = puntiLb.getText().split("/");
			parts[0] = punti;
			puntiLb.setText(parts[0]+"/"+parts[1]);
		}
	}
	
	public void showResourceBis() {
		
		ObservableList<ListaFarmacieModelTable> list = FXCollections.observableArrayList();
		usernameCol.setCellValueFactory(new PropertyValueFactory<ListaFarmacieModelTable, String>("Username"));
		nomeCol.setCellValueFactory(new PropertyValueFactory<ListaFarmacieModelTable, String>("Nome"));
		indirizzoCol.setCellValueFactory(new PropertyValueFactory<ListaFarmacieModelTable, String>("Indirizzo"));
		emailCol.setCellValueFactory(new PropertyValueFactory<ListaFarmacieModelTable, String>("Email"));
		
		
		if(sessione != null) {
			ListaFarmacieBean bean = controller.findListOfPharmacy();
			list = bean.getFarmacie();
			farmacieTb.setItems(list);
		
		
			lvLabel.setText(Integer.toString(sessione.getLivello()));
			String punti = Integer.toString(sessione.getPunteggio());
			String[] parts = ptLabel.getText().split("/");
			parts[0] = punti;
			ptLabel.setText(parts[0]+"/"+parts[1]);
		}
		
	}
	
	@FXML
	public void datiPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerAccount.fxml",(Button)event.getSource());
	}
	
	@FXML
	public void farmaPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerAccountPage2.fxml",(Button)event.getSource());
	}

	@FXML
	public void homePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepageClient.fxml",(Button)event.getSource());
	}
	@FXML
	public void home2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepageClient.fxml",(Button)event.getSource());
	}
	
	@FXML
	public void logoutPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "progetto.fxml",(Button)event.getSource());
	}
	
	@FXML
	public void logout2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "progetto.fxml",(Button)event.getSource());
	}

}
