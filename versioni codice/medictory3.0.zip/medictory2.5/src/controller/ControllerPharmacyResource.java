package controller;

import java.util.ArrayList;
import ingegnerizzazione.RisorseFarmaciaBean;
import ingegnerizzazione.RisorseFarmaciaTableModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.AbstractFactory;
import model.FactoryElementoFarmacia;
import model.FarmacoFarmacia;
import model.SessioneFarmacia;
import view.GC_PharmacyRisorse;

public class ControllerPharmacyResource {
	
	private AbstractFactory factory = new FactoryElementoFarmacia();
	
	public RisorseFarmaciaBean findResources(SessioneFarmacia s) {
		int i;
	
		ObservableList<RisorseFarmaciaTableModel> list = null;
		if(s.getFarmaci() != null) {
			
			list = FXCollections.observableArrayList();
			ArrayList<FarmacoFarmacia> farmaci = s.getFarmaci();
		
			for(i=0; i<farmaci.size(); i++) {
				//int somma = 0;
				/*for (int j=0; j < farmaci.size();j++) {
					if (farmaci.get(i).getNome().compareTo(farmaci.get(j).getNome())==0)
						somma += Integer.toString(farmaci.get(i).getQuantita());
					
				}*/
				list.add(new RisorseFarmaciaTableModel(farmaci.get(i).getNome(), Integer.toString(farmaci.get(i).getQuantita()), farmaci.get(i).getDescrizione())); 
			}
		}
		
		return new RisorseFarmaciaBean(list);
	}
	
	
	public boolean addMedicine(SessioneFarmacia s, GC_PharmacyRisorse controllerGrafico, String nome, int quantitativo,  String descr, String scad) {
		
		
		ArrayList<FarmacoFarmacia> farmaci = new ArrayList<FarmacoFarmacia>();
		if( s.getFarmaci() != null) {
			farmaci =  s.getFarmaci();
		}
		
		FarmacoFarmacia f = (FarmacoFarmacia) factory.creaFarmaco(nome, descr , scad, quantitativo);
		farmaci.add(f);
		s.setFarmaci(farmaci);				//update the list of medicines in the session
		
		f.attach(controllerGrafico);
		f.notifica();
		return true;
	}
	
	
	
}
