package controller;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import ingegnerizzazione.EventiUtenteAbstractModelTable;
import ingegnerizzazione.EventiUtenteBean;
import ingegnerizzazione.EventiUtenteModelTable;
import ingegnerizzazione.PharmacyAllEventBean;
import ingegnerizzazione.PharmacyAllEventTableModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Evento;
import model.EventoDAO;
import model.SessioneFarmacia;
import view.GC_PharmacyEvent;

public class ControllerPharmacyEvent {
	
	
	public boolean addEvent(SessioneFarmacia s, GC_PharmacyEvent controllerGrafico, String nome, String dettagli, String premio, String inizio, String fine, int livello) {
		
	
		ArrayList<Evento> eventi = new ArrayList<Evento>();
		if(s.getEventi() != null) eventi= s.getEventi();
		
		
		Date oggi = new Date();
		
			
		try {
				
			SimpleDateFormat sdf = new  SimpleDateFormat("yyyy-MM-dd");
			Date scad = sdf.parse(inizio);
			if (scad.before(oggi)) return false;
			
			} catch (ParseException e) {
		      e.printStackTrace();
			}
		
		Evento e = new Evento(nome, dettagli, premio, inizio, fine, livello);
		
		
		eventi.add(e);
		s.setEventi(eventi);				
		
		e.attach(controllerGrafico);
		e.notifica();
		
		return true;
	}
	
	
	public PharmacyAllEventBean findEvent(SessioneFarmacia sessione) {
		
		ObservableList<PharmacyAllEventTableModel> list = FXCollections.observableArrayList();

		ArrayList<Evento> eventi = EventoDAO.allActiveEvents(sessione.getUsername()) ;
		if (eventi !=  null) {
			for(int i=0; i<eventi.size(); i++) {
				list.add(new PharmacyAllEventTableModel(eventi.get(i).getNome(), eventi.get(i).getDescrizione(),Integer.toString(eventi.get(i).getLivello_richiesto()),eventi.get(i).getPremio(), eventi.get(i).getInizio().toString() , eventi.get(i).getFine().toString())); 
			}
		}
		return new PharmacyAllEventBean(list);
	}
	
	
	
}
