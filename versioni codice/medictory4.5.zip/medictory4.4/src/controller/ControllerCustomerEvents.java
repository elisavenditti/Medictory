package controller;

import java.util.ArrayList;

import ingegnerizzazione.EventiUtenteAbstractModelTable;
import ingegnerizzazione.EventiUtenteBean;
import ingegnerizzazione.EventiUtenteModelTable;
import ingegnerizzazione.MyEventiUtenteBean;
import ingegnerizzazione.MyEventiUtenteModelTable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.AbstractState;
import model.Evento;
import model.SessioneCliente;
import model.StatoIniziale;
import model.SvolgimentoEvento;
import view.GC_CustomerEvent;

public class ControllerCustomerEvents {
	
	
	public void addMyEvent(GC_CustomerEvent observer,SessioneCliente s, String nomeEvento) {
		
		if (s.getEventiAttiviFarmaciaAssociata() == null) return;
		ArrayList<Evento> eventi = s.getEventiAttiviFarmaciaAssociata();
		for (Evento e : eventi) {
			if (e.getNome().compareToIgnoreCase(nomeEvento) == 0) { 							//Data la farmacia il nome evento � unico
				
				if(e.getLivello_richiesto() > s.getLivello()) {
					observer.mostraErrore("Requisiti insoddisfatti: non puoi partecipare");
					return;
				
				} else {
					
					//per prima cosa controllo che io non stia gi� partecipando
					for(Evento myEvent: s.getEventi()) {
						
						if(myEvent.getNome().compareToIgnoreCase(e.getNome()) == 0) {			
							observer.mostraErrore("Stai gi� partecipando a questo evento");
							return;
						}
					}
					
				
					s.getEventi().add(e);
					if(e.setJoined(true)) {
						e.attach(observer);
						e.notifica();
						observer.joined();
						return;
					
					} else {
						observer.mostraErrore("Evento non disponibile");
						return;
					}

				}
			}
		}
		observer.mostraErrore("Evento inserito non trovato");
	}
	
	public MyEventiUtenteBean findEvents(SessioneCliente s) {
	
		ObservableList<EventiUtenteAbstractModelTable> list = FXCollections.observableArrayList();
		if (s.getEventi() == null) return null;
		ArrayList<Evento> eventi = s.getEventi() ;
	
		for(int i=0; i<eventi.size(); i++) {
			AbstractState state = eventi.get(i).getState();
			if(state.getClass() == StatoIniziale.class || state.getClass() == SvolgimentoEvento.class)
				list.add(new MyEventiUtenteModelTable(eventi.get(i).getNome(), eventi.get(i).getDescrizione(), eventi.get(i).getPremio(), eventi.get(i).getInizio().toString() , eventi.get(i).getFine().toString())); 
		}
	
		return new MyEventiUtenteBean(list);
	}
	

	public EventiUtenteBean findAllActiveEvents(SessioneCliente sessione) {
		ObservableList<EventiUtenteAbstractModelTable> list = FXCollections.observableArrayList();

		
		ArrayList<Evento> eventi = sessione.getEventiAttiviFarmaciaAssociata();
		for(int i=0; i<eventi.size(); i++) {
			AbstractState state = eventi.get(i).getState();
			if(state.getClass() == StatoIniziale.class || state.getClass() == SvolgimentoEvento.class){	
				list.add(new EventiUtenteModelTable(eventi.get(i).getNome(), eventi.get(i).getDescrizione(),Integer.toString(eventi.get(i).getLivello_richiesto()),eventi.get(i).getPremio(), eventi.get(i).getInizio().toString() , eventi.get(i).getFine().toString())); 
			}
		}
	
		return new EventiUtenteBean(list);
	}
}
