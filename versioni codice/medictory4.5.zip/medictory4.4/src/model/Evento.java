package model;

import java.util.ArrayList;
import java.util.List;

import ingegnerizzazione.Observable;
import ingegnerizzazione.Observer;


public class Evento implements Observable {
	private AbstractState state;
	private ArrayList<Observer> observers = new ArrayList<Observer>();
	private String nome, descrizione, premio, inizio, fine;
	private String vincitore = null;
    private int livello_richiesto;
    private boolean addedRuntime = false; //E' solo per la farmacia
    private boolean changed = false;
    private boolean deleted = false;
    private boolean joined = false; //E' solo per l'utente
    private List<String> partecipanti = new ArrayList<>();

    public Evento(String nome, String descrizione, String premio, String inizio, String fine, int lv) {
        this.state = new StatoIniziale(this);
        this.setNome(nome);
        this.descrizione = descrizione;
        this.premio = premio;
        this.livello_richiesto = lv;
        this.inizio = inizio;
        this.fine = fine;
        
    }
    
    /********************* FUNZIONI CHE CAMBIANO IMPLEMENTAZIONE IN BASE ALLO STATO ***********************************/
    
    
    public void nextState() {
        this.state = this.state.nextState();
    }
    
	public boolean addPartecipant(String username) {
    	if(state.addPartecipant(username) == true) {
    		this.partecipanti.add(username);
    		return true;
    	}
    	else return false;
    }
    
    public boolean setLivello_richiesto(int livello_richiesto) {
		if( state.setLivello_richiesto(livello_richiesto) == true) {
			this.livello_richiesto = livello_richiesto;
			return true;
		}
		else return false;
	}
    
    public String getVincitore() {
    	if (state.getVincitore().compareTo("OK")==0) return this.vincitore;
    	else return "No winner";
	}

	public boolean setVincitore(String vincitore) {
		if( state.setVincitore(vincitore) == true) {
			this.vincitore = vincitore;
			return true;
		}
		else return false;
	}
    

	public boolean setFine(String fine) {
		if( state.setFine(fine) == true) {
			this.fine = fine;
			return true;
		}
		else return false;
	}
    
	public boolean setInizio(String inizio) {
		
		if(state.setInizio(inizio) == true) {
			this.inizio = inizio;
			return true;
		}
		else return false;
	}
	
	public boolean setPremio(String premio) {
		if(state.setPremio(premio) == true) {
			this.premio = premio;
			return true;
		}
		else return false;
	}
    
	
	public boolean setDescrizione(String descrizione) {
		if( state.setDescrizione(descrizione) == true) {
			this.descrizione = descrizione;
			return true;
		}
		else return false;
	}

	public boolean setNome(String nome) {
		if( state.setNome(nome) == true) {
			this.nome = nome;
			return true;
		}
		else return false;
	}
	
	public boolean setJoined(boolean joined) {
		if(state.setJoined(joined) && joined) {
			this.joined = joined;
			return true;
		}
		return false;
	}
	
	public boolean setDeleted(boolean deleted) {
		
		if(state.setDeleted(deleted)) {
			this.deleted = deleted;
			return true;
		}
		return false;

	}
	
	
	/********************* NON CAMBIANO IN BASE ALLO STATO *****************************************/
	
	public AbstractState getState() {
        return state;
    }
	
	public String getNome() {
		return nome;
	}
	
	public String getPremio() {
		return premio;
	}

	public String getDescrizione() {
		return descrizione;
	}
	
	public String getFine() {
		return fine;
	}
	
	public int getLivello_richiesto() {
		return livello_richiesto;
	}
	public String getInizio() {
		return inizio;
	}

	@Override
	public void attach(Observer observer){   
		if (!observers.contains(observer))
			observers.add(observer);		
	}
	
	@Override
	public void detach(Observer observer) {
		observers.remove(observer);
		
	}
	@Override
	public void notifica(){
	    for (Observer observer : observers) {
	       observer.update(this);
	    }

	}
	
	public boolean isAddedRuntime() {
			return addedRuntime;
	}

	public void setAddedRuntime(boolean addedRuntime) {
		this.addedRuntime = addedRuntime;
	}

	public boolean isChanged() {
		return changed;
	}

	public void setChanged(boolean changed) {
		this.changed = changed;
	}

	public boolean isJoined() {
		return joined;
	}


	public boolean isDeleted() {
		return deleted;
	}

	
	
	
}
