package model;

//Closed event

public class FineEvento extends AbstractState{
	
	FineEvento(Evento evento) {
		super(evento);
	}

	@Override
	public boolean addPartecipant(String username) {
		return false;
	}
    
	@Override
	public boolean setLivello_richiesto(int lv) {
		return false;
	}
    
	@Override
	public String getVincitore() {
		return "OK";
	}
    
	@Override
	public boolean setVincitore(String v) {
		return true;
	}
    
	@Override
	public boolean setFine(String f) {
		return false;
	}
    
	@Override
	public boolean setInizio(String i) {
		return false;
	}
    
	@Override
	public boolean setPremio(String premio) {
		return true; // era false
	}
    
	@Override
	public boolean setDescrizione(String ds) {
		return false;
	}
    
	@Override
	public boolean setNome(String nome) {
		return false;
	}
	
	@Override
	public boolean setJoined(Boolean bool) {
		return false;
	}
	
	@Override
	public boolean setDeleted(Boolean bool) {
		return false;
	}
    
	@Override
	public AbstractState nextState() {
		return null;
	}
}
