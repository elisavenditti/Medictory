package model;

public class PremioVincitaEvento extends Premiazione {
	
	
	
	public PremioVincitaEvento(String utente,String email) {
		super();
		this.utente=utente;
		this.email=email;
	}

	@Override
	public String premia() {
		return "Premiazione vincita evento dell'utente:" + this.getUtente() +  " con email:" + this.getEmail();
	}
	
}