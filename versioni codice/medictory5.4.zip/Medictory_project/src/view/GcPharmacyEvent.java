package view;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.AbstractState;
import model.EventoFarmacia;
import model.Sessione;
import model.SessioneFarmacia;
import model.StatoIniziale;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import controller.ControllerPharmacyEvent;
import ingegnerizzazione.Observable;
import ingegnerizzazione.Observer;
import ingegnerizzazione.PharmacyAllEventBean;
import ingegnerizzazione.PharmacyAllEventTableModel;
import javafx.scene.Scene;

public class GcPharmacyEvent implements GraphicController, Observer, Runnable {
	
	@FXML
	private DatePicker start;
	@FXML
	private DatePicker end;
	@FXML
	private Button gestione;
	@FXML
	private Button gestione2;
	@FXML
	private Button ritiro;
	@FXML
	private Button ritiro2;
	@FXML
	private Button risorse;
	@FXML
	private Button risorse2;
	@FXML
	private Button account;
	@FXML
	private Button account2;
	@FXML
	private Button home;
	@FXML
	private Button home2;
	@FXML
	private Button allEvent;
	@FXML
	private Button creaEvento;
	@FXML
	private Button createEvent;
	@FXML
	private Button elimina;
	
	@FXML
	private TextField nomeTf;
	@FXML
	private TextField dettagliTf;
	@FXML
	private TextField livelloTf;
	@FXML
	private TextField inizioTf;
	@FXML
	private TextField fineTf;
	@FXML
	private ComboBox<String> premioCb;
	@FXML
	private TextField eliminaTf;
	
	@FXML
	private TableView<PharmacyAllEventTableModel> eventiTb;
	@FXML
	private TableColumn<PharmacyAllEventTableModel, String> eventoCol;
	@FXML
	private TableColumn<PharmacyAllEventTableModel, String> descrizioneCol;
	@FXML
	private TableColumn<PharmacyAllEventTableModel, String> requisitiCol;
	@FXML
	private TableColumn<PharmacyAllEventTableModel, String> inizioCol;
	@FXML
	private TableColumn<PharmacyAllEventTableModel, String> fineCol;
	@FXML
	private TableColumn<PharmacyAllEventTableModel, String> premioCol;
	
	private SessioneFarmacia sessione;
	private ControllerPharmacyEvent controller = new ControllerPharmacyEvent();
	private boolean first = true;
	
	private void setPrimaryStage(Stage primaryStage, String file) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource(file));
			Parent root = loader.load();
			
			GraphicController controllerNext= loader.getController();
			controllerNext.setData(sessione);
			
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
			}
		
	}	
	
	public void mostraErrore(String err) {
		try {
			
			Stage primaryStage = new Stage();
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Errore.fxml"));
			Parent root = loader.load();
			GcErrore controllerNext = loader.getController();
			controllerNext.setError(err);
			primaryStage.initStyle(StageStyle.UNDECORATED);
			primaryStage.setScene(new Scene(root, 314, 209));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void completed() {
		try {
			Stage primaryStage = new Stage();
			Parent root = FXMLLoader.load(getClass().getResource("OK.fxml"));
			primaryStage.setTitle("Medictory");
			primaryStage.initStyle(StageStyle.UNDECORATED);
			primaryStage.setScene(new Scene(root, 314,209));
			primaryStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void setData(Sessione farma) {
		this.sessione = (SessioneFarmacia) farma;
		if (eventiTb != null) {
			if (first && sessione.getEventi() != null) {
				for (EventoFarmacia e : sessione.getEventi()) {
					AbstractState state = e.getState();
					if(state.getClass() == StatoIniziale.class){
						e.attach(this);
				}	
			}
			first = false;
			}
			
			this.showResource();	
		}
		if (premioCb != null) {
			String[] premi = {"Coupon","Sconto 50%","Analisi Gratis"};		
			premioCb.setItems(FXCollections.observableArrayList(premi));
		}
		new Thread(this).start();

	}

	@Override
	public void update( Observable e) {
		/*ArrayList<Evento> eventi = null;
		if(sessione.getEventi() != null) 
			eventi = sessione.getEventi();
		else eventi = new ArrayList<Evento>();
		
		if(!(eventi.contains((Evento)e))) {
			eventi.add((Evento)e);
			sessione.setEventi(eventi);
		}*/
		this.showResource();
		
	}
	
	@FXML
	public void deletePressed(ActionEvent e) {
		String n = eliminaTf.getText();
	
		if (n.compareTo("")==0) {
			mostraErrore("Non hai inserito nessun parametro");
		}
		else 
			controller.deleteEvent(this,sessione,n);
		eliminaTf.setText("");
		
		
	}
	

	
	
	public void showResource() {
		if ( eventoCol != null) {
			ObservableList<PharmacyAllEventTableModel> list;
			eventoCol.setCellValueFactory(new PropertyValueFactory<>("Evento"));
			descrizioneCol.setCellValueFactory(new PropertyValueFactory<>("Descrizione"));
			requisitiCol.setCellValueFactory(new PropertyValueFactory<>("Requisiti"));
			premioCol.setCellValueFactory(new PropertyValueFactory<>("Premio"));
			inizioCol.setCellValueFactory(new PropertyValueFactory<>("Inizio"));
			fineCol.setCellValueFactory(new PropertyValueFactory<>("Fine"));
	
			if(sessione != null) {
				PharmacyAllEventBean bean = controller.findEvent(sessione);
				if (bean != null) {
				list = bean.getEventi();
				eventiTb.setItems(list);
				}
			}
		}
	}
	
	@FXML
	public void ritiroPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "FarmaciaAppuntamento.fxml");
		
	}
	
	@FXML
	public void gestionePressed(ActionEvent event) {
		
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "GestioneFarmacie.fxml");
	}
	
	@FXML
	public void gestione2Pressed(ActionEvent event) {
		this.gestionePressed(event);
	}
	
	@FXML
	public void risorsePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "RisorseFarmacia.fxml");
	}
	
	@FXML
	public void risorse2Pressed(ActionEvent event) {
		this.risorsePressed(event);
	}
	
	@FXML
	public void allEventPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyAllEvent.fxml");
	}
	
	@FXML
	public void homePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepagePharmacy.fxml");
	}
	
	@FXML
	public void home2Pressed(ActionEvent event) {
		this.homePressed(event);
	}
	
	@FXML
	public void accountPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyAccount.fxml");
	}
	
	@FXML
	public void account2Pressed(ActionEvent event) {
		this.accountPressed(event);
		}
	
	
	@FXML
	public void creaPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyEvent.fxml");
	}
	
	
	@FXML
	public void createEventPressed() {
		String n = nomeTf.getText();
		String p = premioCb.getValue();
		String d = dettagliTf.getText();
		String l = livelloTf.getText();
		LocalDate in = start.getValue();
		LocalDate fin = end.getValue();
		
		
		if(in != null && in.isAfter(fin)) {
			mostraErrore("La data di inizio deve precedere quella di fine");
		} else if(n.compareTo("") == 0 || p==null || d.compareTo("") == 0 || l.compareTo("") == 0 || in == null || fin == null) {
			mostraErrore("Non hai inserito tutti i parametri");
		} else {
			if(p.compareToIgnoreCase("Coupon") != 0 && p.compareToIgnoreCase("Analisi Gratis") != 0 && p.compareToIgnoreCase("Sconto 50%") != 0)
				mostraErrore("Premio non disponibile");
			else {
				List<String> informazioni = new ArrayList<>();
				informazioni.add(n);
				informazioni.add(d);
				informazioni.add(p);
				informazioni.add(in.toString());
				informazioni.add(fin.toString());
				
				controller.addEvent (this, sessione , informazioni, Integer.parseInt(l));
			}
			
			
		}
		nomeTf.setText("");
		dettagliTf.setText("");
		livelloTf.setText("");
		start.setValue(null);
		end.setValue(null);
		
	}

	@Override
	public void run() {
		controller.premiazione(sessione);
	}
}
