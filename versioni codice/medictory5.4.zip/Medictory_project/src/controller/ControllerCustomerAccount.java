package controller;

import java.util.ArrayList;

import ingegnerizzazione.ListaFarmacieBean;
import ingegnerizzazione.ListaFarmacieModelTable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.FarmaciaDAO;
import model.Farmacia;

public class ControllerCustomerAccount {
	
	private ArrayList<Farmacia> farmacie = null; //
	
	public ListaFarmacieBean findListOfPharmacy() {
		
		ObservableList<ListaFarmacieModelTable> list = FXCollections.observableArrayList();
		
		if(farmacie == null) {
			farmacie = new ArrayList<>();
			farmacie = (ArrayList<Farmacia>) FarmaciaDAO.tutteLeFarmacie();
		}
		
		for(Farmacia f: farmacie) {
			list.add(new ListaFarmacieModelTable(f));
		}
		
		return new ListaFarmacieBean(list);
		
	}

}
