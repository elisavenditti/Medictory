package ingegnerizzazione;

import javafx.collections.ObservableList;

public class PharmacyAppuntamentiBean {
		private ObservableList<PharmacyAppuntamentiTableModel> ritiri;
		
		public PharmacyAppuntamentiBean(ObservableList<PharmacyAppuntamentiTableModel> list) {
			this.ritiri = list;
		}

		
		public ObservableList<PharmacyAppuntamentiTableModel> getRitiri() {
			return ritiri;
		}

		public void setRitiri(ObservableList<PharmacyAppuntamentiTableModel> ritiri) {
			this.ritiri = ritiri;
		}
}