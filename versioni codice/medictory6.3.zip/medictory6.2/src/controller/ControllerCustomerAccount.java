package controller;

import java.util.ArrayList;

import ingegnerizzazione.FarmaciaBean;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.FarmaciaDAO;
import model.Farmacia;

public class ControllerCustomerAccount {
	
	private ArrayList<Farmacia> farmacie = null; //
	
	public ObservableList<FarmaciaBean> findListOfPharmacy() {
		
		ObservableList<FarmaciaBean> list = FXCollections.observableArrayList();
		
		if(farmacie == null) {
			farmacie = new ArrayList<>();
			farmacie = (ArrayList<Farmacia>) FarmaciaDAO.tutteLeFarmacie();
		}
		
		for(Farmacia f: farmacie) {
			list.add(new FarmaciaBean(f));
		}
		
		return list;
		
	}

}
