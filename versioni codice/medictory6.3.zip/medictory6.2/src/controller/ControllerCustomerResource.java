package controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.List;

import ingegnerizzazione.DateException;
import ingegnerizzazione.Feedback;
import ingegnerizzazione.InputException;
import ingegnerizzazione.RisorseUtenteBean;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.AbstractFactory;
import model.FactoryElementoUtente;
import model.FarmacoCliente;
import model.SessioneCliente;
import view.GcCustomerRisorse;


public class ControllerCustomerResource {
	private AbstractFactory factory = new FactoryElementoUtente();
	private String utilizzabile = "utilizzabile";
	
	private int decrementa(FarmacoCliente f, String farmaco, int qtaDaTogliere) {
		if(f.getNome().compareToIgnoreCase(farmaco) == 0 && f.getQuantita()>0 && f.getStato().compareToIgnoreCase(utilizzabile)==0) {
			if(qtaDaTogliere <= f.getQuantita()) {
				
				f.setQuantita(f.getQuantita() - qtaDaTogliere);
				qtaDaTogliere = 0;
				f.setChanged(true);
				f.notifica();
			
			} else {
			
				qtaDaTogliere -= f.getQuantita();
				f.setQuantita(0);
				f.setChanged(true);
				f.notifica();
			}
		}
		return qtaDaTogliere;
	}

	
	public ObservableList<RisorseUtenteBean> findResources(SessioneCliente s) {
		int i;
	
		ObservableList<RisorseUtenteBean> list = FXCollections.observableArrayList();
		
		List<FarmacoCliente> farmaci =  s.getFarmaci();
		
		for(i=0; i<farmaci.size(); i++) {
			if(farmaci.get(i).getStato().compareTo(utilizzabile) == 0)
				list.add(new RisorseUtenteBean(farmaci.get(i).getNome(), farmaci.get(i).getDescrizione(), farmaci.get(i).getQuantita(), farmaci.get(i).getScadenza())); 
		}
		
		return list;
	}
	
		
	public void modifyAmount(SessioneCliente s, String farma, int deltaQta) throws InputException{
		List<FarmacoCliente> farmaci = s.getFarmaci();
		
		if(farmaci == null) {
			Feedback.mostraErrore("Non hai nessun farmaco a cui cambiare la quantit�");
			return;
		}
		
		if(deltaQta<0) {
			int qtaDaTogliere = -deltaQta;
		
			for (FarmacoCliente f : farmaci) {			
					qtaDaTogliere = this.decrementa(f, farma, qtaDaTogliere);
					if (qtaDaTogliere == 0) return;
			}
			if(qtaDaTogliere>0) throw new InputException("Impossibile rimuovere altre " + qtaDaTogliere + " unit�");
		
		}for(FarmacoCliente f: farmaci){
				if(f.getNome().compareToIgnoreCase(farma) == 0 && f.getStato().compareToIgnoreCase(utilizzabile)==0) {
					f.setQuantita(f.getQuantita() + deltaQta);
					f.setChanged(true);
					f.notifica();
					return;
				}
			}
	}
	
	private void modificaQtaFarmacoSpecifico(FarmacoCliente farmaco, int quantitativo) {
        
        
        int deltaQta = quantitativo;
        if(deltaQta<0) {
            int qtaDaTogliere = -deltaQta;
            if(qtaDaTogliere <= farmaco.getQuantita()) {
                
                farmaco.setQuantita(farmaco.getQuantita() - qtaDaTogliere);
                qtaDaTogliere = 0;
                farmaco.setChanged(true);
                farmaco.notifica();
            
            } else {
            
                qtaDaTogliere -= farmaco.getQuantita();
                farmaco.setQuantita(0);
                farmaco.setChanged(true);
                farmaco.notifica();
            }
            if(qtaDaTogliere>0) Feedback.mostraErrore("Impossibile rimuovere altre " + qtaDaTogliere + " unit�");
            
        } else {
            
            
            farmaco.setQuantita(farmaco.getQuantita() + deltaQta);
            farmaco.setChanged(true);
            farmaco.notifica();
                
        }
        
    }
    
    public FarmacoCliente addMedicine(GcCustomerRisorse controllerGrafico, SessioneCliente s, String nome, String descrizione, String scadenza, int quantitativo) throws DateException {

 

        FarmacoCliente f = null;
        
        Date oggi = new Date();
        
        
        try {
                
            SimpleDateFormat sdf = new  SimpleDateFormat("yyyy-MM-dd");
            Date scad = sdf.parse(scadenza);
            if (scad.before(oggi)) {
                throw new DateException("Non puoi inserire un medicinale scaduto");
            }
            
            } catch (ParseException e) {
              e.printStackTrace();
            }
        
        
        if(s.getFarmaci() != null) {
            for(FarmacoCliente farmaco: s.getFarmaci()) {
                if(farmaco.getNome().compareToIgnoreCase(nome) == 0 && farmaco.getScadenza().compareToIgnoreCase(scadenza) == 0 && farmaco.getStato().compareToIgnoreCase(utilizzabile)==0) {
                    modificaQtaFarmacoSpecifico(farmaco, quantitativo);
                    return null;

                }
            }
        }
        
        
        f = (FarmacoCliente) factory.creaFarmaco(nome, descrizione, scadenza, quantitativo);
        f.setStato(utilizzabile);
        f.setAddedRuntime(true);
        f.attach(controllerGrafico);
        f.notifica();
        
        return f;
    }
}
