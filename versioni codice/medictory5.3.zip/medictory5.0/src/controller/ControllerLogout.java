package controller;


import model.ClienteDAO;
import model.EventoDAO;
import model.FarmacoClienteDAO;
import model.FarmacoFarmaciaDAO;
import model.SessioneCliente;
import model.SessioneFarmacia;

public class ControllerLogout {

	public void makeDataClientPersistent(SessioneCliente s) {
		EventoDAO.clientEventsPersistence(s);
		FarmacoClienteDAO.clientMedicinePersistence(s);
	}
	
	public void makeDataPharmacyPersistent(SessioneFarmacia s) {
			EventoDAO.pharmacyEventsPersistence(s);
			ClienteDAO.clientPersistence(s.getClienti());
			FarmacoFarmaciaDAO.pharmacyMedicinePersistence(s);
	}
}
