package controller;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import ingegnerizzazione.PharmacyAllEventBean;
import ingegnerizzazione.PharmacyAllEventTableModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.AbstractState;
import model.Cliente;
import model.Coupon;
import model.EventoDAO;
import model.EventoFarmacia;
import model.FineEvento;
import model.Premiazione;
import model.PremioVincitaEvento;
import model.SessioneFarmacia;
import model.StatoIniziale;
import model.SvolgimentoEvento;
import view.GcPharmacyEvent;

public class ControllerPharmacyEvent implements Runnable {
	private String vincitore;
	private String emailCliente;
	private String premio;
	private Random r = new Random();
	
	public void premiazione (SessioneFarmacia s) {
		ArrayList<Cliente> infoPartecipanti =null;
		ArrayList<EventoFarmacia> eventi = null;
		if(s.getEventi() == null) return;
		
		eventi = s.getEventi();
		//ci va messo un: if (s.getEventi == null) return; ???
		for (EventoFarmacia e: eventi) {
			AbstractState state = e.getState();
		    if(state.getClass() == FineEvento.class && e.getVincitore() == null){	
		    	infoPartecipanti = EventoDAO.findPartecipants(e.getNome(), s.getUsername());
			    if (infoPartecipanti != null) {
			    	
			    	int dimensione = infoPartecipanti.size();
			    	int selected = r.nextInt(dimensione);
				   	this.vincitore = infoPartecipanti.get(selected).getUsername();
					this.emailCliente = infoPartecipanti.get(selected).getEmail();
					e.setVincitore(vincitore);
					e.setChanged(true);
					e.notifica();
					premio = e.getPremio();
					new Thread(this).start();
			    }
			}	
		}	
	}
	
	@Override
	public void run() {
		Premiazione p;
		p = new PremioVincitaEvento(vincitore, emailCliente);
		
		if(premio.compareToIgnoreCase("coupon") == 0) {
			Coupon coupon;
			coupon = new Coupon(p);
		}
		
		
		// altri ...
		
		
	}
	
	
	public void deleteEvent (GcPharmacyEvent observer, SessioneFarmacia s, String nomeEvento) {
		if (s.getEventi() == null) return;
		ArrayList<EventoFarmacia> eventi = s.getEventi();
		for (EventoFarmacia e : eventi) {
			if (e.getNome().compareToIgnoreCase(nomeEvento) == 0) { //Data la farmacia il nome evento � unico
				
				if(e.setDeleted(true)) {
					e.attach(observer);
					e.notifica();
					observer.completed();
					return;
				} else {
					observer.mostraErrore("Impossibile eliminare un evento in corso o concluso");
					return;
				}
			}
		}
		
		observer.mostraErrore("Impossibile trovare l'evento indicato");
	}
	
	
	
	public EventoFarmacia addEvent( GcPharmacyEvent controllerGrafico, SessioneFarmacia sessione, List<String> informazioni, int livello) {
		
		EventoFarmacia ev = null;		
		Date oggi = new Date();
		
		
		String infoNome = informazioni.get(0); 
		String infoDettagli = informazioni.get(1);  
		String infoPremio = informazioni.get(2);
		String infoInizio = informazioni.get(3); 
		String infoFine = informazioni.get(4);
		
		
		
		
		
		for(EventoFarmacia e: sessione.getEventi()) {
			if(e.getNome().compareToIgnoreCase(infoNome) == 0) {
				controllerGrafico.mostraErrore("Hai gi� creato un evento con questo nome");
				return ev;
			}
		}
			
		try {
				
			SimpleDateFormat sdf = new  SimpleDateFormat("yyyy-MM-dd");
			Date start = sdf.parse(infoInizio);
			
			
			if (start.before(oggi)) {
				controllerGrafico.mostraErrore("Non puoi inserire un evento iniziato");
				return ev;
			}		
		} catch (ParseException e) {
		     e.printStackTrace();
		}
		
		ev = new EventoFarmacia(infoNome, infoDettagli, infoPremio, infoInizio, infoFine, livello);
		
		ev.setAddedRuntime(true);	
		ev.attach(controllerGrafico);
		sessione.getEventi().add(ev);
		ev.notifica();
		controllerGrafico.completed();
		return ev;
	}
	
	
	public PharmacyAllEventBean findEvent(SessioneFarmacia sessione) {	
		ObservableList<PharmacyAllEventTableModel> list = FXCollections.observableArrayList();

		ArrayList<EventoFarmacia> eventi = sessione.getEventi() ;
		if (eventi ==  null) return null;
		for(int i=0; i<eventi.size(); i++) {
			AbstractState state = eventi.get(i).getState();
			if(eventi.get(i).isDeleted()) {}
			
			else if(state.getClass() == StatoIniziale.class || state.getClass() == SvolgimentoEvento.class){	
				list.add(new PharmacyAllEventTableModel(eventi.get(i).getNome(), eventi.get(i).getDescrizione(), Integer.toString(eventi.get(i).getLivelloRichiesto()), eventi.get(i).getPremio(), eventi.get(i).getInizio() , eventi.get(i).getFine())); 
			}
		}
	
	return new PharmacyAllEventBean(list);	
	
	}
	
	
	
}
