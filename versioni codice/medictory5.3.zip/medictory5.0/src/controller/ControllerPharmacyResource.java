package controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import ingegnerizzazione.RisorseFarmaciaBean;
import ingegnerizzazione.RisorseFarmaciaTableModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.AbstractFactory;
import model.FactoryElementoFarmacia;
import model.FarmacoFarmacia;
import model.SessioneFarmacia;
import view.GcPharmacyRisorse;

public class ControllerPharmacyResource {
	
	private AbstractFactory factory = new FactoryElementoFarmacia();
	
	
	private void unisciFarmaci(ObservableList<RisorseFarmaciaTableModel> list,FarmacoFarmacia f) {
		for(RisorseFarmaciaTableModel tm: list) {
			if(tm.getFarmaco().compareToIgnoreCase(f.getNome()) == 0) {
				int qta = f.getQuantita() + Integer.parseInt(tm.getQuantitativo());
				tm.setQuantitativo(Integer.toString(qta));
			}
		}
		
	}
	
	private int decrementa(FarmacoFarmacia f, String farmaco, int qtaDaTogliere) {
		if(f.getNome().compareToIgnoreCase(farmaco) == 0 && f.getQuantita()>0) {
			if(qtaDaTogliere <= f.getQuantita()) {
				
				f.setQuantita(f.getQuantita() - qtaDaTogliere);
				qtaDaTogliere = 0;
				f.setChanged(true);
				f.notifica();
			
			} else {
			
				qtaDaTogliere -= f.getQuantita();
				f.setQuantita(0);
				f.setChanged(true);
				f.notifica();
			}
		}
		return qtaDaTogliere;
	}
	
	
	
	public RisorseFarmaciaBean findResources(SessioneFarmacia s) {
		
		ArrayList<FarmacoFarmacia> farmaci = new ArrayList<>();
	    ObservableList<RisorseFarmaciaTableModel> list = null;			//devo mettere i farmaci qui ma devono essere raggruppati
		ArrayList<String> nomiPresenti = new ArrayList<>();
	    
	    if(s.getFarmaci() != null) {
			
			list = FXCollections.observableArrayList();
		    farmaci = s.getFarmaci();
		
			for(FarmacoFarmacia f: farmaci) {
				
				String farmacoCorrente = f.getNome();
				
				if(nomiPresenti.contains(farmacoCorrente)) {
					
					unisciFarmaci(list, f);
					
				} else {
					list.add(new RisorseFarmaciaTableModel(f.getNome(), Integer.toString(f.getQuantita()), f.getDescrizione())); 
					nomiPresenti.add(f.getNome());
				}
				
			}
		
		}
	    
	    
		return new RisorseFarmaciaBean(list);
	}
	
	
	
	public void cambiaQuantita(SessioneFarmacia s, String farmaco, int deltaQta, GcPharmacyRisorse gc_PharmacyRisorse) {
		
		ArrayList<FarmacoFarmacia> listaFarmaci = s.getFarmaci();
		
		if(listaFarmaci == null) {
			gc_PharmacyRisorse.mostraErrore("Non hai nessun farmaco a cui cambiare la quantit�");
			return;
		}
		
		if(deltaQta<0) {
		
			int qtaDaTogliere = -deltaQta;
			for(FarmacoFarmacia f: listaFarmaci){
				
				qtaDaTogliere = this.decrementa(f, farmaco, qtaDaTogliere);
				if (qtaDaTogliere == 0) return;
			}		
			if(qtaDaTogliere>0) gc_PharmacyRisorse.mostraErrore("Impossibile rimuovere altre " + qtaDaTogliere + " unit�");
		
		} else if(deltaQta>0) {
			
			for(FarmacoFarmacia f: listaFarmaci){
				if(f.getNome().compareToIgnoreCase(farmaco) == 0) {
					f.setQuantita(f.getQuantita() + deltaQta);
					f.setChanged(true);
					f.notifica();
					return;
				}
			}
		}
	}
	
	
	public FarmacoFarmacia addMedicine(SessioneFarmacia s, GcPharmacyRisorse controllerGrafico, String nome, int quantitativo,  String descrizione, String scadenza) {
		
		FarmacoFarmacia f = null;
		
		Date oggi = new Date();
		
		
		try {
				
			SimpleDateFormat sdf = new  SimpleDateFormat("yyyy-MM-dd");
			Date scad = sdf.parse(scadenza);
			if (scad.before(oggi)) return f;
			
		} catch (ParseException e) {
		      e.printStackTrace();
		}
		
		
		f = (FarmacoFarmacia) factory.creaFarmaco(nome.toUpperCase(), descrizione, scadenza, quantitativo);
		f.setAddedRuntime(true);
		s.getFarmaci().add(f);
		f.attach(controllerGrafico);
		f.notifica();
		
		return f;
	}
}
