package controller;


import java.time.LocalDate;

import model.RitiroCliente;
import model.RitiroClienteDAO;


public class ControllerCustomerAppuntamento {
	
	public static boolean prenotaRitiro(String nome, String citta, String indirizzo, LocalDate d, String farmacia, String email) {
		if (nome == null || citta == null || indirizzo == null || d == null || farmacia == null || email == null) 
			return false;
		
		
		RitiroCliente r;
		r = RitiroClienteDAO.creaRitiro(nome, citta, indirizzo, d, farmacia, email);
		
		if(r == null) { 
			return false;
		}
		return true;
	}

	public static boolean prenotaRitiro(String n, String c, String i, String string, String f, String e) {
		return false;
	}
}

