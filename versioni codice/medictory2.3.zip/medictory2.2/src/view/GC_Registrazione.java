package view;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.ArrayList;

import model.Farmacia;
import model.FarmaciaDAO;
import javafx.scene.Scene;
import controller.ControllerCustomerAccount;
import controller.ControllerRegistrazione;
import ingegnerizzazione.ListaFarmacieBean;
import ingegnerizzazione.ListaFarmacieModelTable;

public class GC_Registrazione {
	
	
	
	
	
	@FXML
	private Button x;
	@FXML
	private Button farma;
	@FXML
	private TextField username;
	@FXML
	private PasswordField password;
	@FXML
	private TextField email;
	@FXML
	private TextField scelta;
	@FXML
	private Button done;
	@FXML
	private TableView<ListaFarmacieModelTable> table;
	@FXML
	private TableColumn<ListaFarmacieModelTable, String> username_col, name_col, indirizzo_col, email_col;
	
	private void setPrimaryStage(Stage primaryStage, String file) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource(file));
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void mostraErrore(String err) {
		try {
			
			Stage primaryStage = new Stage();
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Errore.fxml"));
			Parent root = loader.load();
			GC_Errore controller_next = loader.getController();
			controller_next.setError(err);
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 314, 209));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	public void xPressed(ActionEvent event) {
		
        Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "progetto.fxml");
	}
	
	
	@FXML
	public void farmaPressed(ActionEvent event) {
		
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "Registrazione_farma.fxml");
	}
	

	@FXML
	public void tableStart() {
		
		
		ObservableList<ListaFarmacieModelTable> list = FXCollections.observableArrayList();
		username_col.setCellValueFactory(new PropertyValueFactory<ListaFarmacieModelTable, String>("Username"));
		name_col.setCellValueFactory(new PropertyValueFactory<ListaFarmacieModelTable, String>("Nome"));
		indirizzo_col.setCellValueFactory(new PropertyValueFactory<ListaFarmacieModelTable, String>("Indirizzo"));
		email_col.setCellValueFactory(new PropertyValueFactory<ListaFarmacieModelTable, String>("Email"));
		
		ControllerCustomerAccount controller = new ControllerCustomerAccount();
		ListaFarmacieBean bean = controller.findListOfPharmacy();
		list = bean.getFarmacie();
		table.setItems(list);
		
	}
	
	
	@FXML
	public void donePressed(ActionEvent event) {
		String u;
		String p;
		String e;
		String s;
		
		u = username.getText();
		p = password.getText();
		e = email.getText();
		s = scelta.getText();
		
		if(ControllerRegistrazione.registraCliente(u, p, e, s)) {
			
			Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
			setPrimaryStage(primaryStage, "progetto.fxml");
			GC_Ok o = new GC_Ok();
			o.mostrati();
		}
		else {
			u = "";
			p = "";
			e = "";
			s = "";
			
			Stage stage = (Stage) done.getScene().getWindow();
			stage.close();
			Stage primaryStage = new Stage();
			setPrimaryStage(primaryStage, "Registrazione.fxml");
	
			mostraErrore("Dati inseriti scorretti, riprovare");
			
		}
		
	}
	
}
