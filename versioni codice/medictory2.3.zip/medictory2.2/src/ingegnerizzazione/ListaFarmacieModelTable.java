package ingegnerizzazione;

import model.Farmacia;

public class ListaFarmacieModelTable {
	private String username, nome, indirizzo, email;
	
	/*public ListaFarmacieModelTable(String u, String n, String i, String e) {
		this.setUsername(u);
		this.setNome(n);
		this.setIndirizzo(i);
		this.setEmail(e);
	}*/

	public ListaFarmacieModelTable(Farmacia f) {
		this.username = f.getUsername();
		this.nome = f.getNome();
		this.indirizzo = f.getIndirizzo();
		this.email = f.getEmail();
	}
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getIndirizzo() {
		return indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
}
