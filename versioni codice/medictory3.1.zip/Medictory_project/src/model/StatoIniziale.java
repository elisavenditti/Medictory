package model;

//Created event, not started yet


public class StatoIniziale extends AbstractState {
	
	public StatoIniziale(Evento evento) {
		super(evento);
	}

	
	@Override
	public boolean addPartecipant(String username) {
		return true;
	}
    
	@Override
	public boolean setLivello_richiesto(int lv) {
		return true;
	}
    
	@Override
	public String getVincitore() {
		return "No winner: the event is going to start soon";
	}
    
	@Override
	public boolean setVincitore(String v) {
		return false;
	}
    
	@Override
	public boolean setFine(String f) {
		return true;
	}
    
	@Override
	public boolean setInizio(String i) {
		return true;
	}
    
	@Override
	public boolean setPremio(String premio) {
		return true;
	}
    
	@Override
	public boolean setDescrizione(String ds) {
		return true;
	}
    
	@Override
	public boolean setNome(String nome) {
		return true;
	}
    
	@Override
	public AbstractState nextState() {
		SvolgimentoEvento s = new SvolgimentoEvento(evento);
		return s;
	}
	
}
