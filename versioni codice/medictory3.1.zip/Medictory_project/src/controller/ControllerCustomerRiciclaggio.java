package controller;

import java.util.ArrayList;

import ingegnerizzazione.RiciclaggioUtenteBean;
import ingegnerizzazione.RiciclaggioUtenteModelTable;
import ingegnerizzazione.StoricoUtenteBean;
import ingegnerizzazione.StoricoUtenteTableModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.FarmacoCliente;
import model.SessioneCliente;

public class ControllerCustomerRiciclaggio {
	public RiciclaggioUtenteBean findResources(SessioneCliente s) {
		int i;
	
		ObservableList<RiciclaggioUtenteModelTable> list = FXCollections.observableArrayList();
		
		ArrayList<FarmacoCliente> farmaci = s.getFarmaci();
		
		for(i=0; i<farmaci.size(); i++) {
			if(farmaci.get(i).getStato().compareTo("scaduto") == 0 || farmaci.get(i).getStato().compareTo("scaduto") == 0 )
			list.add(new RiciclaggioUtenteModelTable(farmaci.get(i).getNome(), farmaci.get(i).getDescrizione(), farmaci.get(i).getQuantita())); 
		}
		
		RiciclaggioUtenteBean bean = new RiciclaggioUtenteBean(list);
		return bean;
		
	}
	
	public StoricoUtenteBean findResourcesBis(SessioneCliente s) {
		int i;
	
		ObservableList<StoricoUtenteTableModel> list = FXCollections.observableArrayList();
		
		ArrayList<FarmacoCliente> farmaci = s.getFarmaci();
		
		for(i=0; i<farmaci.size(); i++) {
			if(farmaci.get(i).getStato().compareTo("verificato") == 0)
				list.add(new StoricoUtenteTableModel(farmaci.get(i).getNome(), farmaci.get(i).getDescrizione(), "\u2713")); 
			else if (farmaci.get(i).getStato().compareTo("smaltito") == 0 )
			list.add(new StoricoUtenteTableModel(farmaci.get(i).getNome(), farmaci.get(i).getDescrizione(), "⌛❀✿ ┌∩┐(◣_◢)┌∩┐")); 
		}
		
		StoricoUtenteBean bean = new StoricoUtenteBean(list);
		return bean;
		
	}
	
	public void ricicla(SessioneCliente s, String farma, int quantitativo) {
	/*	ArrayList<FarmacoCliente> farmaci = s.getFarmaci();
		for (FarmacoCliente f : farmaci) {
			if(f.getNome().compareToIgnoreCase(farma)==0) {
				f.setQuantita(f.getQuantita() + quantitativo);
				f.notifica();
				
		}		
		
		}*/
	}
}
