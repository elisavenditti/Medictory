package view;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.EventoCliente;
import model.EventoDAO;
import model.Sessione;
import model.SessioneCliente;
import java.io.IOException;
import controller.ControllerCustomerEvents;
import ingegnerizzazione.AbstractEventiUtenteBean;
import ingegnerizzazione.Feedback;
import ingegnerizzazione.InputException;
import ingegnerizzazione.Observable;
import ingegnerizzazione.Observer;
import ingegnerizzazione.RequirementException;
import javafx.scene.Scene;

public class GcCustomerEvent implements GraphicController, Observer {
	@FXML
	private Button risorse;
	@FXML
	private Button risorse2;
	@FXML
	private Button riciclaggio;
	@FXML
	private Button riciclaggio2;
	@FXML
	private Button account;
	@FXML
	private Button account2;
	@FXML
	private Button home;
	@FXML
	private Button home2;
	@FXML
	private Button myEvent;
	@FXML
	private Button eventiAttivi;
	@FXML
	private Button refresh;
	@FXML
	private Button join;
	@FXML
	private TextField tfEvento;
	
	
	@FXML
	private TableView<AbstractEventiUtenteBean> myEventoTb;
	@FXML
	private TableColumn<AbstractEventiUtenteBean, String> risorseCol1;
	@FXML
	private TableColumn<AbstractEventiUtenteBean, String> risorseCol2;
	@FXML
	private TableColumn<AbstractEventiUtenteBean, String> risorseCol3;
	@FXML
	private TableColumn<AbstractEventiUtenteBean, String> risorseCol4;
	@FXML
	private TableColumn<AbstractEventiUtenteBean, String> risorseCol5;
	@FXML
	private TableColumn<AbstractEventiUtenteBean, String> extra;
	
	private SessioneCliente sessione;
	private ControllerCustomerEvents controller = new ControllerCustomerEvents();
	
	
	
	
	private void setPrimaryStage(Stage primaryStage, String file) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource(file));
			Parent root = loader.load();
			
			GraphicController controllerNext = loader.getController();
			controllerNext.setData(sessione);
			
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
			}
		
	}
	
	public void setData(Sessione cliente) {
		this.sessione = (SessioneCliente) cliente;
		sessione.setEventiAttiviFarmaciaAssociata(EventoDAO.allActiveEvents(sessione.getFarmaciaAssociata()));
		this.showResource();

	}
	

	public void joined() {
		try {
			Stage primaryStage = new Stage();
			Parent root = FXMLLoader.load(getClass().getResource("OK.fxml"));
			primaryStage.setTitle("Medictory");
			primaryStage.initStyle(StageStyle.UNDECORATED);
			primaryStage.setScene(new Scene(root, 314,209));
			primaryStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	@FXML
	public void joinEvent(ActionEvent event) {
		String n = tfEvento.getText();
		try {
				controller.addMyEvent(this, sessione, n);
			}catch (InputException | RequirementException e) {
				Feedback.mostraErrore(e.getMessage());
		
			}finally {
				tfEvento.setText("");
			}
	}
	
	public void showResource() {
		
		ObservableList<AbstractEventiUtenteBean> list = FXCollections.observableArrayList();
		risorseCol1.setCellValueFactory(new PropertyValueFactory<>("Evento"));
		risorseCol2.setCellValueFactory(new PropertyValueFactory<>("Descrizione"));
		risorseCol3.setCellValueFactory(new PropertyValueFactory<>("Premio"));
		risorseCol4.setCellValueFactory(new PropertyValueFactory<>("DataInizio"));
		risorseCol5.setCellValueFactory(new PropertyValueFactory<>("DataFine"));
		
		
		
		
		if(extra != null) {
			extra.setCellValueFactory(new PropertyValueFactory<>("Requisiti"));
			 list = controller.findAllActiveEvents(sessione);
		}
		if(sessione != null && extra ==null) {
			 list = controller.findEvents(sessione);	
			
		}
		
		myEventoTb.setItems(list);
		

	}
	
	@FXML
	public void refreshPressed(ActionEvent event) {
		sessione.setEventiAttiviFarmaciaAssociata(EventoDAO.allActiveEvents(sessione.getFarmaciaAssociata()));
		for(EventoCliente e: sessione.getEventiAttiviFarmaciaAssociata()) {
			e.attach(this);
			e.notifica();
		}		
	}
	
	
	
	@FXML
	public void risorsePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "Risorse.fxml");
	}
	
	@FXML
	public void risorse2Pressed(ActionEvent event) {
		this.risorsePressed(event);
	}
	
	@FXML
	public void accountPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerAccount.fxml");
	}
	
	@FXML
	public void account2Pressed(ActionEvent event) {
		this.accountPressed(event);
	}
	
	@FXML
	public void riciclaggioPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerRiciclaggio.fxml");
	}
	
	@FXML
	public void riciclaggio2Pressed(ActionEvent event) {
		this.riciclaggioPressed(event);
	}
	
	@FXML
	public void homePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepageClient.fxml");
	}
	
	@FXML
	public void home2Pressed(ActionEvent event) {
		this.homePressed(event);
	}
	
	@FXML
	public void eventiAttiviPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerEventi.fxml");
	}
	
	@FXML
	public void myEventPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerMyEvent.fxml");
	}

	@Override
	public void update(Observable e) {
		this.showResource();
	}
}
