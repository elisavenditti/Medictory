package ingegnerizzazione;

public class EventiUtenteBean extends AbstractEventiUtenteBean{
	
	private String requisiti;
	
	
	public EventiUtenteBean(String e, String d, String r, String p, String di, String df) {
		this.evento=e;
		this.descrizione=d;
		this.requisiti=r;
		this.premio=p;
		this.dataInizio=di;
		this.dataFine=df;
	}



	public String getRequisiti() {
		return requisiti;
	}



	public void setRequisiti(String requisiti) {
		this.requisiti = requisiti;
	}


}
