package ingegnerizzazione;

public interface Observer {
	public void update(Observable subj);
}
