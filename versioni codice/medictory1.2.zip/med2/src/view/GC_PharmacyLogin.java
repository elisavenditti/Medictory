package view;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Cliente;
import model.Farmacia;
import model.Sessione;
import controller.ControllerLogin;
import java.io.IOException;
import javafx.scene.Scene;

public class GC_PharmacyLogin {
	
	@FXML
	private Button backButton1;
	@FXML
	private Button PharmacyLogin;
	@FXML
	private TextField username;
	@FXML
	private PasswordField password;

	private void setPrimaryStage(Stage primaryStage, String file) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource(file));
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	public void loginPressed(ActionEvent event){

		String s1, s2;
		s1 = username.getText();
		s2 = password.getText();
		ControllerLogin controller_attuale = new ControllerLogin();
		Farmacia f = controller_attuale.loginFarmacia(s1, s2);
		Sessione s = new Sessione(f.getUsername(), f.getPassword(), f.getEmail());
		
		if(f == null) {												
																	
			s1 = "";
			s2 = "";	
			GC_Errore g = new GC_Errore();
			g.mostrati();	
			
			
		} else {
			
			try {
				Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
				FXMLLoader loader = new FXMLLoader(getClass().getResource("HomepagePharmacy.fxml"));
				Parent root = loader.load();
				GC_PharmacyHomepage controller_next = loader.getController();
				controller_next.setData(s);
				primaryStage.setTitle("Medictory");
				primaryStage.setScene(new Scene(root, 600,400));
				primaryStage.show();
			} catch(IOException e) {
				e.printStackTrace();
				}
		}
	}
	
	@FXML
	public void back1Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "progetto.fxml");
	}

}
