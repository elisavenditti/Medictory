package view;

public class ModelTable {
	private String username, nome, indirizzo;
	
	public ModelTable(String u, String n, String i) {
		setUsername(u);
		setNome(n);
		setIndirizzo(i);
	}
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getIndirizzo() {
		return indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	
}
