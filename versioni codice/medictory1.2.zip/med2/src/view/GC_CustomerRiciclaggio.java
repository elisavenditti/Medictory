package view;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import model.Sessione;

import java.io.IOException;
import javafx.scene.Scene;

public class GC_CustomerRiciclaggio {
	
	@FXML
	private Button risorse, risorse2;
	@FXML
	private Button eventi, eventi2;
	@FXML
	private Button account, account2;
	@FXML
	private Button home, home2;
	@FXML
	private Button storico, ricicla2;
	@FXML
	private Button ricicla;
	
	private Sessione sessione;
	
	private void setPrimaryStage(Stage primaryStage, String file) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource(file));
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private FXMLLoader setPrimaryStage2(Stage primaryStage, String file) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource(file));
			Parent root = loader.load();
				
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
			return loader;
			
		} catch(IOException e) {
			e.printStackTrace();
			}
		return null;
		
	}
	
	public void setData(Sessione cliente) {
		this.sessione = cliente;
	}
	
	
	@FXML
	public void eventiPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerMyEvent.fxml");
	}
	
	@FXML
	public void eventi2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerMyEvent.fxml");
	}
	
	@FXML
	public void accountPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerAccount.fxml");
	}
	
	@FXML
	public void account2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerAccount.fxml");
	}
	
	@FXML
	public void risorsePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		FXMLLoader loader = setPrimaryStage2(primaryStage, "Risorse.fxml");
		GC_CustomerRisorse controller_next = loader.getController();
		controller_next.setData(sessione);
	}
	
	@FXML
	public void risorse2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		FXMLLoader loader = setPrimaryStage2(primaryStage, "Risorse.fxml");
		GC_CustomerRisorse controller_next = loader.getController();
		controller_next.setData(sessione);
	}
	
	@FXML
	public void homePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepageClient.fxml");
	}
	
	@FXML
	public void home2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepageClient.fxml");
	}
	
	@FXML
	public void ricicla2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		FXMLLoader loader = setPrimaryStage2(primaryStage, "CustomerRiciclaggio.fxml");
		GC_CustomerRiciclaggio controller_next = loader.getController();
		controller_next.setData(sessione);
	}
	
	@FXML
	public void storicoPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		FXMLLoader loader = setPrimaryStage2(primaryStage, "CustomerStoricoRicicli.fxml");
		GC_CustomerRiciclaggio controller_next = loader.getController();
		controller_next.setData(sessione);
	}
}
