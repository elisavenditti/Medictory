package view;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Sessione;

import java.io.IOException;

import controller.ControllerCustomerResource;
import ingegnerizzazione.RisorseUtenteBean;
import ingegnerizzazione.RisorseUtenteTableModel;
import javafx.scene.Scene;

public class GC_CustomerRisorse {
	
	@FXML
	private Button riciclaggio;
	@FXML
	private Button eventi;
	@FXML
	private Button account;
	@FXML
	private Button submit;
	@FXML
	private Button home;
	@FXML
	private TableView<RisorseUtenteTableModel> risorsetb;
	@FXML
	private TableColumn<RisorseUtenteTableModel, String> risorse_cl1;
	@FXML
	private TableColumn<RisorseUtenteTableModel, String> risorse_cl2;
	@FXML
	private TableColumn<RisorseUtenteTableModel, String> risorse_cl3;
	@FXML
	private TableColumn<RisorseUtenteTableModel, String> risorse_cl4;
	
	
	private Sessione sessione;
	

	private void setPrimaryStage(Stage primaryStage, String file, Button btn) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource(file));
			Parent root = loader.load();
			
			if(btn.getId() == "riciclaggio") {
				GC_CustomerRiciclaggio controller_next = loader.getController();
				controller_next.setData(sessione);
			}
			else if(btn.getId() == "home") {
				GC_CustomerHomepage controller_next = loader.getController();
				controller_next.setData(sessione);
			}
			else if(btn.getId() == "eventi") {
				GC_CustomerEvent controller_next = loader.getController();
				controller_next.setData(sessione);
			}
			else if(btn.getId() == "account") {
				GC_CustomerAccount controller_next = loader.getController();
				controller_next.setData(sessione);
			}
			
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
			}
		
	}
	
	private FXMLLoader setPrimaryStage2(Stage primaryStage, String file) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource(file));
			Parent root = loader.load();
				
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
			return loader;
			
		} catch(IOException e) {
			e.printStackTrace();
			}
		return null;
		
	}
	
	public void setData(Sessione cliente) {
		this.sessione = cliente;
		this.showResource();
	}
	
	public void showResource() {
		
		
		ObservableList<RisorseUtenteTableModel> list = FXCollections.observableArrayList();
		risorse_cl1.setCellValueFactory(new PropertyValueFactory<RisorseUtenteTableModel, String>("Farmaco"));
		risorse_cl2.setCellValueFactory(new PropertyValueFactory<RisorseUtenteTableModel, String>("Descrizione"));
		risorse_cl3.setCellValueFactory(new PropertyValueFactory<RisorseUtenteTableModel, String>("Quantitativo"));
		risorse_cl4.setCellValueFactory(new PropertyValueFactory<RisorseUtenteTableModel, String>("Scadenza"));
		
		//chiama showResource del controllore e mi ritorna la bean
		ControllerCustomerResource controller = new ControllerCustomerResource();
		RisorseUtenteBean bean = controller.findResources(sessione);
		
		//chiama la bean per visualizzare i dati:
		list = bean.getFarmaci();
		risorsetb.setItems(list);
		
	}
	
	@FXML
	public void accountPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerAccount.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void homePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepageClient.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void riciclaggioPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		FXMLLoader loader = setPrimaryStage2(primaryStage, "CustomerRiciclaggio.fxml");
		GC_CustomerRiciclaggio controller_next = loader.getController();
		controller_next.setData(sessione);
	}
	
	@FXML
	public void eventiPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerMyEvent.fxml", (Button)event.getSource());
	}
}
