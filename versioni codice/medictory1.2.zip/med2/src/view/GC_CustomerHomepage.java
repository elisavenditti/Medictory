package view;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Sessione;

import java.io.IOException;
import javafx.scene.Scene;

public class GC_CustomerHomepage {
	@FXML
	private Button account;
	@FXML
	private Button eventi;
	@FXML
	private Button risorse;
	@FXML
	private Button riciclaggio;
	@FXML
	private Label score;
	
	private Sessione sessione;
	
	
	
	private void setPrimaryStage(Stage primaryStage, String file, Button btn) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource(file));
			Parent root = loader.load();
			
			if(btn.getId() == "riciclaggio") {
				GC_CustomerRiciclaggio controller_next = loader.getController();
				controller_next.setData(sessione);
			}
			else if(btn.getId() == "risorse") {
				GC_CustomerRisorse controller_next = loader.getController();
				controller_next.setData(sessione);
			}
			else if(btn.getId() == "eventi") {
				GC_CustomerEvent controller_next = loader.getController();
				controller_next.setData(sessione);
			}
			else if(btn.getId() == "account") {
				GC_CustomerAccount controller_next = loader.getController();
				controller_next.setData(sessione);
			}
			
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
			}
		
	}	
	
	
	private FXMLLoader setPrimaryStage2(Stage primaryStage, String file) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource(file));
			Parent root = loader.load();
				
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
			return loader;
			
		} catch(IOException e) {
			e.printStackTrace();
			}
		return null;
		
	}
	
	private void initPage() {
		
		/* per visualizzare queste informazioni sarebbe opportuno usare una bean. Visto che usare una classe per una sola stringa mi 
		 * sembra eccessivo penso che qui si dovrebbe richiamare la bean che si usa nella pagina dell'account ... alla fine le informazioni
		 * sono le stesse (e visualizzate nello stesso modo)*/
		
	//	int punti = sessione.getPunti();
	//	String[] parts = score.getText().split("/");
	//	parts[0] = Integer.toString(punti);
	//	score.setText(parts[0]+"/"+parts[1]);
	}
	
	
	
	public void setData(Sessione cliente) {
		this.sessione = cliente;
		this.initPage();
	}
	
	@FXML
	public void accountPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerAccount.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void eventiPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerMyEvent.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void riciclaggioPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerRiciclaggio.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void risorsePressed(ActionEvent event) throws IOException {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		FXMLLoader loader = setPrimaryStage2(primaryStage, "Risorse.fxml");
		GC_CustomerRisorse controller_next = loader.getController();
		controller_next.setData(sessione);
	}

}
