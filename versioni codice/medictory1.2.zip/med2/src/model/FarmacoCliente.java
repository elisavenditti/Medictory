package model;

public class FarmacoCliente extends Farmaco{
	
	private String stato;
	
	public FarmacoCliente(String nome, String descrizione, String scadenza, int quantita, String stato) {
			super(nome, descrizione, scadenza, quantita);
			this.stato = stato;
	}
	
	public String getStato() {
		return stato;
	}

	public void setStato(String stato) {
		this.stato = stato;
	}
}
