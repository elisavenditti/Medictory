package controller;
import java.util.ArrayList;
import java.util.List;

import ingegnerizzazione.RisorseUtenteBean;
import ingegnerizzazione.RisorseUtenteTableModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.FarmacoCliente;
import model.FarmacoClienteDAO;
import model.Sessione;

public class ControllerCustomerResource {
	
	
	public RisorseUtenteBean findResources(Sessione s) {
		int i;
	/********************** va nella dao a prendere le risorse *******************/
		
		FarmacoClienteDAO dao = new FarmacoClienteDAO();
		List<FarmacoCliente> farmaci = dao.retrieveResourceFromDb(s.getUsername());
		
		//setta la bean con queste risorse
		
		ObservableList<RisorseUtenteTableModel> list = FXCollections.observableArrayList();
		
		for(i=0; i<farmaci.size(); i++) {
			list.add(new RisorseUtenteTableModel(farmaci.get(i).getNome(), farmaci.get(i).getDescrizione(), farmaci.get(i).getQuantita(), farmaci.get(i).getScadenza())); 
		}
		
		RisorseUtenteBean bean = new RisorseUtenteBean(list);
		return bean;
		
	}
}
