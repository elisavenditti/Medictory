package model;

import java.util.ArrayList;

import ingegnerizzazione.Observable;
import ingegnerizzazione.Observer;


public class EventoCliente implements Observable, Evento {
	private AbstractState state;
	private ArrayList<Observer> observers = new ArrayList<>();
	private String nome;
	private String descrizione;
	private String premio;
	private String inizio;
	private String fine;
	private String vincitore = null;
    private int livelloRichiesto;
    private boolean joined = false; //E' solo per l'utente
   
    public EventoCliente(String nome, String descrizione, String premio, String inizio, String fine, int lv) {
        this.state = new StatoIniziale(this);
        this.nome = nome;
        this.descrizione = descrizione;
        this.premio = premio;
        this.livelloRichiesto = lv;
        this.inizio = inizio;
        this.fine = fine;
        
    }
    
    /********************* FUNZIONI CHE CAMBIANO IMPLEMENTAZIONE IN BASE ALLO STATO ***********************************/
    
    @Override
    public void nextState() {
        this.state = this.state.nextState();
    }
    
    
    /*@Override
    public boolean setLivelloRichiesto(int livelloRichiesto) {
		if( state.setLivello_richiesto(livelloRichiesto)) {
			this.livelloRichiesto = livelloRichiesto;
			return true;
		}
		else return false;
	}
    
    
    @Override
	public boolean setVincitore(String vincitore) {
		if( state.setVincitore(vincitore)) {
			this.vincitore = vincitore;
			return true;
		}
		else return false;
	}
    
    @Override
	public boolean setFine(String fine) {
		if( state.setFine(fine)) {
			this.fine = fine;
			return true;
		}
		else return false;
	}
    
    @Override
	public boolean setInizio(String inizio) {
		
		if(state.setInizio(inizio)) {
			this.inizio = inizio;
			return true;
		}
		else return false;
	}
	
    @Override
	public boolean setPremio(String premio) {
		if(state.setPremio(premio)) {
			this.premio = premio;
			return true;
		}
		else return false;
	}
    
    @Override
	public boolean setDescrizione(String descrizione) {
		if( state.setDescrizione(descrizione)) {
			this.descrizione = descrizione;
			return true;
		}
		else return false;
	}
    
    @Override
	public boolean setNome(String nome) {
		if( state.setNome(nome)) {
			this.nome = nome;
			return true;
		}
		else return false;
	}
	
    */
    
	public boolean setJoined(boolean joined) {
		if(state.setJoined(joined) && joined) {
			this.joined = joined;
			return true;
		}
		return false;
	}
	
	  @Override
	  public String getVincitore() {
	    if (state.getVincitore().compareTo("OK")==0) return this.vincitore;
	    else return "No winner";
	  }
	
	/********************* NON CAMBIANO IN BASE ALLO STATO *****************************************/
	@Override
	public AbstractState getState() {
        return state;
    }
	
	@Override
	public String getNome() {
		return nome;
	}
	
	@Override
	public String getPremio() {
		return premio;
	}
	
	@Override
	public String getDescrizione() {
		return descrizione;
	}
	
	@Override
	public String getFine() {
		return fine;
	}
	
	@Override
	public int getLivelloRichiesto() {
		return livelloRichiesto;
	}
	
	@Override
	public String getInizio() {
		return inizio;
	}

	@Override
	public void attach(Observer observer){   
		if (!observers.contains(observer))
			observers.add(observer);		
	}
	
	@Override
	public void detach(Observer observer) {
		observers.remove(observer);
		
	}
	@Override
	public void notifica(){
	    for (Observer observer : observers) {
	       observer.update(this);
	    }

	}

	public boolean isJoined() {
		return joined;
	}	
}
