package ingegnerizzazione;

import javafx.collections.ObservableList;

public class PharmacyGestioneBean {
		private ObservableList<PharmacyGestioneTableModel> autenticazioni;
		
		public PharmacyGestioneBean(ObservableList<PharmacyGestioneTableModel> list) {
			this.setAutenticazioni(list);
		}

		
		public ObservableList<PharmacyGestioneTableModel> getAutenticazioni() {
			return autenticazioni;
		}

		public void setAutenticazioni(ObservableList<PharmacyGestioneTableModel> autenticazioni) {
			this.autenticazioni = autenticazioni;
		}
}
