package ingegnerizzazione;

import javafx.collections.ObservableList;

	public class ListaClientiBean {
	private ObservableList<ListaClientiModelTable> clienti;
	
	public ListaClientiBean(ObservableList<ListaClientiModelTable> list) {
		this.setClienti(list);
	}

	public ObservableList<ListaClientiModelTable> getClienti() {
		return clienti;
	}

	public void setClienti(ObservableList<ListaClientiModelTable> clienti) {
		this.clienti = clienti;
	}
}
