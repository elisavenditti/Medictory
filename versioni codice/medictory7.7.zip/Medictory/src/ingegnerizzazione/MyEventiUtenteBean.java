package ingegnerizzazione;

public class MyEventiUtenteBean extends AbstractEventiUtenteBean {
		
	public MyEventiUtenteBean(String e, String d, String p, String di, String df) {
		this.evento=e;
		this.descrizione=d;
		this.premio=p;
		this.dataInizio=di;
		this.dataFine=df;
	}

	
}
