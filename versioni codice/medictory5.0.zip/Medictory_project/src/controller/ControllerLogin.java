package controller;
import model.Farmacia;
import model.FarmaciaDAO;
import model.FarmacoCliente;
import model.FarmacoFarmacia;
import model.FarmacoFarmaciaDAO;
import model.SessioneCliente;
import model.SessioneFarmacia;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import model.Cliente;
import model.ClienteDAO;

public class ControllerLogin{
	private SessioneCliente s;
	private SessioneFarmacia sf;
	private ArrayList<FarmacoFarmacia> farmaciFarmacia = new ArrayList<>();
	
	
	private void deleteExpiredOnes(String username) {
		
		Date oggi = new Date();
		
		for(FarmacoFarmacia f: farmaciFarmacia) {
			try {
								
				SimpleDateFormat sdf = new  SimpleDateFormat("yyyy-MM-dd");
				Date scad = sdf.parse(f.getScadenza());
			
				
				if (scad.before(oggi)) {
						
						FarmacoFarmaciaDAO.deleteExpired(f.getNome(), username, f.getScadenza());
						farmaciFarmacia.remove(f);	
				}
							
			} catch (ParseException e) {
				e.printStackTrace();
			}

		}
	}
	
	
	
	public SessioneFarmacia loginFarmacia(String us, String pwd) {
	
		
		if (us == null || pwd == null || us.equals("") || pwd.equals("")) return null;
		
		Farmacia f;
		f = FarmaciaDAO.esisteFarmacia(us, pwd);
		
		
		if(f == null) return null;
		
		
		farmaciFarmacia = f.getFarmaci();
		if(farmaciFarmacia !=  null) {
			
			this.deleteExpiredOnes(us);
			f.setFarmaci(farmaciFarmacia);
		}
			
		
		sf = new SessioneFarmacia (f.getUsername(), /*f.getRitiri()*/ f.getClienti() ,f.getFarmaci(),f.getEventi());
		sf.setNomeFarmacia(f.getNome());
		sf.setIndirizzo(f.getIndirizzo());
		sf.setEmail(f.getEmail());
		//sf.setRitiri(f.getRitiri());
		
		return sf;
	}
	
	public SessioneCliente loginCliente(String us, String pwd) {
		int qta = 0;
		
		if (us == null || pwd == null || us.equals("") || pwd.equals("")) return null;
		
		Cliente c;
		c = ClienteDAO.esisteCliente(us, pwd);
			
		
		if(c == null) return null;
		
		s = new SessioneCliente(c.getUsername(),c.getFarmaci(),c.getEventi());
		
		s.setPunteggio(c.getPunti());
		s.setLivello(c.getLivello());
		s.setFarmaciaAssociata(c.getFarma_associata());
		s.setEmail(c.getEmail());
		check();
		
		if(c.getFarmaci() != null) {
			for(FarmacoCliente f: c.getFarmaci()) {
				if(f.getStato().compareTo("verificato") == 0) {
					qta += f.getQuantita();
				}
			}
		}
		
		s.setQtaVerificate(qta);
		
		return s;
	}

	public void check() {
		
		Date oggi = new Date();
		
		
		ArrayList<FarmacoCliente> farmaci = new ArrayList<>();	
		if(s.getFarmaci() != null) {
			farmaci = s.getFarmaci();
		
			for(FarmacoCliente f: farmaci) {
		
				try {
				
					SimpleDateFormat sdf = new  SimpleDateFormat("yyyy-MM-dd");
					Date scad = sdf.parse(f.getScadenza());
				
					if (scad.before(oggi) && f.getStato().compareTo("utilizzabile") == 0) {
							f.setStato("scaduto");
							f.setChanged(true);
					}
								
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
