package controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

import ingegnerizzazione.ListaClientiModelTable;
import ingegnerizzazione.PharmacyAppuntamentiBean;
import ingegnerizzazione.PharmacyAppuntamentiTableModel;
import ingegnerizzazione.PharmacyGestioneBean;
import ingegnerizzazione.PharmacyGestioneTableModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Cliente;
import model.Coupon;
import model.FarmacoCliente;
import model.FarmacoClienteDAO;
import model.Premiazione;
import model.PremioPassaggioDiLivello;
import model.RitiroCliente;
import model.RitiroClienteDAO;
import model.SessioneFarmacia;
import view.GcPharmacyAccount;
import view.GcPharmacyAppuntamenti;

public class ControllerPharmacyAppuntamenti  {

	//private ArrayList<RitiroCliente> ritiri = null; 
	
	public PharmacyAppuntamentiBean findListOfRitiri(SessioneFarmacia sessione) {
		
		
		ObservableList<PharmacyAppuntamentiTableModel> list = FXCollections.observableArrayList();
		//ArrayList<RitiroCliente> ritiri = sessione.getRitiri();
		ArrayList<Cliente> clienti = sessione.getClienti();
	
		LocalDate currentDate = LocalDate.now();
		for(Cliente c: clienti) {
			ArrayList<RitiroCliente> ritiri= RitiroClienteDAO.myRitiriCliente(c.getUsername());
			
			for(RitiroCliente rc: ritiri) {
				
				
				if((rc.getData()).isAfter(currentDate)) {
					PharmacyAppuntamentiTableModel modelTable = new PharmacyAppuntamentiTableModel(c.getUsername(),rc.getEmail(),rc.getCitta(),rc.getIndirizzo(),rc.getData());
					list.add(modelTable);
				}
			}
		}
		
		/*if(ritiri == null) {
			ritiri = sessione.getRitiri();
		}*/
		
		/*for(RitiroCliente c: ritiri) {
			list.add(new PharmacyAppuntamentiTableModel(c.getNome(), c.getEmail(), c.getCitta(),c.getIndirizzo(),c.getData()));
			
		}*/
		
		return new PharmacyAppuntamentiBean(list);
    }
}


	

 