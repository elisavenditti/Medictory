package model;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;
import java.util.ArrayList;
import java.util.Random;



public class Coupon extends Decorator {
	
	
	private Random r;
	


	
	public Coupon(Premiazione premiazione) {
		this.prem= premiazione;
	}

	@Override
	public String premia() {
		
		System.out.println("Preparing to send email....");
		Properties p = new Properties();
		
		p.put("mail.smtp.auth", "true");
		p.put("mail.smtp.starttls.enable", "true");
		p.put("mail.smtp.host", "smtp.gmail.com");
		p.put("mail.smtp.port", "587");
		p.put("mail.smtp.ssl.trust", "smtp.gmail.com");
		
		String myEmail = "medictoryISPW@gmail.com";
		String myPassword = "30elodecrew";												//inserire la password dell'email di medictory
		
		Session session = Session.getInstance(p, new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(myEmail, myPassword);
			}
		});
		Message mex = prepareMessage(session, myEmail);
		
		try {
			Transport.send(mex);
		} catch (MessagingException e) {
			
			e.printStackTrace();
		}
			System.out.println("TCP mandaaa");
			System.out.println("Sent message successfully....");
			return "OK";

		
	}
	
	public Message prepareMessage(Session session, String myEmail) {
		try{
			
			Message mex = new MimeMessage(session);
			
			mex.setFrom(new InternetAddress(myEmail));
			
			mex.setRecipient(Message.RecipientType.TO, new InternetAddress("ludovico.zarr@gmail.com"/*this.email*/));	//inserire l'email a cui inviare il messaggio
			
			mex.setSubject("MEDICTORY LEVEL UP");
			
			mex.setText(this.prem.premia() + randomCoupon()+ ".\nLa Tua Farmacia");
			
			return mex;
		} catch (AddressException e) {

			e.printStackTrace();
		} catch (MessagingException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	private String randomCoupon() {
		
		r = new Random();
		ArrayList<String> text = new ArrayList<>();
		
		text.add("Hai ottenuto un profumo in omaggio, passa in farmacia per ritirarlo");
		text.add("Hai ottenuto il copupon PRENDI 3 PAGHI 2, passa in farmacia per utilizzarlo");
		text.add("Hai ottenuto un set per la manicure in omaggio, passa in farmacia per ritirarlo");
		text.add("Hai ottenuto la nuovissima crema mani Yves Rocher in omaggio, passa in farmacia per ritirarlo");
		text.add("Hai ottenuto un prodotto a scelta in omaggio, passa in farmacia per ritirarlo");
		text.add("Hai ottenuto un set di shampoo in omaggio, passa in farmacia per ritirarlo");
		text.add("Hai ottenuto il 30% di sconto sul tuo prossimo acquisto (articoli della parafarmacia)");
		text.add("Hai ottenuto il 25% di sconto sul tuo prossimo acquisto (articoli della parafarmacia)");
		text.add("Hai ottenuto il 15% di sconto sul tuo prossimo acquisto (articoli della parafarmacia)");
		text.add("Hai ottenuto il 5% di sconto sul tuo prossimo acquisto (articoli della parafarmacia)");
		
		
		int selected = r.nextInt(10);
		
		return text.get(selected);
		
	}
	
	

}