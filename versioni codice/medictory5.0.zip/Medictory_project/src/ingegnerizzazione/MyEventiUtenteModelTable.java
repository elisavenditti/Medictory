package ingegnerizzazione;

public class MyEventiUtenteModelTable extends EventiUtenteAbstractModelTable {
		
	public MyEventiUtenteModelTable(String e, String d, String p, String di, String df) {
		this.evento=e;
		this.descrizione=d;
		this.premio=p;
		this.dataInizio=di;
		this.dataFine=df;
	}

	
}
