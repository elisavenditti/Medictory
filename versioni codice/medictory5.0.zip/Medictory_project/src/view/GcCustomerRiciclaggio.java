package view;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.FarmacoCliente;
import model.FarmacoClienteDAO;
import model.Sessione;
import model.SessioneCliente;
import java.io.IOException;
import java.util.ArrayList;
import controller.ControllerCustomerRiciclaggio;
import ingegnerizzazione.Observable;
import ingegnerizzazione.Observer;
import ingegnerizzazione.RiciclaggioUtenteBean;
import ingegnerizzazione.RiciclaggioUtenteModelTable;
import ingegnerizzazione.StoricoUtenteBean;
import ingegnerizzazione.StoricoUtenteTableModel;
import javafx.scene.Scene;

public class GcCustomerRiciclaggio implements Graphic_Controller, Observer {
	
	@FXML
	private Button risorse, risorse2, eventi, eventi2, account, account2, home, home2, storico, ricicla2, ricicla, ritiro, refresh;
	@FXML
	private TextField riciclaTf;
	@FXML
	private TableView<RiciclaggioUtenteModelTable> riciclaggiotb;
	@FXML
	private TableColumn<RiciclaggioUtenteModelTable, String> riciclaggio_c1, riciclaggio_c2, riciclaggio_c3;
	
	
	@FXML
	private TableView<StoricoUtenteTableModel> storicotb;
	@FXML
	private TableColumn<StoricoUtenteTableModel, String> storico_c1, storico_c2, storico_c3;
	
	
	private SessioneCliente sessione;
	private ControllerCustomerRiciclaggio controller = new ControllerCustomerRiciclaggio();
	
	
	public void mostraErrore(String err) {
		try {
			
			Stage primaryStage = new Stage();
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Errore.fxml"));
			Parent root = loader.load();
			GcErrore controller_next = loader.getController();
			controller_next.setError(err);
			primaryStage.initStyle(StageStyle.UNDECORATED);
			primaryStage.setScene(new Scene(root, 314, 209));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	
	private void setPrimaryStage(Stage primaryStage, String file, Button btn) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource(file));
			Parent root = loader.load();
			
			Graphic_Controller controller_next = loader.getController();
			controller_next.setData(sessione);
			
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
			}
		
	}
	
	
	public void setData(Sessione cliente) {
		this.sessione = (SessioneCliente) cliente;
		if (sessione.getFarmaci() !=null) {
		for (FarmacoCliente f : sessione.getFarmaci()) {
			if(f.getStato().compareTo("utilizzabile") != 0) f.attach(this);
		}
		
		
		if(riciclaggiotb != null) this.showResource();
		else this.showResourceBis();
		}
	}
	
	public void showResource() {
		
		ObservableList<RiciclaggioUtenteModelTable> list = FXCollections.observableArrayList();
		riciclaggio_c1.setCellValueFactory(new PropertyValueFactory<RiciclaggioUtenteModelTable, String>("Farmaco"));
		riciclaggio_c2.setCellValueFactory(new PropertyValueFactory<RiciclaggioUtenteModelTable, String>("Descrizione"));
		riciclaggio_c3.setCellValueFactory(new PropertyValueFactory<RiciclaggioUtenteModelTable, String>("Quantitativo"));
		
		
		
		if(sessione != null) {
			RiciclaggioUtenteBean bean = controller.findResources(sessione);
			list = bean.getFarmaci();
			riciclaggiotb.setItems(list);
		}
	}
	
	public void showResourceBis() {
		
		ObservableList<StoricoUtenteTableModel> list = FXCollections.observableArrayList();
		storico_c1.setCellValueFactory(new PropertyValueFactory<StoricoUtenteTableModel, String>("Farmaco"));
		storico_c2.setCellValueFactory(new PropertyValueFactory<StoricoUtenteTableModel, String>("Descrizione"));
		storico_c3.setCellValueFactory(new PropertyValueFactory<StoricoUtenteTableModel, String>("Verifica"));
		
		
		if(sessione != null) {
			StoricoUtenteBean bean = controller.findResourcesBis(sessione);
		
		//chiama la bean per visualizzare i dati:
		list = bean.getFarmaci();
		storicotb.setItems(list);
		}
	}
	
	
	
	@FXML
	public void riciclaPressed(ActionEvent event) {
		
		String farmaco = riciclaTf.getText();
		riciclaTf.setText("");
		if(farmaco.compareTo("") == 0) mostraErrore("Non hai inserito nessun parametro");
		
		else{
			
			ArrayList<FarmacoCliente> farmaci = sessione.getFarmaci();
			if(farmaci == null) mostraErrore("Non possiedi nessun farmaco");
			else {
				controller.ricicla(sessione, farmaco, this);				
			}
		}
	}
	
	
	@FXML
	public void refreshPressed(ActionEvent event) {
		
		
		sessione.setFarmaci(FarmacoClienteDAO.myFarmaciCliente(sessione.getUsername()));
		for(FarmacoCliente f: sessione.getFarmaci()) {
			f.attach(this);
			f.notifica();
		}
		System.out.println("sto chiamando il controller");
		controller.incrementaPunteggio(sessione);
	}
	
	
	
	@FXML
	public void ritiroPressed(ActionEvent event) {

		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "Appuntamento.fxml",(Button)event.getSource());

		
		
	}
	
	

	@FXML
	public void eventiPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerMyEvent.fxml",(Button)event.getSource());
	}
	
	@FXML
	public void eventi2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerMyEvent.fxml",(Button)event.getSource());
	}
	
	@FXML
	public void accountPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerAccount.fxml",(Button)event.getSource());
	}
	
	@FXML
	public void account2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerAccount.fxml",(Button)event.getSource());
	}
	
	@FXML
	public void risorsePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "Risorse.fxml",(Button)event.getSource());
		
	}
	
	@FXML
	public void risorse2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "Risorse.fxml",(Button)event.getSource());
		
	}
	
	@FXML
	public void homePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepageClient.fxml",(Button)event.getSource());
	}
	
	@FXML
	public void home2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepageClient.fxml",(Button)event.getSource());
	}
	
	@FXML
	public void ricicla2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerRiciclaggio.fxml",(Button)event.getSource());
		
	}
	
	@FXML
	public void storicoPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "CustomerStoricoRicicli.fxml",(Button)event.getSource());
		
	}


	@Override
	public void update(Observable f) {
		if(riciclaggiotb != null) this.showResource();
		else this.showResourceBis();		
	}
}
