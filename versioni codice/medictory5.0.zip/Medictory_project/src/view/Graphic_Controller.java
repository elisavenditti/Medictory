package view;

import model.Sessione;

public interface Graphic_Controller {
	public void setData(Sessione s);
}
