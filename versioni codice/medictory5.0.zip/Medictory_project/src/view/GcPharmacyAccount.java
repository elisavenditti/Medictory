package view;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Sessione;
import model.SessioneFarmacia;
import java.io.IOException;
import controller.ControllerLogout;
import controller.ControllerPharmacyAccount;
import ingegnerizzazione.ListaClientiBean;
import ingegnerizzazione.ListaClientiModelTable;
import ingegnerizzazione.Observable;
import ingegnerizzazione.Observer;
import ingegnerizzazione.PharmacyAccountBean;
import javafx.scene.Scene;

public class GcPharmacyAccount implements Graphic_Controller, Observer{
	@FXML
	private Button clienti, dati, home, home2, logout, logout2;
	@FXML
	private Label username, count, countBis, usernameLb, emailLb, nomeLb, indirizzoLb;
	@FXML
	private Label usernameLabel, emailLabel, farmaciaLabel, puntiLb, livelloLb, ptLabel, lvLabel;
	@FXML
	private TableView<ListaClientiModelTable> clientiTb;
	@FXML
	private TableColumn<ListaClientiModelTable, String> usernameCol, emailCol, livelloCol, puntiCol;
	
	
	private SessioneFarmacia sessione;
	private ControllerPharmacyAccount controller = new ControllerPharmacyAccount();
	


	private void setPrimaryStage(Stage primaryStage, String file, Button btn) {
		try {
			
			FXMLLoader loader = new FXMLLoader(getClass().getResource(file));
			Parent root = loader.load();
			
			if(btn.getId().compareTo("logout") == 0 || btn.getId().compareTo("logout2") ==0) {
				ControllerLogout ControllerLogout = new ControllerLogout();
				ControllerLogout.makeDataPharmacyPersistent(sessione);
			}
			else {
			Graphic_Controller controller_next = loader.getController();
			controller_next.setData(sessione);
			}
			
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
			}
		
	}
	
	
	public void showResource() {
		
		
		if(sessione != null) {
			PharmacyAccountBean bean = new PharmacyAccountBean(sessione);
			usernameLb.setText(bean.getUsername());
			emailLb.setText(bean.getEmail());
			nomeLb.setText(bean.getNomeFarmacia());
			indirizzoLb.setText(bean.getIndirizzo());
			count.setText(bean.getNumeroClienti());
		}
	}
	
	public void showResourceBis() {
		
		ObservableList<ListaClientiModelTable> list = FXCollections.observableArrayList();
		usernameCol.setCellValueFactory(new PropertyValueFactory<ListaClientiModelTable, String>("Username"));
		emailCol.setCellValueFactory(new PropertyValueFactory<ListaClientiModelTable, String>("Email"));
		livelloCol.setCellValueFactory(new PropertyValueFactory<ListaClientiModelTable, String>("Livello"));
		puntiCol.setCellValueFactory(new PropertyValueFactory<ListaClientiModelTable, String>("Punti"));
		
		
		if(sessione != null) {
			ListaClientiBean bean = controller.findListOfCustomers(sessione, this);
			list = bean.getClienti();
			clientiTb.setItems(list);
			countBis.setText(Integer.toString(sessione.getClienti().size()));
		}
		
	}

	
	@FXML
	public void datiPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyAccount.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void clientiPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyAccountPage2.fxml", (Button)event.getSource());
	}

	@FXML
	public void homePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepagePharmacy.fxml", (Button)event.getSource());
	}
	@FXML
	public void home2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepagePharmacy.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void logoutPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "progetto.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void logout2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "progetto.fxml", (Button)event.getSource());
	}
	
	public void setData(Sessione farma) {
		this.sessione = (SessioneFarmacia) farma;
		if(clientiTb != null) this.showResourceBis();
		else this.showResource();
	}

	@Override
	public void update(Observable subj) {
		if (count != null) this.showResource();
		else this.showResourceBis();
		
	}

}
