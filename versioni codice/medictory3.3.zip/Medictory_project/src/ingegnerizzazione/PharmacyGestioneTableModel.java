package ingegnerizzazione;


public class PharmacyGestioneTableModel {
	
	private String utente, farmaco, scadenza;
	
	public PharmacyGestioneTableModel(String username, String farmaco, String scadenza) {
		this.utente = username;
		this.farmaco = farmaco;
		this.scadenza = scadenza;
	}
	
	
	public String getUtente() {
		return utente;
	}
	public void setUtente(String utente) {
		this.utente = utente;
	}
	public String getFarmaco() {
		return farmaco;
	}
	public void setFarmaco(String farmaco) {
		this.farmaco = farmaco;
	}


	public String getScadenza() {
		return scadenza;
	}


	public void setScadenza(String scadenza) {
		this.scadenza = scadenza;
	}

}
