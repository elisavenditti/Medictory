package controller;
import model.Farmacia;
import model.FarmaciaDAO;
import model.FarmacoCliente;
import model.SessioneCliente;
import model.SessioneFarmacia;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import model.Cliente;
import model.ClienteDAO;

public class ControllerLogin{
	private SessioneCliente s;
	private SessioneFarmacia sf;
	
	
	public SessioneFarmacia loginFarmacia(String us, String pwd) {
		if (us == null || pwd == null || us.equals("") || pwd.equals("")) return null;
		
		Farmacia f;
		f = FarmaciaDAO.esisteFarmacia(us, pwd);
		
		
		if(f == null) return null;
		sf = new SessioneFarmacia(f.getUsername(), f.getClienti() ,f.getFarmaci(),f.getEventi());
		sf.setNomeFarmacia(f.getNome());
		sf.setIndirizzo(f.getIndirizzo());
		sf.setEmail(f.getEmail());
		
		return sf;
	}
	
	public SessioneCliente loginCliente(String us, String pwd) {
		if (us == null || pwd == null || us.equals("") || pwd.equals("")) return null;
		
		Cliente c;
		c = ClienteDAO.esisteCliente(us, pwd);
			
		
		if(c == null) return null;
		
		s = new SessioneCliente(c.getUsername(),c.getFarmaci(),c.getEventi());
		s.setPunteggio(c.getPunti());
		s.setLivello(c.getLivello());
		s.setFarmaciaAssociata(c.getFarma_associata());
		s.setEmail(c.getEmail());
		check();
		return s;
	}

	public void check() {
		
		Date oggi = new Date();
		
		
		ArrayList<FarmacoCliente> farmaci = new ArrayList<FarmacoCliente>();	
		if(s.getFarmaci() != null) {
			farmaci = s.getFarmaci();
		
			for(FarmacoCliente f: farmaci) {
		
				try {
				
					SimpleDateFormat sdf = new  SimpleDateFormat("yyyy-MM-dd");
					Date scad = sdf.parse(f.getScadenza());
				
					if (scad.before(oggi)) { 
						if(f.getStato().compareTo("utilizzabile") == 0) f.setStato("scaduto");
					}
			
				} catch (ParseException e) {
		      e.printStackTrace();
				}
			}
		}
	}
}
