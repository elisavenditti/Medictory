package model;
import java.sql.*;
import java.util.ArrayList;



public class FarmacoClienteDAO {
	private static AbstractFactory factory = new FactoryElementoUtente();
	private static Connector connector = Connector.getConnectorInstance();
	
	
	public static ArrayList<FarmacoCliente> myFarmaciCliente(String username) {
		
		ArrayList<FarmacoCliente> farmaci =  null;
		
		Statement stmt = null;
		Connection conn= connector.getConnection();
     
        
        try {
        	
        	String sql = "SELECT `farmaco`, `descrizione`, `scadenza`, `quantitativo`, `stato` " + "FROM `Farmaco Cliente` where `possessore` = '" + username + "';";
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);       
            
            ResultSet rs = stmt.executeQuery(sql);
            
           
            if (rs.first()) {		// rs non vuoto, posso procedere
            	rs.first();
            	farmaci = new ArrayList<FarmacoCliente>();
            	do {
            		FarmacoCliente f =(FarmacoCliente)factory.creaFarmaco(rs.getString("farmaco"), rs.getString("descrizione"), rs.getString("scadenza"), rs.getInt("quantitativo"));
             		f.setStato(rs.getString("stato"));
            		farmaci.add(f);
            		
            	} while (rs.next());
            	
            }

            else{
            	rs.close();
                stmt.close();
                conn.close();
            }
        } catch (SQLException se) {
            // Errore durante l'apertura della connessione
            se.printStackTrace();
        } catch (Exception e) {
            // Errore nel loading del driver
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
            } catch (SQLException se2) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
		return farmaci;
	}
	
	
	public static void scriviFarmacoClienteNelDb(FarmacoCliente farmaco, String possessore) {

		Statement stmt = null;
		Connection conn= connector.getConnection();
		

		try {
	        	
	      
	        String sql = "UPDATE `Farmaco Cliente` SET `stato` = '"+ farmaco.getStato() + "' , `quantitativo` = '" + farmaco.getQuantita() + "' WHERE `farmaco` = '" + farmaco.getNome() + 
	        		"' and `descrizione` = '" + farmaco.getDescrizione() + "'and `scadenza`='" + farmaco.getScadenza() + "'and `possessore`='"+ possessore +"';";
	    
	     
	        stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);       
	            
	        stmt.executeUpdate(sql);
	            
	        
	        stmt.close();
	        conn.close();
	        
		} catch (SQLException se) {
	            // Errore durante l'apertura della connessione
			se.printStackTrace();
	    } catch (Exception e) {
	            // Errore nel loading del driver
	        e.printStackTrace();
	    } finally {
	    	try {
	    		if (stmt != null)
	    			stmt.close();
	    	} catch (SQLException se2) {
	    		se2.printStackTrace();
	        }
	    	try {
	    		if (conn != null)
	    		   conn.close();
	        } catch (SQLException se) {
	               se.printStackTrace();
	        }
	    }
	}
	
	
	
	public static void cambiaStato(String farmaco, String possessore, String scadenza, String stato) {
		
		Statement stmt = null;
		Connection conn= connector.getConnection();
		
		try {
        	
	        String sql = "UPDATE `Farmaco Cliente` SET `stato` = '"+ stato + "' WHERE `farmaco` = '" + farmaco + 
	        		"' and `scadenza` = '" + scadenza + "' and `possessore`='"+ possessore +"';";
	    
	     
	        stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);       
	            
	        stmt.executeUpdate(sql);
	            
	        
	        stmt.close();
	        conn.close();
		
		} catch (SQLException se) {
            // Errore durante l'apertura della connessione
			se.printStackTrace();
		} catch (Exception e) {
            // Errore nel loading del driver
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				} catch (SQLException se2) {
					se2.printStackTrace();
				}
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
	}
		
}
