package model;

//Created event, not started yet


public class StatoIniziale extends AbstractState {
	


	public StatoIniziale(Evento evento) {
		super(evento);
		
	}

	@Override
	public void addPartecipant(String username) {
		this.evento.addPartecipant(username);
	}
    
	@Override
	public void setLivello_richiesto(int lv) {
		this.evento.livello_richiesto=lv;
	}
    
	@Override
	public String getVincitore() {
		return "No winner: the event is going to start soon";
	}
    
	@Override
	public void setVincitore(String v) {
	}
    
	@Override
	public void setFine(String f) {
		this.evento.fine=f;
	}
    
	@Override
	public void setInizio(String i) {
		this.evento.inizio=i;
	}
    
	@Override
	public void setPremio(String premio) {
		this.evento.premio=premio;;
	}
    
	@Override
	public void setDescrizione(String ds) {
		this.evento.descrizione=ds;
	}
    
	@Override
	public void setNome(String nome) {
		this.evento.nome=nome;
	}
    
	@Override
	public AbstractState nextState() {
		SvolgimentoEvento s = new SvolgimentoEvento(evento);
		return s;
	}
	
}
