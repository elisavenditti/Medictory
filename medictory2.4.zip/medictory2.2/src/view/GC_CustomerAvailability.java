package view;

import controller.ControllerDisponibilita;
import ingegnerizzazione.DisponibilitaBean;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class GC_CustomerAvailability {
	
	@FXML
	private Button back;
	@FXML
	private Label numeroLb;
	private String farmacia, farmaco;
	private ControllerDisponibilita controller = new ControllerDisponibilita();
	
	
	private void searchAvailability() {
		DisponibilitaBean bean = controller.cercaDisponibilitaInFarmacia(this.farmacia, this.farmaco);
		numeroLb.setText(bean.getNumero() + " unit�");
	}

	
	@FXML
	public void backPressed() {
		Stage stage = (Stage) back.getScene().getWindow();
		stage.close();
	}

	
	public void request(String farmacia, String farmaco) {
		this.farmacia = farmacia;
		this.farmaco = farmaco;
		this.searchAvailability();
	}
}
