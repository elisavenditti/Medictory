package view;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import model.Sessione;
import model.SessioneFarmacia;

import java.io.IOException;
import javafx.scene.Scene;

public class GC_PharmacyGestione implements Graphic_Controller{
	
	@FXML
	private Button eventi, eventi2, ritiro, ritiro2, risorse, risorse2, account, account2, home, home2, riciclaggi, premiazioni, verifica, premia;
	
	
	private SessioneFarmacia sessione;


	private void setPrimaryStage(Stage primaryStage, String file, Button btn) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource(file));
			Parent root = loader.load();
			
			
			Graphic_Controller controller_next= loader.getController();
			controller_next.setData(sessione);
			
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
			}
		
	}	
	
	@FXML
	public void accountPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyAccount.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void account2Pressed(ActionEvent event) {
		System.out.println("sono qui");
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyAccount.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void eventiPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyEvent.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void eventi2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyEvent.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void risorsePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "RisorseFarmacia.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void risorse2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "RisorseFarmacia.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void homePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepagePharmacy.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void home2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepagePharmacy.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void premiazioniPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "GestionePremiazioniFarmacia.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void riciclaggiPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "GestioneFarmacie.fxml", (Button)event.getSource());
	}
	
	public void setData(Sessione farma) {
		this.sessione = (SessioneFarmacia) farma;
	}
	
}
