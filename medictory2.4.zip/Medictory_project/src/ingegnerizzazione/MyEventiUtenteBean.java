package ingegnerizzazione;

import javafx.collections.ObservableList;

public class MyEventiUtenteBean {
private ObservableList<EventiUtenteAbstractModelTable> eventi;
	
	public MyEventiUtenteBean(ObservableList<EventiUtenteAbstractModelTable> list) {
		this.eventi=list;
	}

	public ObservableList<EventiUtenteAbstractModelTable> getEventi() {
		return eventi;
	}

	public void setEventi(ObservableList<EventiUtenteAbstractModelTable> eventi) {
		this.eventi = eventi;
	}

	
}
