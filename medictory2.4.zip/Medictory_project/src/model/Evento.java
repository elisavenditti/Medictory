package model;

import java.util.ArrayList;
import java.util.List;

public class Evento {
	private AbstractState state;
    

	public String nome, descrizione, premio, inizio, fine;
	public String vincitore = null;
	public int livello_richiesto;
	public List<String> partecipanti = new ArrayList<>();

    public Evento(String nome, String descrizione, String premio, String inizio, String fine, int lv) {
    	this.state = new StatoIniziale(this);
        this.nome=nome;
        this.descrizione = descrizione;
        this.premio = premio;
        this.livello_richiesto = lv;
        this.inizio = inizio;
        this.fine = fine;
        for (int i = 1; i <= 12; i++) {
            partecipanti.add("p" + i);
        }
    }
	

    /********************* FUNZIONI CHE CAMBIANO IMPLEMENTAZIONE IN BASE ALLO STATO ***********************************/
    
    
    public void nextState() {
        this.state = this.state.nextState();
    }
    
    public void setState(AbstractState as) {
    	this.state=as;
    	}
    
    
    public void addPartecipant(String username) {
    	this.state.addPartecipant(username);
    }
    
    public void setLivello_richiesto(int livello_richiesto) {
			this.state.setLivello_richiesto(livello_richiesto);
	}
    
    public String getVincitore() {
    	return this.state.getVincitore();
	}

	public void setVincitore(String vincitore) {
			this.state.setVincitore(vincitore);
	}
    

	public void setFine(String fine) {
			this.state.setFine(fine);
	}
    
	public void setInizio(String inizio) {
			this.state.setInizio(inizio);
		
	}
	
	public void setPremio(String premio) {
			this.state.setPremio(premio);
	}
    
	
	public void setDescrizione(String descrizione) {
			this.state.setDescrizione(descrizione);
		
	}

	public void setNome(String nome) {
		this.state.setNome(nome);
	}
	
	
	/********************* NON CAMBIANO IN BASE ALLO STATO *****************************************/
	
	public AbstractState getState() {
        return this.state;
    }
	
	public String getNome() {
		return this.nome;
	}
	
	public String getPremio() {
		return this.premio;
	}

	public String getDescrizione() {
		return this.descrizione;
	}
	
	public String getFine() {
		return this.fine;
	}
	
	public int getLivello_richiesto() {
		return this.livello_richiesto;
	}
	public String getInizio() {
		return this.inizio;
	}
}
