package view;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import model.Sessione;
import model.SessioneFarmacia;

import java.io.IOException;
import javafx.scene.Scene;

public class GC_PharmacyAccount implements Graphic_Controller{
	@FXML
	private Button clienti, dati, home, home2, logout, logout2;
	@FXML
	private Label username;
	
	private SessioneFarmacia sessione;
	


	private void setPrimaryStage(Stage primaryStage, String file, Button btn) {
		try {
			
			FXMLLoader loader = new FXMLLoader(getClass().getResource(file));
			Parent root = loader.load();
			
			if(btn.getId().compareTo("logout") != 0 && btn.getId().compareTo("logout2") !=0) {
				Graphic_Controller controller_next = loader.getController();
				controller_next.setData(sessione);
			}
			
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
			}
		
	}
	
	@FXML
	public void datiPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyAccount.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void clientiPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyAccountPage2.fxml", (Button)event.getSource());
	}

	@FXML
	public void homePressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepagePharmacy.fxml", (Button)event.getSource());
	}
	@FXML
	public void home2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepagePharmacy.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void logoutPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "progetto.fxml", (Button)event.getSource());
	}
	
	@FXML
	public void logout2Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "progetto.fxml", (Button)event.getSource());
	}
	
	public void setData(Sessione farma) {
		this.sessione = (SessioneFarmacia) farma;
	}

}
