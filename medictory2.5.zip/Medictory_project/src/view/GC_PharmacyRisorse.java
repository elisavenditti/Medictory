package view;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.FarmacoFarmacia;
import model.Sessione;
import model.SessioneFarmacia;
import java.io.IOException;
import controller.ControllerPharmacyResource;
import ingegnerizzazione.Observer;
import ingegnerizzazione.RisorseFarmaciaBean;
import ingegnerizzazione.RisorseFarmaciaTableModel;
import javafx.scene.Scene;

public class GC_PharmacyRisorse implements Graphic_Controller, Observer{
	
	@FXML
	private Button eventi, ritiro, gestione, account, home, submit;
	@FXML
	private TableView<RisorseFarmaciaTableModel> risorseTb;
	@FXML
	private TableColumn<RisorseFarmaciaTableModel, String> farmacoCol, quantitativoCol;
	@FXML
	private TextField farmacoLb, quantitativoLb;
	
	
	private SessioneFarmacia sessione;
	private ControllerPharmacyResource controller = new ControllerPharmacyResource();
	
	
	
	private void setPrimaryStage(Stage primaryStage, String file) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource(file));
			Parent root = loader.load();
					
			Graphic_Controller controller_next = loader.getController();
			controller_next.setData(sessione);
			
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	private void mostraErrore(String err) {
		try {
			
			Stage primaryStage = new Stage();
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Errore.fxml"));
			Parent root = loader.load();
			GC_Errore controller_next = loader.getController();
			controller_next.setError(err);
			primaryStage.initStyle(StageStyle.UNDECORATED);
			primaryStage.setScene(new Scene(root, 314, 209));
			primaryStage.show();
			
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public void showResource() {
		
		ObservableList<RisorseFarmaciaTableModel> list = FXCollections.observableArrayList();
		farmacoCol.setCellValueFactory(new PropertyValueFactory<RisorseFarmaciaTableModel, String>("Farmaco"));
		quantitativoCol.setCellValueFactory(new PropertyValueFactory<RisorseFarmaciaTableModel, String>("Quantitativo"));
		
	
		if(sessione != null) {
			RisorseFarmaciaBean bean = controller.findResources(sessione);
			list = bean.getFarmaci();
			risorseTb.setItems(list);
		
		}
	}
	
	
	@FXML
	public void eventiPressed(ActionEvent event) {
		
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyEvent.fxml");
	}
	
	@FXML
	public void gestionePressed(ActionEvent event) {
		
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "GestioneFarmacie.fxml");
	}
	
	@FXML
	public void ritiroPressed(ActionEvent event) {
		
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepagePharmacy.fxml");
	}
	
	@FXML
	public void homePressed(ActionEvent event) {
		
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "HomepagePharmacy.fxml");
	}
	@FXML
	public void accountPressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "PharmacyAccount.fxml");
	}
	
	@FXML
	public void submitPressed(ActionEvent event) {
		
		String f = farmacoLb.getText();
		String q = quantitativoLb.getText();
		
		if(f.compareTo("") == 0 || q.compareTo("") == 0) {
			mostraErrore("Non hai inserito tutti i parametri");
		}
		
		else {
			controller.addMedicine(sessione, this, f, Integer.parseInt(q));
		}
		
		farmacoLb.setText("");
		quantitativoLb.setText("");
	}

	@Override
	public void setData(Sessione farmacia) {
		this.sessione = (SessioneFarmacia) farmacia;
		for (FarmacoFarmacia f : sessione.getFarmaci()) {
			f.attach(this);
		}
		this.showResource();
		
	}

	@Override
	public void update() {
		showResource();
		
	}
	
}
