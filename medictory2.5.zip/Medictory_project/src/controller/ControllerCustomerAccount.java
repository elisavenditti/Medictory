package controller;

import java.util.ArrayList;

import ingegnerizzazione.ListaFarmacieBean;
import ingegnerizzazione.ListaFarmacieModelTable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.FarmaciaDAO;
import model.Farmacia;



public class ControllerCustomerAccount {
	private ArrayList<Farmacia> farmacie = null; //
	
	
	
	public ListaFarmacieBean findListOfPharmacy() {
		
		ObservableList<ListaFarmacieModelTable> list = FXCollections.observableArrayList();
		
		if(farmacie == null) {
			farmacie = new ArrayList<Farmacia>();
			farmacie = FarmaciaDAO.tutteLeFarmacie();
		}
		
		for(Farmacia f: farmacie) {
			list.add(new ListaFarmacieModelTable(f));
		}
		
		return new ListaFarmacieBean(list);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*public CustomerAccountBean findInfoAccount(SessioneCliente s) {
		
		ArrayList<String> list = new ArrayList<String>();
		list = ClienteDAO.datiAccount(s.getUsername());
		
		return new CustomerAccountBean(list.get(0), list.get(4), list.get(1), list.get(2), list.get(3));
	}*/
	
}
