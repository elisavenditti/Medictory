package ingegnerizzazione;

import javafx.collections.ObservableList;

public class RisorseFarmaciaBean {
	private ObservableList<RisorseFarmaciaTableModel> farmaci;
	
	public RisorseFarmaciaBean(ObservableList<RisorseFarmaciaTableModel> list) {
		this.setFarmaci(list);
	}

	public ObservableList<RisorseFarmaciaTableModel> getFarmaci() {
		return farmaci;
	}

	public void setFarmaci(ObservableList<RisorseFarmaciaTableModel> farmaci) {
		this.farmaci = farmaci;
	}
}
