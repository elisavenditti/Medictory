package view;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Farmacia;
import controller.ControllerLogin;
import java.io.IOException;
import javafx.scene.Scene;

public class GC_PharmacyLogin {
	
	@FXML
	private Button backButton1;
	@FXML
	private Button PharmacyLogin;
	@FXML
	private TextField username;
	@FXML
	private PasswordField password;

	private void setPrimaryStage(Stage primaryStage, String file) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource(file));
			primaryStage.setTitle("Medictory");
			primaryStage.setScene(new Scene(root, 600,400));
			primaryStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	public void loginPressed(ActionEvent event){

		String s1, s2;
		s1 = username.getText();
		s2 = password.getText();
		Farmacia f = ControllerLogin.loginFarmacia(s1, s2);
		
		if(f == null) {												// la f potresti metterla nel costruttore di un altro controller
																	// magari a quel costruttore serve conoscere i dati della singola istanza di farmacia
			
			s1 = "";
			s2 = "";	
			GC_Errore g = new GC_Errore();
			g.mostrati();	
			
			
		} else {
			
			Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
			setPrimaryStage(primaryStage, "HomepagePharmacy.fxml");
			
			// prepara i dati da caricare ??
		}
	}
	
	@FXML
	public void back1Pressed(ActionEvent event) {
		Stage primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
		setPrimaryStage(primaryStage, "progetto.fxml");
	}

}
