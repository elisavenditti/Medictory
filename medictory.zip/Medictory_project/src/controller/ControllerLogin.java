package controller;
import model.Farmacia;
import model.FarmaciaDAO;
import model.Cliente;
import model.ClienteDAO;

public class ControllerLogin {
	
	public static Farmacia loginFarmacia(String us, String pwd) {
		if (us == null || pwd == null || us.equals("") || pwd.equals("")) return null;
		
		Farmacia f;
		f = FarmaciaDAO.esisteFarmacia(us, pwd);
		
		if(f == null) return null;
		
		return f;
	}
	
	public static Cliente loginCliente(String us, String pwd) {
		if (us == null || pwd == null || us.equals("") || pwd.equals("")) return null;
		
		Cliente c;
		c = ClienteDAO.esisteCliente(us, pwd);
		
		if(c == null) return null;
		
		return c;
	}
}
