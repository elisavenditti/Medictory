package model;
import java.sql.*;

import javafx.collections.ObservableList;
import view.ModelTable;

public class FarmaciaDAO {
	private static String USER = "root";
	private static String PASS = "lZ...030599";
	private static String DB_URL = "jdbc:mysql://localhost:3306/medictory";
	private static String DRIVER_CLASS_NAME = "com.mysql.cj.jdbc.Driver";
	
	
	public static Farmacia creaUtenteFarmacia(String username, String pwd, String nome, String email, String indirizzo) {
		Statement stmt = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		Statement stmt4 = null;
        Connection conn = null;
        Farmacia f = null;
        
        try {
        	
        	String sql = "SELECT `username` " + "FROM `Farmacia` where `username` = '" + username + "';";
            String sql2 = "SELECT `indirizzo` " + "FROM `Farmacia` where `indirizzo` = '" + indirizzo + "';";
            String sql3 = "INSERT INTO `Utenti` (`username`, `password`, `email`) values ('"+ username + "', '" + pwd + "', '" +email + "');" ;
            String sql4 = "INSERT INTO `Farmacia` (`username`, `nome`, `indirizzo`) values ('"+ username + "', '" + nome + "', '" +indirizzo + "');" ;
            
        	//cerca nel db se esistono username e indirizzo inseriti
        	Class.forName(DRIVER_CLASS_NAME);
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            stmt2 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            stmt3 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt4 = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            
            
            ResultSet rs = stmt.executeQuery(sql);
            ResultSet rs2 = stmt2.executeQuery(sql2);
           
            if (!rs.first() && !rs2.first()) {		// rs e rs2 vuoti --> posso procedere
            	
            	
            	stmt3.executeUpdate(sql3);
            	stmt4.executeUpdate(sql4);
            	f = new Farmacia(username, pwd, email, nome, indirizzo);
            	return f;

            }
            rs.close();
            stmt.close();
            
            conn.close();
        } catch (SQLException se) {
            // Errore durante l'apertura della connessione
            se.printStackTrace();
        } catch (Exception e) {
            // Errore nel loading del driver
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
            } catch (SQLException se2) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        return null;
	}
	
	
	
	
	public static Farmacia esisteFarmacia(String username, String pwd) {
		
		Statement stmt = null;
        Connection conn = null;
        Farmacia f = null;
        
        try {
        	
        	String sql = "SELECT F.`username`, F.`nome`, F.`indirizzo`, U.`password`, U.`email` " + "FROM `Farmacia` F join `Utenti` U on F.`username`= U.`username` where F.`username` = '" + username + "' and U.`password` = '" + pwd + "';";
           
        	
        	Class.forName(DRIVER_CLASS_NAME);
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            
            
            ResultSet rs = stmt.executeQuery(sql);
           
            if (rs.first()) {		// rs non vuoto --> esiste l'utente cercato  
            	// � giusto creare qui la farmacia? mi serve veramente ?
            	f = new Farmacia(rs.getString("username"), rs.getString("password"), rs.getString("email"), rs.getString("nome"), rs.getString("indirizzo"));
            	rs.close();
            	stmt.close();
            	conn.close();
            	return f;
            	
            } else {
            	
            	rs.close();
            	stmt.close();
            	conn.close();
            	return null;
            }
            
        } catch (SQLException se) {
            // Errore durante l'apertura della connessione
            se.printStackTrace();
        } catch (Exception e) {
            // Errore nel loading del driver
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
            } catch (SQLException se2) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        return null;
	}
	
	
	
	
	
	
	
	public static ObservableList<ModelTable> popolaRegistazione(ObservableList<ModelTable> list) {
		Statement stmt = null;
        Connection conn = null;
        
       try { 
      
    	   	String sql = "SELECT `username`, `nome`, `indirizzo` " + "FROM `Farmacia`;";
    	   	Class.forName(DRIVER_CLASS_NAME);
    	   	conn = DriverManager.getConnection(DB_URL, USER, PASS);
    	   	stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
    	   	ResultSet rs = stmt.executeQuery(sql);
       
        
    	   	if (!rs.first()) return null;
        	rs.first();
    	   	do {
    	   		list.add(new ModelTable(rs.getString("username"), rs.getString("nome"), rs.getString("indirizzo")));
    	   	} while(rs.next());
    	   	
    	   	rs.close();
    	   	stmt.close();
    	   	conn.close();
    	   	return list;
       	} catch (SQLException se) {
       		// Errore durante l'apertura della connessione
       		se.printStackTrace();
       	} catch (Exception e) {
       		// Errore nel loading del driver
       		e.printStackTrace();
       	} finally {
       		try {
       			if (stmt != null)
       				stmt.close();
       		} catch (SQLException se2) {
       		}
       		try {
       			if (conn != null)
       				conn.close();
       		} catch (SQLException se) {
       			se.printStackTrace();
       		}
       	}
       return null;
	}
        
        
        
}
