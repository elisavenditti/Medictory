package model;

public class Farmacia extends Utente{
	private String nome;
	private String indirizzo;
	
	public Farmacia(String user, String pwd, String em, String nome, String ind) {
		
		super(user, pwd, em);
		this.nome = nome;
		this.indirizzo = ind;
	}
	
	public void setNome(String name){
		this.nome = name;
	}
	public void setIndirizzo(String i){
		this.indirizzo = i;
	}
	
	public String getNome(){
		return this.nome;
	}
	public String getIndirizzo(){
		return this.indirizzo;
	}

}
