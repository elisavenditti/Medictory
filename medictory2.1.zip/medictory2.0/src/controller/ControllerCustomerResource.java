package controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import ingegnerizzazione.RisorseUtenteBean;
import ingegnerizzazione.RisorseUtenteTableModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.AbstractFactory;
import model.FactoryElementoUtente;
import model.FarmacoCliente;
import model.SessioneCliente;
import view.GC_CustomerRisorse;

public class ControllerCustomerResource {
	private AbstractFactory factory = new FactoryElementoUtente();
	
	public RisorseUtenteBean findResources(SessioneCliente s) {
		int i;
	
		ObservableList<RisorseUtenteTableModel> list = FXCollections.observableArrayList();
		
		ArrayList<FarmacoCliente> farmaci = s.getFarmaci();
		
		for(i=0; i<farmaci.size(); i++) {
			if(farmaci.get(i).getStato().compareTo("utilizzabile") == 0)
				list.add(new RisorseUtenteTableModel(farmaci.get(i).getNome(), farmaci.get(i).getDescrizione(), farmaci.get(i).getQuantita(), farmaci.get(i).getScadenza())); 
		}
		
		return new RisorseUtenteBean(list);
	}
	
	public void modifyAmount(SessioneCliente s, String farma, int quantitativo) {
		ArrayList<FarmacoCliente> farmaci = s.getFarmaci();
		for (FarmacoCliente f : farmaci) {
			if(f.getNome().compareToIgnoreCase(farma)==0) {
				f.setQuantita(f.getQuantita() + quantitativo);
				f.notifica();	
			}
		}
	}
	
	public boolean addMedicine(SessioneCliente s, GC_CustomerRisorse controllerGrafico, String nome, String descrizione, String scadenza, int quantitativo) {
		
		ArrayList<FarmacoCliente> farmaci = s.getFarmaci();
		
		String[] parts = scadenza.split("-");
		int year = Integer.parseInt(parts[0]);
		int month = Integer.parseInt(parts[1]);
		int day = Integer.parseInt(parts[2]);
		
		Date oggi = new Date();							
				
		try {
	    
			DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.SHORT, Locale.ITALY);
			Date scad = dateFormat.parse(year + "/" + month + "/" + day);
			
			if (scad.before(oggi)) return false; 		//if is expired
		
		
		} catch (ParseException e) {
	      e.printStackTrace();
	    }
		
		FarmacoCliente f = (FarmacoCliente) factory.creaFarmaco(nome, descrizione, scadenza, quantitativo);
		f.setStato("utilizzabile");
		farmaci.add(f);
		s.setFarmaci(farmaci);				//update the list of medicines in the session
		
		f.attach(controllerGrafico);
		f.notifica();
		
		return true;
	}
}
