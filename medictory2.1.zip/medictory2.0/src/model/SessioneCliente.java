package model;

import java.util.ArrayList;

public class SessioneCliente extends Sessione{
	
	private ArrayList<FarmacoCliente> farmaci;
	private int punteggio;
	private int livello;
	private String email;
	private String farmaciaAssociata;
	
		
	public SessioneCliente(String username, ArrayList<FarmacoCliente> farmaci, ArrayList<Evento> eventi) {
		this.username = username;
		this.farmaci = farmaci;
		this.eventi = eventi;
	}
	
	
	public int getPunteggio() {
		return punteggio;
	}


	public void setPunteggio(int punteggio) {
		this.punteggio = punteggio;
	}


	public ArrayList<FarmacoCliente> getFarmaci() {
		return farmaci;
	}

	public void setFarmaci(ArrayList<FarmacoCliente> farmaci) {
		this.farmaci = farmaci;
	}


	public String getFarmaciaAssociata() {
		return farmaciaAssociata;
	}


	public void setFarmaciaAssociata(String farmaciaAssociata) {
		this.farmaciaAssociata = farmaciaAssociata;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public int getLivello() {
		return livello;
	}


	public void setLivello(int livello) {
		this.livello = livello;
	}
	

}
