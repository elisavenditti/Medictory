package model;

import java.util.ArrayList;

public class FarmacoFarmacia extends Farmaco {
	
	
	public FarmacoFarmacia(String nome, String descrizione, String scadenza, int quantita) {
		super(nome,descrizione,scadenza,quantita);
		
	}
	
	
	
}
